package com.capg.walletservice;

import java.util.List;
import java.util.Scanner;

import com.capg.walletbeans.TransactionBeans;
import com.capg.walletbeans.WalletBeans;
import com.capg.walletdao.WalletDaoImpl;

public  class WalletServiceImpl implements WalletServiceInterface{
	Scanner sc=new Scanner(System.in);

	WalletDaoImpl wd=new WalletDaoImpl();
	
	@Override
	public WalletBeans userAccount(WalletBeans wb) {
	    WalletBeans w=wd.userAccount1(wb);
        return w;
    }
	public long validationBal(long balance) {
		while (true) {
			if(balance<=0) {
				System.out.println("Amount should be greater than zero \nEnter valid amount ");
				balance=sc.nextLong();
			}else {
				return balance;
			}
		}
	}
	public String validationName(String userName) {
		if(userName.matches("[A-Z][a-zA-Z]*")){
			return userName;
		}else {
			System.out.println("Enter Valid Name Starts with Uppercase ");
			return userName=sc.next();
		}
		}
	public String validationMobileNo(String mobileNo) {
		while(true) {
			if(String.valueOf(mobileNo).length()==10 && mobileNo.matches("[6-9][0-9]{9}")) {
				System.out.println(mobileNo);
				return mobileNo;
			}else {
				System.out.println("Enter valid 10 digit number");
				mobileNo=sc.next();			}
		}
	}
	@Override
	public WalletBeans showBalance(long accNo) {
		WalletBeans wb1=wd.showBalance(accNo);
		return wb1;
	}
	@Override
	public WalletBeans deposit(long accNo, long bal) {
		WalletBeans wb1=wd.deposit(accNo,bal);
		return wb1;

	}
	@Override
	public WalletBeans withdraw(long accNo, long bal1) {
		WalletBeans wb1=wd.withdraw(accNo,bal1);
		return wb1;
    }
	@Override
	public WalletBeans fundTransfer(long accNo, long accNo1, long bal2) {
		WalletBeans wb1=wd.fundTransfer(accNo,accNo1,bal2);
		return wb1;
	}
	@Override
	public List<TransactionBeans> getTransactions(long accNo) {
		List<TransactionBeans> l=wd.getTransactions(accNo);
		return l;
	}
	
}