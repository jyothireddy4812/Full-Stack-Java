package com.capg.walletservice;

import java.util.List;

import com.capg.walletbeans.TransactionBeans;
import com.capg.walletbeans.WalletBeans;

public interface WalletServiceInterface {
	
	WalletBeans userAccount(WalletBeans wb);
	
	WalletBeans showBalance(long accNo);
	
	WalletBeans deposit(long accNo, long bal);
	
	WalletBeans withdraw(long accNo, long bal1);
	
    WalletBeans fundTransfer(long accNo, long accNo1, long bal2) ;

    List<TransactionBeans> getTransactions(long accNo);
}


