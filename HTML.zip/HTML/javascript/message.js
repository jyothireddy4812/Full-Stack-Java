function msg(){
    document.write(" JYOTHIREDDY");
}