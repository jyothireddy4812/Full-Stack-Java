import { Component, OnInit, APP_INITIALIZER } from '@angular/core';
import { MyServiceService, Employee, Transactions } from '../my-service.service';


@Component({
  selector: 'app-deposite-amount',
  templateUrl: './deposite-amount.component.html',
  styleUrls: ['./deposite-amount.component.css']
})
export class DepositeAmountComponent implements OnInit {

  isLogin:boolean=true;
  employees:Employee[]=[];
  createdTransaction:Transactions;
  isShowBalance=true;
  service:MyServiceService;
  cbalance1:number;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  depositeAmount(data:any){
    if(data.caccount=="" || data.caccount1==""|| data.cpassword=="" ||data.cbalance ==""){
      alert("Please fill all Fields")
      return;
    }
    let tid:number;
    let caccount_first:number=data.caccount;
    let cbalance:number=data.cbalance;
  
    if(this.service.login(data)){
    this.service.depositeBalance(caccount_first,cbalance);

    this.createdTransaction=new Transactions(cbalance*4+1023,data.caccount,"Deposit",data.cbalance);
    this.service.addTransaction(this.createdTransaction)
    this.cbalance1 = this.service.showBalance(data);
    this.isShowBalance = !this.isShowBalance;
 
    }
    else{
      alert("Invalid Account Number or Password");
    }
  }


  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
