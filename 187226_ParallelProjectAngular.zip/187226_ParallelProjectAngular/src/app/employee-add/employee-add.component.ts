import { Component, OnInit } from '@angular/core';
import { Employee, MyServiceService, Transactions } from '../my-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {



  router: Router;
  createdFlag: boolean = false;

  service: MyServiceService;

  constructor(service: MyServiceService, router: Router) {
    this.service = service;
    this.router = router;
  }

  ngOnInit() {
  }

  add(data: any) {
    if(data.cname=="" || data.cphone==""|| data.cpassword=="" ||data.ccity ==""){
      alert("Please fill all fields")
      return;
    }
    data.caccount = data.cphone - 100;
    data.cbalance = 5000;
   
    let createdEmployee = new Employee(data.caccount, data.cname, data.cphone, data.cpassword, data.ccity, data.cbalance);

    this.service.add(createdEmployee);

    let createdTransaction = new Transactions(3866, data.caccount, "Deposit", data.cbalance);
    this.service.addTransaction(createdTransaction)


    alert("Added Succesfully!!! Your Account number is " + data.caccount);
    this.createdFlag = true;
    this.router.navigate(['app-homepage']);
  }
 

}
