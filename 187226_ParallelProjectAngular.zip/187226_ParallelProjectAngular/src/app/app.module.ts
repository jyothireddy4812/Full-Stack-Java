import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MyServiceService } from './my-service.service';
import { OrderbyPipe } from './orderby.pipe';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositeAmountComponent } from './deposite-amount/deposite-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { HomepageComponent } from './homepage/homepage.component';
import { DisplayallComponent } from './displayall/displayall.component';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeAddComponent,
    OrderbyPipe,
    ShowBalanceComponent,
    DepositeAmountComponent,
    WithdrawAmountComponent,
    FundTransferComponent,
    MiniStatementComponent,
    HomepageComponent,
    DisplayallComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
