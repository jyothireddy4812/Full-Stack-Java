import { Component, OnInit } from '@angular/core';
import { MyServiceService, Transactions } from '../my-service.service';
import { Employee } from '../my-service.service';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  transactions: Transactions[] = [];
  employees: Employee[] = [];
  service: MyServiceService;


  constructor(service: MyServiceService) {
    this.service = service;
  }

  mini(data: any) {
    if(data.caccount=="" ||data.cpassword==""){
      alert("Please fill all Fields")
      return;
    }
    if (this.service.login(data)) {
      this.transactions = this.service.miniStatement(data);
    }
    else {
      alert("Invalid Account Number or Password")
    }
  }

  ngOnInit() {
    this.service.fetchTransactions();

    this.employees = this.service.getEmployees();

  }

}
