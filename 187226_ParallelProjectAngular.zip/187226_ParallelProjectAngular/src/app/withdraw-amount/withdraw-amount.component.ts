import { Component, OnInit } from '@angular/core';
import { MyServiceService, Employee, Transactions } from '../my-service.service';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {


  isLogin: boolean = true;
  employees: Employee[] = [];
  createdTransaction: Transactions;
isShowBalance=true;
cbalance1:number;
  service: MyServiceService;
  constructor(service: MyServiceService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  withdrawAmount(data: any) {
    if(data.caccount=="" ||  data.cpassword=="" ||data.cbalance ==""){
      alert("Please fill all Fields")
      return;
    }
    let tid: number;
    let caccount_first: number = data.caccount;
    let cbalance: number = data.cbalance;

    if (this.service.login(data)) {
      this.service.withdrawBalance(caccount_first, cbalance);

      this.createdTransaction = new Transactions(cbalance * 3 + 3866, data.caccount, "withdraw", data.cbalance);
      this.service.addTransaction(this.createdTransaction)
      this.cbalance1 = this.service.showBalance(data);
      this.isShowBalance = !this.isShowBalance;
    }
    else {
      alert("Invalid Account Number or Password");
    }
  }

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees = this.service.getEmployees();
  }
}
