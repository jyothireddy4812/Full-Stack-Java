import { Component, OnInit } from '@angular/core';
import { MyServiceService, Transactions } from '../my-service.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin: boolean = true;
  createdTransaction: Transactions;
  isShowBalance=true;
  cbalance1:number;
  service: MyServiceService;
  constructor(service: MyServiceService) {
    this.service = service;
    this.isLogin = this.service.isLogin;
  }

  fundTransfer(data: any) {
    if(data.caccount=="" || data.caccount1==""|| data.cpassword=="" ||data.cbalance ==""){
      alert("Please fill all Fields")
      return;
    }
    let caccount_first = data.caccount;
    let caccount_second = data.caccount1;
    let cbalance = data.cbalance;
    if (this.service.login(data)) {
      this.service.depositeBalance(caccount_second, cbalance);
      this.service.withdrawBalance(caccount_first, cbalance)

      this.createdTransaction = new Transactions(cbalance * 3 + 1562, caccount_first, "fund transfer", data.cbalance);
      this.service.addTransaction(this.createdTransaction)
      this.cbalance1 = this.service.showBalance(data);
      this.isShowBalance = !this.isShowBalance;
    }
    else {
      alert("Invalid Account Number or Password");
    }
  }

  ngOnInit() {
  }

}
