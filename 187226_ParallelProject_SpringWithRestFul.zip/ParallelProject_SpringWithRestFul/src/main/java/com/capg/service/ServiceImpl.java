package com.capg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.CustmerRepo;
import com.capg.dao.TransactionRepo;
import com.capg.entities.CustomerDetails;
import com.capg.entities.TransactionDetails;
import com.capg.exception.AccountNotFoundException;

@Service
public class ServiceImpl implements ServiceInterface {

	@Autowired
	CustmerRepo custRepo;

	@Autowired
	TransactionRepo transRepo;

	@Override
	public CustomerDetails createAccount(CustomerDetails customerDetails) throws AccountNotFoundException {
		if (customerDetails.getBal() == null || customerDetails.getBal() <= 0) {
			throw new AccountNotFoundException("Enter Minimum balance....Should be greater than Zero");
		} else {
			custRepo.save(customerDetails);
			return custRepo.findById(customerDetails.getAccNo()).get();
		}
	}

	@Override
	public CustomerDetails accountDetails(Long accNo) throws AccountNotFoundException {
		if (!custRepo.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			return custRepo.findById(accNo).get();
		}
	}

	@Override
	public Double showBalance(Long accNo) throws AccountNotFoundException {
		if (!custRepo.findById(accNo).isPresent()) {
			throw new AccountNotFoundException("Invalid account number!!!");
		} else {
			return custRepo.findById(accNo).get().getBal();
		}

	}

	@Override
	public Double depositAmount(Long accNo, Double amt) throws AccountNotFoundException {

		Optional<CustomerDetails> bank = custRepo.findById(accNo);
		if (bank.isPresent()) {
			CustomerDetails tempEntity = bank.get();
			tempEntity.setBal(bank.get().getBal() + amt);
			custRepo.save(tempEntity);
			TransactionDetails trans = new TransactionDetails(accNo, "Deposit", bank.get().getBal(),
					bank.get().getBal() + amt);
			transRepo.save(trans);
			return showBalance(accNo);
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double withdrawAmount(Long accNo, Double amt) throws AccountNotFoundException {
		Optional<CustomerDetails> bank = custRepo.findById(accNo);
		if (bank.isPresent()) {
			if (amt > showBalance(accNo)) {
				throw new AccountNotFoundException("Insufficient balance");
			} else {
				CustomerDetails tempEntity = bank.get();
				tempEntity.setBal(bank.get().getBal() - amt);
				custRepo.save(tempEntity);
				TransactionDetails trans = new TransactionDetails(accNo, "Withdraw", bank.get().getBal(),
						bank.get().getBal() - amt);
				transRepo.save(trans);
				return showBalance(accNo);
			}
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public Double fundTransfer(Long accNo, Double amt, Long accNo1) throws AccountNotFoundException {
		Optional<CustomerDetails> senderAcc = custRepo.findById(accNo);
		Optional<CustomerDetails> receiverAcc = custRepo.findById(accNo1);
		if (senderAcc.isPresent() && receiverAcc.isPresent()) {

			CustomerDetails sender = senderAcc.get();
			sender.setBal(senderAcc.get().getBal() - amt);
			custRepo.save(sender);

			CustomerDetails receiver = receiverAcc.get();
			receiver.setBal(receiverAcc.get().getBal() + amt);
			custRepo.save(receiver);

			TransactionDetails senderTrans = new TransactionDetails(accNo, "Amount transferred",
					senderAcc.get().getBal(), senderAcc.get().getBal() - amt);
			transRepo.save(senderTrans);

			TransactionDetails receiverTrans = new TransactionDetails(accNo1, "Amount received",
					receiverAcc.get().getBal(), amt + receiverAcc.get().getBal());
			transRepo.save(receiverTrans);

			return showBalance(accNo);
		} else {
			throw new AccountNotFoundException("Invalid account number!!!");
		}
	}

	@Override
	public List<TransactionDetails> printTransactions(Long accNo) {

		return transRepo.printTransactions(accNo);
	}
}
