package com.capg.service;

import java.util.List;

import com.capg.entities.CustomerDetails;
import com.capg.entities.TransactionDetails;
import com.capg.exception.AccountNotFoundException;

public interface ServiceInterface {

	CustomerDetails createAccount(CustomerDetails customerDetails) throws AccountNotFoundException;

	CustomerDetails accountDetails(Long accNo) throws AccountNotFoundException;

	Double showBalance(Long accNo) throws AccountNotFoundException;

	Double depositAmount(Long accNo, Double amt) throws AccountNotFoundException;

	Double withdrawAmount(Long accNo, Double amt) throws AccountNotFoundException;

	Double fundTransfer(Long accNo, Double amt, Long accNo1) throws AccountNotFoundException;

	List<TransactionDetails> printTransactions(Long accNo);
}
