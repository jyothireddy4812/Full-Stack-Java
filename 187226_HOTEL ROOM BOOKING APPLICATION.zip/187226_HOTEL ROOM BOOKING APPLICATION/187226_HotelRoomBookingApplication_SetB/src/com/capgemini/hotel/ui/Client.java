package com.capgemini.hotel.ui;

import java.util.Scanner;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.service.HotelService;

public class Client {
	static HotelService service = new HotelService();

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		int customerId = 0;
		String name;
		String mobileNo;
		String address;
		String email;
		String roomType;
		int roomNo;
		while (true) {
			Scanner sc = new Scanner(System.in);
			System.out.println("HOTEL ROOM BOOKING APPLICATION");
			System.out.println("1.BOOK ROOM");
			System.out.println("2.VIEW BOOKING DETAILS");
			System.out.println("3.EXIT");

			System.out.println("enter your choice");
			int choice = getOption(sc);
			switch (choice) {
			case 1:
				System.out.println("Enter customer name");
				name =service.validationName (sc.next());
				System.out.println("enter email");
				email = sc.next();
				System.out.println("enter address");
				address = sc.next();
				System.out.println("enter mobile number");
				mobileNo = service.validationMobileNo(sc.next());
				System.out.println("Enter Room number");
				roomNo = sc.nextInt();
				System.out.println("Enter Room type");
				roomType = sc.next();
				for (int i = 0; i < 5; i++) {
					customerId = customerId + (int) (Math.random() * 1000);
				}
				CustomerBean bean = new CustomerBean(customerId, name, mobileNo, address, email);
				CustomerBean bean1 = service.addCustomerDetails(bean);
				System.out.println("YOUR ROOM HAS BEEN SUCCESSFULLY BOOKED");
				System.out.println("YOUR Customer id: " + customerId);
				break;
			case 2:
				System.out.println("Enter customer id");
				customerId=service.validationCode(sc.nextInt());
				RoomBooking room2 = service.getBookingDetails(customerId);
				// System.out.println("Name of the customer :" + .getName());
				System.out.println("room no: " + room2.getRoomNo());
				System.out.println("room type :" + room2.getRoomType());
				break;
			case 3:
				System.out.println("THANK YOU");
				break;
			default:
				System.exit(0);
				sc.close();

			}
		}
	}
	private static int getOption(Scanner sc) {
		try {
			int option = sc.nextInt();
			return option;
		} catch (Throwable e) {
			System.out.println("Enter Valid choice");
		}
		return -1;
	}
}
