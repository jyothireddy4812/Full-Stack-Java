package com.capgemini.hotel.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public class CustomerBookingDAO implements ICustomerBookingDAO {
	Map<Integer, CustomerBean> customerDetails = new HashMap<>();
	Map<Integer, RoomBooking> roomBooking = new HashMap<>();

	public CustomerBookingDAO() {
		roomBooking.put(1, new RoomBooking(101, "AC_SINGLE"));
		roomBooking.put(2, new RoomBooking(102, "AC_SINGLE"));
		roomBooking.put(3, new RoomBooking(103, "AC_DOUBLE"));
		roomBooking.put(4, new RoomBooking(201, "NONAC_SINGLE"));
		roomBooking.put(5, new RoomBooking(202, "NONAC_SINGLE"));
		roomBooking.put(6, new RoomBooking(203, "NONAC_DOUBLE"));
	}

	@Override
	public CustomerBean addCustomerDetails(CustomerBean bean) {
		customerDetails.put(bean.getCustomerId(), bean);
		CustomerBean cust = (CustomerBean) customerDetails.get(bean.getCustomerId());
		return cust;
	}

	public RoomBooking getBookingDetails(int customerId) {

		RoomBooking room = (RoomBooking) roomBooking.get(customerId);
		return room;
	}

}