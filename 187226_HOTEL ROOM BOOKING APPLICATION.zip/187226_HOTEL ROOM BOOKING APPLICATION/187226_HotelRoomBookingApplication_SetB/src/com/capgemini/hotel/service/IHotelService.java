package com.capgemini.hotel.service;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public interface IHotelService {

	RoomBooking getBookingDetails(int customerId);

	CustomerBean addCustomerDetails(CustomerBean bean);
}
