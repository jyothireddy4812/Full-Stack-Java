package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capg.entities.TransactionDetails;

public interface TransactionRepo extends JpaRepository<TransactionDetails, Integer> {

	@Query("from TransactionDetails where accNo=?1")
	List<TransactionDetails> printTransactions(Long accNo);

}
