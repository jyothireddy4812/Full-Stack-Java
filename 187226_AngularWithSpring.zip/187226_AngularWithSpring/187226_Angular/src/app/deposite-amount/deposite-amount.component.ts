import { Component, OnInit, APP_INITIALIZER } from '@angular/core';
import { MyServiceService, Employee,} from '../my-service.service';


@Component({
  selector: 'app-deposite-amount',
  templateUrl: './deposite-amount.component.html',
  styleUrls: ['./deposite-amount.component.css']
})
export class DepositeAmountComponent implements OnInit {

  isLogin:boolean=true;
  employees:Employee[]=[];
  isShowBalance=true;
  service:MyServiceService;
  cbalance1:number;
  constructor(service:MyServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  depositeAmount(data:any){
    if(data.caccount=="" || data.caccount1==""|| data.cpassword=="" ||data.cbalance ==""){
      alert("Please fill all Fields")
      return;
    }
    let tid:number;
    let caccount_first:number=data.caccount;
    let cbalance:number=data.cbalance;
  
    if(this.service.login(data)){
    let ob=this.service.depositeBalance(caccount_first,cbalance);
    ob
    .subscribe((data1) => {
     
    },(error) => {
      console.log(error)
    })
   this.cbalance1=cbalance
 
    this.isShowBalance = false;
 
    }
    else{
      alert("Wrong Account Number or Password");
    }
  }


  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getEmployees();
  }

}
