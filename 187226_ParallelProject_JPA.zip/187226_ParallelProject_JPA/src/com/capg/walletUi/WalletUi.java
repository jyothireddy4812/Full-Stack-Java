package com.capg.walletUi;

import java.sql.SQLException;
import java.util.Scanner;


import com.capg.walletBeans.WalletBean;

import com.capg.walletService.WalletService;

//user interface to the user to connect with database
public class WalletUi {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Scanner sc = new Scanner(System.in);
		WalletService service = new WalletService();
		int i = 10000;
		while (true) {
			System.out.println("------------XYZ BANK-----------");
			System.out.println("******BANK WALLET APPLICATION*******");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT MONEY");
			System.out.println("4.WITHDRAW MONEY");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.print("Enter Your Choice : ");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.print("Enter  username : ");
				String userName = sc.next();
				userName += sc.nextLine();
				while (!service.validateName(userName)) {

					System.out.print("Enter username: ");
					userName = sc.next();
					userName += sc.nextLine();
				}
				System.out.print("Enter mobile number : ");
				long mobile = sc.nextLong();
				while (!service.validateMobile(mobile)) {
					System.out.print("Enter  mobile number : ");
					mobile = sc.nextLong();
				}
				System.out.print("Enter  password :");
				String password = sc.next();
				while (!service.validatePassword(password)) {
					System.out.print("Enter password :");
					password = sc.next();
				}
				String str = service.addAccount(userName, mobile, password);
				i++;
				System.out.print(" " + str +"\n");

				break;
			case 2:
				System.out.print("Enter Account number : ");
				long accNo = sc.nextLong();
				if (service.accCheck(accNo)) {
					System.out.print("Enter  Password : ");
					String pass = sc.next();
					if (service.passwordCheck(pass,accNo)) {
						long bal = service.getBalance(accNo);
						System.out.print("Available balance: " + bal + "/-"+"\n");
					}
				}

				break;
			case 3:
				System.out.print("Enter Account number : ");
				accNo = sc.nextLong();
				if (service.accCheck(accNo)) {
					System.out.print("Enter Password : ");
					String pass = sc.next();
					if (service.passwordCheck(pass,accNo)) {

						System.out.print("Enter the amount to be deposited :");
						long bal1 = sc.nextInt();
						long bal = service.getBalance(accNo) + bal1;
						service.setBalance(accNo, bal, "\nTransaction ID :" + i + ".....Amount deposited:" + bal1+"/-");
						i++;
						System.out.print("Amount  deposited: " + bal1 +"/-"+"\n");
						System.out.print("Available balance :" + service.getBalance(accNo) + "/-"+"\n");

					}
				}
				break;
			case 4:
				System.out.print("Enter Account number : ");
				accNo = sc.nextLong();
				if (service.accCheck(accNo)) {
					System.out.print("Enter  Password : ");
					String pass = sc.next();
					if (service.passwordCheck(pass,accNo)) {

						System.out.print(" Enter the amount to be withdrawn :");
						long bal1 = sc.nextInt();
						long bal = service.getBalance(accNo) - bal1;
						service.setBalance(accNo, bal, "\nTransaction ID : " + i + ".....Amount withdrawn :" + bal1+"/-");
						System.out.print("Amount withdrawn: " + bal1 + "/-"+"\n");
						System.out.print("Available balance :" + service.getBalance(accNo) +"/-"+ "\n");
						i++;
					}
				}
				break;
			case 5:
				System.out.print("Enter Account number :");
				accNo = sc.nextLong();
				if (service.accCheck(accNo)) {
					System.out.print("Enter Password :");
					String pass = sc.next();
					if (service.passwordCheck(pass,accNo)) {
						System.out.print("Enter Receiver's Account number : ");
						long accNo1 = sc.nextLong();
						if (service.accCheck(accNo1)) {
							long bal = service.getBalance(accNo);
							long bal1 = service.getBalance(accNo1);
							System.out.print("Enter the amount to be transferred :");
							long bal2 = sc.nextInt();
							service.setBalance(accNo, bal - bal2, "\nTransaction ID : " + i + ".....Amount debited:"
									+ bal2 + "/-"+  "To Account Number " + accNo1);
							service.setBalance(accNo1, bal1 + bal2, "\nTransaction ID :" + i + ".....Amount credited:"
									+ bal2 +"/-"+ " From Account Number " + accNo);
							System.out.print("Amount  transferred :" + bal2 +"/-"+ "\n");
							System.out.println("Available balance :" + service.getBalance(accNo) +"/-"+ "\n");
							i++;
						}
					}
				}
				break;
			case 6:
				System.out.print(" Enter Account number :");
				accNo = sc.nextLong();
				if (service.accCheck(accNo)) {
					System.out.print("Enter Password :");
					String password1 = sc.next();
					if (service.passwordCheck(password1,accNo)) {
						System.out.println("**PRINT TRANSACTIONS**");
						String str1 = service.getTransaction(accNo);
						System.out.print("  " + str1 + "\n");
						System.out.print("Available balance is Rs." + service.getBalance(accNo) +"/-"+ "\n");

					}
				}
				break;
	
			case 7:
				System.exit(0);
			default:
				System.out.println("Enter valid choice :");
				break;

			}

		}
	}
}