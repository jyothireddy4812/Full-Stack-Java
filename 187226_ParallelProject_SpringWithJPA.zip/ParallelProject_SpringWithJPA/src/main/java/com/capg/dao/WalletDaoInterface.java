package com.capg.dao;

import java.util.List;

import com.capg.entities.WalletBean;
import com.capg.entities.Transaction;

public interface WalletDaoInterface {
   boolean createAccount(WalletBean bank);
   int showBalance(long accountNo);
   int depositBalance(long accountNo, int deposit);
   int withdrawAmount(long accountNo, int withdraw) ;
   boolean fundTransfer(long accountNo, long accno, int amount);
   boolean validDetails(long accountNo,String password);
   public List<Transaction> getTransactions(long accountNo) ;
}
