package com.capg.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.entities.WalletBean;
import com.capg.entities.Transaction;

@Repository("dao")
@Transactional
public class WalletDao implements WalletDaoInterface {

	@PersistenceContext
	private EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	Random random = new Random();

	@Override
	public boolean createAccount(WalletBean wallet) {
		entityManager.persist(wallet);
		return true;
	}

	@Override
	public int showBalance(long accountNo) {
		WalletBean wallet = entityManager.find(WalletBean.class, accountNo);
		int balance = wallet.getBalance();
		return balance;
	}

	@Override
	public int depositBalance(long accountNo, int deposit) {
		WalletBean wallet = entityManager.find(WalletBean.class, accountNo);
		int bal = wallet.getBalance();
		int bal1 = bal + deposit;
		wallet.setBalance(bal1);

		Transaction tran = new Transaction();
		tran.setAmount(deposit);
		tran.setTransactionId(random.nextInt(100000));
		tran.setTransactionType("Deposit");
		tran.setWallet(wallet);

		entityManager.persist(tran);
		entityManager.merge(wallet);

		return bal1;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		WalletBean wallet = entityManager.find(WalletBean.class, accountNo);
		int availableBalance = wallet.getBalance();
		int updatedBalance = availableBalance - withdraw;
		wallet.setBalance(updatedBalance);

		Transaction transactionDetails = new Transaction();
		transactionDetails.setAmount(withdraw);
		transactionDetails.setTransactionId(random.nextInt(100000));
		transactionDetails.setTransactionType("Withdraw");
		transactionDetails.setWallet(wallet);
		entityManager.persist(transactionDetails);
		entityManager.merge(wallet);

		return updatedBalance;
	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean b = false;
		WalletBean wallet = entityManager.find(WalletBean.class, accountNo);
		WalletBean wallet1 = entityManager.find(WalletBean.class, accno);
		if (wallet.getBalance() <= amount) {
			b = false;
		} else {
			int availableBalance = wallet.getBalance();
			int availableBalance_1 = wallet1.getBalance();
			int updatedBalance = availableBalance_1 + amount;
			int updatedBalance_1 = availableBalance - amount;

			wallet1.setBalance(updatedBalance);
			Transaction transactionDetails_2 = new Transaction();
			transactionDetails_2.setAmount(amount);
			transactionDetails_2.setTransactionId(random.nextInt(100000));
			transactionDetails_2.setTransactionType("Fund transfer");
			transactionDetails_2.setWallet(wallet1);
			transactionDetails_2.setFromAccount(accno);
			entityManager.persist(transactionDetails_2);

			wallet.setBalance(updatedBalance_1);
			Transaction transactionDetails_3 = new Transaction();
			transactionDetails_3.setAmount(amount);
			transactionDetails_3.setTransactionId(random.nextInt(100000));
			transactionDetails_3.setTransactionType("fund transfer");
			transactionDetails_3.setWallet(wallet);
			transactionDetails_3.setFromAccount(accountNo);
			entityManager.persist(transactionDetails_3);
			b = true;
		}
		return b;
	}

	@Override
	public boolean validDetails(long accountNo, String password) {
		boolean b = false;
		WalletBean wallet1 = entityManager.find(WalletBean.class, accountNo);
		if (wallet1 == null) {
			b = false;
		} else {
			String pass = wallet1.getPassword();
			//System.out.println(pass);
			if (password.equals(pass)) {
				b = true;
			} else {
				b = false;
			}
		}
		return b;
	}

	@Override
	public List<Transaction> getTransactions(long accountNo) {
		WalletBean wallet = entityManager.find(WalletBean.class, accountNo);
		TypedQuery<Transaction> query = entityManager.createQuery("Select t from Transaction as t where t.wallet=:wallet",
				Transaction.class);
		query.setParameter("wallet", wallet);
		List<Transaction> list = query.getResultList();
		return list;
	}

}