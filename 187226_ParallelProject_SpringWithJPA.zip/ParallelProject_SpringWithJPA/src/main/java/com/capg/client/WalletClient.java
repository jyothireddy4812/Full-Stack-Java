package com.capg.client;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capg.entities.Transaction;
import com.capg.service.WalletService;


public class WalletClient {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		WalletService service = context.getBean("service", WalletService.class);
		String choice;
		int click, balance;
		String name, password, mblNo;
		Random random = new Random();
		while (true) {
			System.out.println("**********XYZ BANK WALLET APPLICATION***************");

			System.out.println("1. Create account");
			System.out.println("2. Show balance");
			System.out.println("3. Deposit balance");
			System.out.println("4. Withdraw money");
			System.out.println("5. Fund transfer");
			System.out.println("6. Mini Statement");
			System.out.println("7. Exit");
			System.out.println("\nEnter Your choice : ");
			choice = scanner.next();

			if (choice.matches("[a-z]*") || choice.matches("[A-Z]*")) {
				System.out.println("Invalid Choice!!!");
				main(null);
			}
			switch (choice) {
			case "1":
				System.out.println("Welcome to XYZ BANK WALLET Application");
				do {
					System.out.println("Enter your name : ");
					name = scanner.next();
					click = service.checkName(name);
				} while (click != 1);
				do {
					System.out.println("Enter your mobile number : ");
					mblNo = scanner.next();
					click = service.validMobile(mblNo);
				} while (click != 1);
				@SuppressWarnings("unused")
				long phone = Long.parseLong(mblNo);
				long accountNo = random.nextInt(1000000);
				do {
					System.out.println("Enter your password : ");
					password = scanner.next();
					click = service.checkPassword(password);
				} while (click != 1);
				balance = 100000;
				boolean result = service.createAccount(name, mblNo, password, accountNo, balance);
				if (result) {
					System.out.println("Successfully created");
					System.out.println("Your account number: " + accountNo);
				}
				break;
			case "2":
				System.out.println("Enter your account number : ");
				accountNo = scanner.nextLong();
				System.out.println("Enter your password : ");
				password = scanner.next();
				boolean b1 = service.validDetails(accountNo, password);
				if (b1) {
					balance = service.showBalance(accountNo);
					if (balance != 0) {
						System.out.println("Available balance : " + balance);
					} else {
						System.out.println("Something Went Wrong!!!");
					}
				} else {
					System.out.println("Invalid account number or password");
				}
				break;
			case "3":
				System.out.println("Enter your account number : ");
				accountNo = scanner.nextLong();
				System.out.println("Enter your password : ");
				password = scanner.next();
				boolean b = service.validDetails(accountNo, password);
				if (b) {
					System.out.println("Enter the amount for deposit : ");
					int deposit = scanner.nextInt();
					balance = service.depositAmount(accountNo, deposit);
					System.out.println("Successfully deposited");
					System.out.println("Available balance : " + balance);
				} else {
					System.out.println("Invalid account number or password");
				}
				break;
			case "4":
				System.out.println("Enter your account number : ");
				accountNo = scanner.nextLong();
				System.out.println("Enter your password : ");
				password = scanner.next();
				b = service.validDetails(accountNo, password);
				if (b) {
					balance = service.showBalance(accountNo);
					System.out.println("Available balance: " + balance);
					System.out.println("Enter the amount for withdraw: ");
					int withdraw = scanner.nextInt();
					balance = service.withdrawAmount(accountNo, withdraw);
					if (balance >= 0) {
						System.out.println("Successfully withdrawn:");
						System.out.println("Available balance : " + balance);
					} else {
						System.out.println("Insufficient Funds!!!...");
					}
				} else {
					System.out.println("Invalid account number or password");
				}
				break;
			case "5":
				System.out.println("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.println("Enter the password: ");
				password = scanner.next();
				b = service.validDetails(accountNo, password);
				if (b) {
					System.out.println("Enter the account number to be transfer: ");
					long accno = scanner.nextLong();
					System.out.println("Enter the amount to be transfer: ");
					int amount = scanner.nextInt();
					boolean transfer = service.fundTransfer(accountNo, accno, amount);
					if (transfer) {
						System.out.println("Successfully transferred");
					} else {
						System.out.println("Something Went Wrong!!!...");
					}
				} else {
					System.out.println("Invalid account number or password");
				}
				break;
			case "6":
				System.out.println("Enter your account number: ");
				accountNo = scanner.nextLong();
				System.out.println("Enter your password: ");
				password = scanner.next();
				b = service.validDetails(accountNo, password);
				if (b) {
					List<Transaction> list = service.getTransaction(accountNo);
					System.out.println("******************Mini Statement************************");
					for (Transaction tran : list) {
						System.out.println(tran);
					}
				} else {
					System.out.println("Invalid account number or password");
				}
				break;
			case "7":
				System.out.println("Thank you for using our services!!!");

				System.exit(0);
			}
		}
	}
}
