package com.capg.service;

import java.util.List;

import com.capg.entities.Transaction;

public interface WalletServiceInterface {
	public boolean createAccount(String name, String phoneNo, String password, long accountNo, int balance);

	public int showBalance(long accountNo);

	public int depositAmount(long accountNo, int deposit);

	public int withdrawAmount(long accountNo, int withdraw);

	public boolean fundTransfer(long accountNo, long accno, int amount);

	public boolean validDetails(long accountNo, String password);

	public List<Transaction> getTransaction(long accountNo);

	public int checkPassword(String password);

	public int checkBalance(int balance);

	int validMobile(String phoneNo);

	int checkName(String name);

}
