package com.capg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.dao.WalletDao;
import com.capg.entities.WalletBean;
import com.capg.entities.Transaction;

class MyException extends Exception {
	private static final long serialVersionUID = 1L;
	String s1;

	MyException(String s) {
		s1 = s;
	}

	public String toString() {
		return (s1);
	}
}

@Service("service")
public class WalletService implements WalletServiceInterface {
	int balance;
	@Autowired
	private WalletDao dao;

	@Override
	public boolean createAccount(String name, String phoneNo, String password, long accountNo, int balance) {
		WalletBean bank = new WalletBean();
		bank.setName(name);
		bank.setPhoneNo(phoneNo);
		bank.setPassword(password);
		bank.setAccountNo(accountNo);
		bank.setBalance(balance);
		boolean result = dao.createAccount(bank);
		return result;
	}

	@Override
	public int showBalance(long accountNo) {
		balance = dao.showBalance(accountNo);
		return balance;
	}

	@Override
	public int depositAmount(long accountNo, int deposit) {
		int balance;
		balance = dao.depositBalance(accountNo, deposit);
		return balance;
	}

	@Override
	public int withdrawAmount(long accountNo, int withdraw) {
		int balance;
		balance = dao.withdrawAmount(accountNo, withdraw);
		return balance;
	}

	@Override
	public boolean fundTransfer(long accountNo, long accno, int amount) {
		boolean fund = dao.fundTransfer(accountNo, accno, amount);
		return fund;
	}

	@Override
	public boolean validDetails(long accountNo, String password) {
		boolean b = dao.validDetails(accountNo, password);
		return b;
	}

	@Override
	public List<Transaction> getTransaction(long accountNo) {
		List<Transaction> list = dao.getTransactions(accountNo);
		return list;
	}

	public int checkPassword(String password) {
		try {
			if (password.length() >=8)
				return 1;
			else
				throw new MyException("Password should contain minimum 8 characters");
		} catch (MyException e) {
			System.out.println(e);
		}
		return 0;
	}

	@Override
	public int checkBalance(int balance) {
		if (balance >= 1000)
			return 1;
		else
			return 0;
	}

	@Override
	public int validMobile(String phoneNo) {
		try {
			if (phoneNo.matches("[6-9][0-9]{9}"))
				return 1;
			else
				throw new MyException("Please Enter Valid Mobile Number");
		} catch (MyException e) {
			System.out.println(e);
		}
		return 0;
	}

	@Override
	public int checkName(String name) {
		try {
			if (name.matches("[A-Z][a-zA-Z]*"))
				return 1;
			else
				throw new MyException("Name should be starts with capital letter");
		} catch (MyException e) {
			System.out.println(e);
		}
		return 0;
	}

}