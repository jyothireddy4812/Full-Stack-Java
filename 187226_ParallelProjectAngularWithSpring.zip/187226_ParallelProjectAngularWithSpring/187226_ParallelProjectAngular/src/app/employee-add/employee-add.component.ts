import { Component, OnInit } from '@angular/core';
import { Employee, MyServiceService } from '../my-service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {



  router: Router;
  createdFlag: boolean = false;
accNo:number;
  service: MyServiceService;

  constructor(service: MyServiceService, router: Router) {
    this.service = service;
    this.router = router;
  }

  ngOnInit() {
  }

  add(data: any) {
    if(data.cname=="" || data.cphone==""|| data.cpassword=="" ){
      alert("Please fill all fields")
      return;
    }
    let caccount=parseInt("20"+Math.random()*1000)+1000
    data.cbalance = 5000;
    let tran="Rs. 1000         Deposited"
    let createdEmployee = new Employee(caccount, data.cname, data.cphone, data.cpassword, tran, data.cbalance);

    var add = this.service.add(createdEmployee);
    add.subscribe((data)=>{
    alert("Added Succesfully!!! Your Account number is " + data.accNo);
    })

   
    this.createdFlag = true;
    this.service.fetchEmployees();
  
   // open("app-homepage");
    
   this.router.navigate(['app-homepage']);
  }
 

}
