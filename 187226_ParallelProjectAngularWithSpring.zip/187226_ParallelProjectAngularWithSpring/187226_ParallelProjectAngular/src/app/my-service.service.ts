import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http: HttpClient;
  isLogin: boolean = true;
  employees: Employee[] = [];
  public API = '//localhost:3489';
  public CAR_API = this.API + '/bank';

  loginAcc: number;
  constructor(http: HttpClient) {
    this.http = http;
    this.fetchEmployees();

  }

  fetched: boolean = false;
  fetchedT: boolean = false;

  fetchEmployees() {
    this.http.get('//localhost:3489/bank/viewAll')
      .subscribe
      (
      data => {
        if (!this.fetched) {
          this.convert(data);
          this.fetched = true;
        }
      }
      );
  }

  getEmployees(): Employee[] {
    return this.employees;
  }

  convert(dataE1: any):number {
    let dataE:any;
    this.http.get(this.CAR_API + '/viewAll'  ).subscribe((data=> dataE=data))
    let e;
    for (let o of dataE1) {
      e = new Employee(o.accNo, o.name, o.mobile, o.password, o.tran, o.balance);
      this.employees.push(e);
      console.log(o.accNo)
     
    }
    return e.accNo
  }



  delete(caccount: number) {
    let foundIndex: number = -1;
    for (let i = 0; i < this.employees.length; i++) {
      let e = this.employees[i];
      if (this.loginAcc == e.accNo) {
        foundIndex = i;
        break;
      }
    }
    this.employees.splice(foundIndex, 1);
  }

  add(e: Employee) :Observable<any>{

    //this.employees.push(e);
   return this.http.post(this.CAR_API + '/create', e);
    //   (
    //   data => {
    //     if (!this.fetched) {
    //       let accNo=this.convert(data);
          
    //   console.log(accNo)
    //       return accNo
       
    //       this.fetched = true;
    //     }
    //   }
    //   );
    // this.fetchEmployees();
    // return ;
  }


  showBalance(data: Employee): Observable<any>  {
    let caccount = this.loginAcc;
    for (let i = 0; i < this.employees.length; i++) {
      if (caccount == this.employees[i].accNo) {

        return this.http.get(this.CAR_API + '/showBalance2/' + this.employees[i].accNo);
        
      } else {
        continue;
      }

    }
    alert("Account No does not matched!")

  }
  mini(data: any): Observable<any> {
    let a: any;
    for (let i = 0; i < this.employees.length; i++) {
      if (data.caccount == this.employees[i].accNo) {
        console.log("reach here")
        //console.log(data)
        return this.http.get(this.CAR_API + '/printTran2/' + this.employees[i].accNo);

      } else {
        continue;
      }

    }
    alert("Account No does not matched!")
  }
  depositeBalance(caccount_first: number, cbalance: any) :Observable<any>{
    console.log(caccount_first, cbalance)
    console.log(typeof (cbalance))

    for (let a of this.employees) {

      if (caccount_first == a.accNo) {
        return this.http.put(this.CAR_API + '/deposit/' + caccount_first + "/" + cbalance, a)
      

      } else {
        continue;
      }
      
    }
    alert("Account No does not matched!")
  }

  withdrawBalance(caccount_first: number, cbalance: number) {


    for (let i = 0; i < this.employees.length; i++) {
      if (caccount_first == this.employees[i].accNo) {
        this.http.put(this.CAR_API + '/withdraw/' + caccount_first + "/" + cbalance, this.employees[i]).subscribe
          (
          data => {
            if (!this.fetched) {
              this.convert(data);
              this.fetched = true;
            }
          }
          );
        break;
      }
    }
  }
  fundTransfer(caccount_first: number,caccount_second:number, cbalance: number) {


    for (let i = 0; i < this.employees.length; i++) {
      if (caccount_first == this.employees[i].accNo) {
        this.http.put(this.CAR_API + '/fundTransfer/' + caccount_first + "/" +caccount_second+"/"+ cbalance, this.employees[i]).subscribe
          (
          data => {
            if (!this.fetched) {
              this.convert(data);
              this.fetched = true;
            }
          }
          );
        break;
      }
    }
  }
  update(data: Employee) {
    let caccount = data.accNo;
    for (let i = 0; i < this.employees.length; i++) {
      if (caccount === this.employees[i].accNo) {
        this.employees[i].name = data.name;
        this.employees[i].balance = data.balance;
        break;
      }
    }
  }

  login(data: any): boolean {
    this.fetchEmployees();
    let caccount = data.caccount;
    let cpassword = data.cpassword;;
    this.loginAcc = caccount;

    for (let a of this.employees) {

      if (caccount == a.accNo && cpassword == a.password) {

        this.isLogin = !this.isLogin;
        return true;

      } else {
        continue;
      }

    }
    return false;
  }

  search(caccount: number): Employee[] {
    let resultEmp: Employee[] = [];
    let o: Employee;
    var flag = 0;
    for (let i = 0; i < this.employees.length; i++) {
      if (caccount == o.accNo) {
        resultEmp.push(o);
        alert("ID : " + o.accNo + "Name :" + o.name);
        flag = 1;
        break;
      }
    }
    if (flag == 0) {
      alert("No data Exist!");
    }
    return resultEmp;
  }
}

export class Employee {
  accNo: number;
  name: String;
  mobile: number;
  balance: number;
  password: String;
  tran: String;
  password1: String;

  constructor(caccount: number, cname: string, cphone: number, cpassword: string, tran: string, cbalance: number) {
    this.balance = cbalance;
    this.accNo = caccount;
    this.name = cname;
    this.mobile = cphone;
    this.password = cpassword;
    this.tran = tran;
  }
}

/*export class Transactions {
  tid: number;
  taccount_sender: number;
  taccount_reciver: String;
  tamount: number;


  constructor(tid: number, taccount_sender: number, taccount_reciver: String, tamount: number) {
    this.tid = tid;
    this.taccount_sender = taccount_sender;
    this.taccount_reciver = taccount_reciver;
    this.tamount = tamount;
  }
}*/