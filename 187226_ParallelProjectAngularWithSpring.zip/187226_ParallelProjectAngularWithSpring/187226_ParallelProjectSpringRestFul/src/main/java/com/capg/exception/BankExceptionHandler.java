package com.capg.exception;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class BankExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(BankException.class)
	public ResponseEntity<String> handleException(Exception ex) {
		Map<String, Object> body = new LinkedHashMap<>();
		body.put("timestamp", new Date()+"");
		body.put("message", "Wrong account ID\n");
		return new ResponseEntity<String>(body +"\n", HttpStatus.CONFLICT);

	}

	
}
