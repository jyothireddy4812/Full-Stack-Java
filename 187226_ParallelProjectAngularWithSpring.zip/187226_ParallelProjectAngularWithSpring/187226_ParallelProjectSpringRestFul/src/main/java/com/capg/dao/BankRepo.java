package com.capg.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.capg.bean.BankBean;

@Repository
@CrossOrigin(origins = "http://localhost:4200")
public interface BankRepo extends JpaRepository<BankBean, Long> {

}
