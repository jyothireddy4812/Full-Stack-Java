package com.capg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.BankBean;
import com.capg.dao.BankRepo;
import com.capg.exception.BankException;


@Service
public class BankServiceImpl implements BankService {
	@Autowired
	BankRepo bankRepo;

	@Autowired
	BankService bankService;

	@Override
	public List<BankBean> getAllAccounts() throws BankException{
		// TODO Auto-generated method stub
		try {
			return bankRepo.findAll();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public BankBean createAccount(@Valid BankBean pro)throws BankException {
		// TODO Auto-generated method stub
		try {
			pro.setBalance(1000);
			
			pro.setTran("Account Balance: Rs.100000 ");
			bankRepo.save(pro);
			return pro;
		
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public BankBean getAccountByAccNo(@Valid long acc)throws BankException {
		// TODO Auto-generated method stub
		try {
			return bankRepo.findById(acc).get();
		} catch (Exception ex) {
			throw new BankException(ex.getMessage());
		}
	}

	@Override
	public String getTransaction(@Valid long acc)throws BankException {
		// TODO Auto-generated method stub
		try {Optional<BankBean> optional=bankRepo.findById(acc);
		
		BankBean product=optional.get();
		String s=product.getTran();
			return s;
		} catch (Exception ex) {
			throw new BankException(ex.getMessage());
		}
	}

	@Override
	public List<BankBean> deleteAccount(@Valid long acc) throws BankException{
		// TODO Auto-generated method stub
		try {
			bankRepo.deleteById(acc);
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
		return bankRepo.findAll();

	}

	@Override
	public BankBean depositMoney(@Valid long acc,@Valid long amount, @Valid BankBean pro)throws BankException {
		// TODO Auto-generated method stub
		try{Optional<BankBean> optional=bankRepo.findById(acc);
		
		BankBean product=optional.get();
		product.setName(pro.getName());
		product.setMobile(pro.getMobile());
		product.setPassword(pro.getPassword());
		long bal=product.getBalance();
		long bal2=bal+amount;
		product.setBalance(bal2);
		String tran=product.getTran();
		
		product.setTran(tran+"Deposit:Rs."+ amount+"/-");
		bankRepo.save(product);
		return product;
	

	
	} catch (Exception e) {
		throw new BankException(e.getMessage());
	}
	}

	@Override
	public BankBean withDrawMoney(@Valid long acc, @Valid long amount,@Valid BankBean pro) throws BankException{
		// TODO Auto-generated method stub
		try{Optional<BankBean> optional=bankRepo.findById(acc);
	
			BankBean product=optional.get();
			product.setName(pro.getName());
			product.setMobile(pro.getMobile());
			product.setPassword(pro.getPassword());
			long bal=product.getBalance();
			long bal2=bal-amount;
			product.setBalance(bal2);
			String tran=product.getTran();
			product.setTran(tran+"-------/nWithdrawn amount:Rs."+ amount+"/-");
		bankRepo.save(product);
			return product;
		

		
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public long getBalance(@Valid long acc) throws BankException {
		// TODO Auto-generated method stub
		try {
			Optional<BankBean> optional=bankRepo.findById(acc);
			
			BankBean product=optional.get();
			long bal= product.getBalance();
			return bal;
		} catch (Exception ex) {
			throw new BankException("Invalid");
		}
	}

	@Override
	public List<BankBean> transferMoney(@Valid long acc, @Valid long acc1,@Valid long amount)throws BankException {
		// TODO Auto-generated method stub
		try{Optional<BankBean> optional=bankRepo.findById(acc);
		Optional<BankBean> optional1=bankRepo.findById(acc1);
		BankBean product=optional.get();
		BankBean product1=optional1.get();
		product.setName(product.getName());
		product.setMobile(product.getMobile());
		product.setPassword(product.getPassword());
		long bal=product.getBalance();
		long bal2=bal-amount;
		product.setBalance(bal2);
		String tran=product.getTran();
		long aNum=product.getAccNo();
		product.setTran(tran+"Transferred:Rs."+ amount+"/-");
		
		
		bankRepo.save(product);
		product1.setName(product1.getName());
		product1.setMobile(product1.getMobile());
		product1.setPassword(product1.getPassword());
		long bal4=product1.getBalance();
		long bal3=bal4+amount;
		product1.setBalance(bal3);
		String tran2=product1.getTran();
	
		product1.setTran(tran2+""+product.getAccNo()+"/n"+"Received amount Rs."+ amount+"/- ");
		
		bankRepo.save(product1);
		List<BankBean> l1 =new ArrayList<BankBean>() ;
		l1.add(product);
		l1.add(product1);
		return l1;
	

	
	} catch (Exception e) {
		throw new BankException(e.getMessage());
	}
	}

	@Override
	public BankBean getTransaction2(@Valid long acc) throws BankException {
		// TODO Auto-generated method stub
try {Optional<BankBean> optional=bankRepo.findById(acc);
		
		BankBean product=optional.get();
		
			return product;
		} catch (Exception ex) {
			throw new BankException(ex.getMessage());
		}
		
	}

	@Override
	public BankBean getBalance2(@Valid long acc) throws BankException {
		// TODO Auto-generated method stub
		try {
			Optional<BankBean> optional=bankRepo.findById(acc);
			
			BankBean product=optional.get();
			
			return product;
		} catch (Exception ex) {
			throw new BankException("Invalid");
		}
	}

	

}
