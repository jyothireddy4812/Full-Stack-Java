package com.capg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.BankBean;
import com.capg.exception.BankException;
import com.capg.service.BankService;

//This is the main controller .
@RestController

@RequestMapping("/bank")
public class BankController {
	// This Creates a StockService Interface automatically
	@Autowired
	BankService bankService;

	// It will view all the entries from database
	@RequestMapping("/viewAll")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<BankBean> getAllAccounts() throws BankException {
		return bankService.getAllAccounts();
	}

	// It will create new account in database
	@PostMapping(value = "/create")
	@CrossOrigin(origins = "http://localhost:4200")
	public BankBean createAccount(@Valid @RequestBody BankBean pro) throws BankException {
		return bankService.createAccount(pro);
	}

	
	@GetMapping("/printInfo/{acc}")
	@CrossOrigin(origins = "http://localhost:4200")
	public BankBean getAccountByAccNo(@Valid @PathVariable long acc) throws BankException {
		return bankService.getAccountByAccNo(acc);
	}

	@GetMapping("/printTran/{acc}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<String> getTransaction(@Valid @PathVariable long acc) throws BankException {
		String s=bankService.getTransaction(acc);
		return new ResponseEntity<String> (s,HttpStatus.OK);
	}
	@GetMapping("/printTran2/{acc}")
	@CrossOrigin(origins = "http://localhost:4200")
	public BankBean getTransaction2(@Valid @PathVariable long acc) throws BankException {
		BankBean s=bankService.getTransaction2(acc);
		return  s ;
	}


	@GetMapping("/showBalance/{acc}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<String> getBalance(@Valid @PathVariable long acc) throws BankException {
		long l=bankService.getBalance(acc);
		return new ResponseEntity<String> ("Your Account Balance is Rs."+l,HttpStatus.OK);
		
	}
	
	@GetMapping("/showBalance2/{acc}")
	@CrossOrigin(origins = "http://localhost:4200")
	public BankBean getBalance2(@Valid @PathVariable long acc) throws BankException {
		BankBean bb=bankService.getBalance2(acc);
		return bb;
		
	}


	@DeleteMapping("/delete/{acc}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<BankBean> deleteAccount(@Valid @PathVariable long acc) throws BankException {
		return bankService.deleteAccount(acc);

	}

	@PutMapping("/deposit/{acc}/{amount}")
	@CrossOrigin(origins = "http://localhost:4200")
	public BankBean depositMoney(@Valid @PathVariable long acc, @Valid @PathVariable long amount,
			@Valid @RequestBody BankBean pro) throws BankException {
		return bankService.depositMoney(acc, amount, pro);
	}

	
	@PutMapping("/withdraw/{acc}/{amount}")
	@CrossOrigin(origins = "http://localhost:4200")
	public BankBean withdrawMoney(@Valid @PathVariable long acc, @Valid @PathVariable long amount,
			@Valid @RequestBody BankBean pro) throws BankException {
		return bankService.withDrawMoney(acc, amount, pro);
	}

	
	@PutMapping("/fundTransfer/{acc}/{acc1}/{amount}")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<BankBean> transferMoney(@Valid @PathVariable long acc, @Valid  @PathVariable long acc1 ,@Valid  @PathVariable long amount )
			throws BankException {
		return bankService.transferMoney(acc, acc1,amount);
	} 
	 
}