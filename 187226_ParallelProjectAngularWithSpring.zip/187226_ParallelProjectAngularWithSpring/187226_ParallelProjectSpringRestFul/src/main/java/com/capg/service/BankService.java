package com.capg.service;

import java.util.List;

import javax.validation.Valid;

import com.capg.bean.BankBean;
import com.capg.exception.BankException;

public interface BankService {
	
	public List<BankBean> getAllAccounts() throws BankException;
	public BankBean createAccount(@Valid BankBean pro)throws BankException;
	public BankBean getAccountByAccNo(@Valid long acc)throws BankException;
	public String getTransaction(@Valid long acc)throws BankException;
	public List<BankBean> deleteAccount(@Valid long acc)throws BankException;
	public BankBean depositMoney(@Valid long acc, @Valid long amount,@Valid BankBean pro)throws BankException;
	public BankBean withDrawMoney(@Valid long acc, @Valid long amount,@Valid BankBean pro)throws BankException;
	public long getBalance(@Valid long acc) throws BankException;
	public List<BankBean> transferMoney(@Valid long acc, @Valid long acc1,@Valid long amount) throws BankException;
	public BankBean getTransaction2(@Valid long acc)throws BankException;
	public BankBean getBalance2(@Valid long acc) throws BankException;
	

}
