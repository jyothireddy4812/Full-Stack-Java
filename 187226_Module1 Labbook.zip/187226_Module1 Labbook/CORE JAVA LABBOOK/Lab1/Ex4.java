package Lab1;

import java.util.Scanner;

public class Ex4 {
public static void main(String[] args) {
	int n,sum ;
	Scanner sc=new Scanner(System.in);
	 n=sc.nextInt();
	 Ex4 e=new Ex4();
	 boolean c=e.checkNumber(n);
	System.out.println(c);
}

public static boolean checkNumber(int n) {
for(int i=2;i<=n;i++)
{
	if(n==Math.pow(2,i))
		return true;

}
return false;
}
}

