package lab5;

import java.util.Scanner;

public class Ex3 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the number");
	int x=sc.nextInt();
	sc.close();
	for(int i=2;i<x;i++) {
		if(isPrime(i)) {
			System.out.println(i);
		}
	}
	
}

private static boolean isPrime(int i) {
	if(i<=1) {
	return false;
}
	for(int i1=2;i1<=Math.sqrt(i);i1++) {
		if(i%i1==0) {
			return false;
		}
	}
	
return true;

}}


