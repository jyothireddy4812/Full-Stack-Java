
package lab5;

import java.util.Scanner;

class Age extends RuntimeException {
	int age;
	public String toString() {
		
		return "ur not eligible"+age;
	}

}
public class Ex5{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the age");
		int age=sc.nextInt();
	
		sc.close();

	if(age<15) {
		throw new Age();
		
	}
	else {
		System.out.println("age:" +age);
	}
	}}

