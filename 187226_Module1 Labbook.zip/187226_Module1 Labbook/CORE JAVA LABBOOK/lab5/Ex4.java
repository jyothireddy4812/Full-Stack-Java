package lab5;

import java.util.Scanner;

class EmptyName extends RuntimeException {
	String name;
	public String toString() {
		
		return " pls enter name"+name;
	}

}
public class Ex4{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the first name");
		String firstname=sc.nextLine();
		System.out.println("enter the last name");
		String lastname=sc.nextLine();
		sc.close();
		int f= firstname.length();
		int l= lastname.length();
	if(f==0||l==0) {
		throw new EmptyName();
		
	}
	else {
		System.out.println("fullname:" +firstname+ lastname);
	}
	}
}
