package lab5;

import java.util.Scanner;

public class Ex2{
public static void main(String[] args) {
	int x = 1,y = 0,z;      //non recursive
	Scanner sc=new Scanner(System.in);
	System.out.println("enter number");
	int n=sc.nextInt();
	sc.close();
	for(int i=1;i<=n;i++) {
		z=x+y;
		System.out.println(z);
	
		x=y;
		y=z;
		
	}
	System.out.println("****************************");
	for(int j=1;j<=n;j++) {       //recursive    
		System.out.println(f(j));
	}
	
Ex2.f(n);

}
static int f(int n) {
	if(n==0||n==1)
		return n;
	else {
	
	return (f(n-1)+f(n-2));
}
}}
