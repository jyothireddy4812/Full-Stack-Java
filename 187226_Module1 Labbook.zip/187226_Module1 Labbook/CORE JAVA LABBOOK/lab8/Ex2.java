package lab8;

import java.io.*;
public class Ex2 {
public static void main(String[] args) throws IOException {
	File f1=new File("CAPGEMINI.txt");
	f1.createNewFile();
PrintWriter pw=new PrintWriter(f1);
pw.println(1000);
pw.println("EMPLOYEES");
pw.println("JYOTHIREDDY");
pw.println("CAPGEMINI");
pw.println("12345");
char [] ch1={'s','s','t'};
pw.write(ch1);
pw.close();
FileReader f=new FileReader(f1);
BufferedReader b=new BufferedReader(f);
int k=1;
String line=b.readLine();
while(line!=null)
{
System.out.println(k+" "+line);
line=b.readLine();
k++;
}
b.close();
}
}