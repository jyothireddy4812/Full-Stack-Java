package lab3;

import java.util.Scanner;

public class Ex4 {
static void occurence(String str)
{
	int count[]=new int [500];
	int len=str.length();
	for(int i=0;i<len;i++)
	{
		count[str.charAt(i)]++;
	}
	char ch[]=new char[str.length()];
	for(int i=0;i<len;i++)
	{
		ch[i]=str.charAt(i);
		int f=0;
		for(int j=0;j<=i;j++)
		{
			if(str.charAt(i)==ch[j])
				f++;
		}
		if(f==1)
			System.out.println("Number of Occurence of "+str.charAt(i)+" is:"+count[str.charAt(i)]);
	}
}
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter a string");
	String str=s.nextLine();
	occurence(str);
	s.close();
}
}