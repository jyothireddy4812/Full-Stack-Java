package lab3;

import java.util.Scanner;

public class Ex1 {
	 
	public static void main(String args[]){
	    Scanner sc=new Scanner(System.in);
	    int n=sc.nextInt();
	    int[] arr=new int[n];
	    for(int i=0;i<n;i++) {
	    	arr[i]=sc.nextInt();
	}
	   Ex1 e=new Ex1();
	   int d=e.getSecondSmallest(arr);
       System.out.println(d);
       sc.close();
}
	
public int getSecondSmallest(int[] arr) {
	
	      int temp = 0,d1=0  ;
		
		for(int i = 0; i<arr.length; i++ ){
	         for(int j = 1; j<arr.length; j++){
	            if(arr[i]<arr[j]){
	               temp = arr[i];
	               arr[i] = arr[j];
	               arr[j] = temp;
	            }
	         }
	      }
	     d1=arr[2];
	     return d1;
	   }
	}