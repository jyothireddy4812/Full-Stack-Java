package lab9;

import java.util.*;

public class Ex3 {
public static void main(String[] args) {
	int array[]= {1,2,3,4,5,6,7,8,9,10,11,12};
	HashMap<Integer,Integer>h=new HashMap<Integer,Integer>();
	h=getSquares(array);
	System.out.println(h);
}
static HashMap<Integer, Integer> getSquares(int[] array)
{
HashMap<Integer,Integer> h1=new HashMap<Integer,Integer>();
for(int value:array)
{
	if(!h1.containsKey(value)) {
		h1.put(value, value*value);
	}
}
return h1;

}
}