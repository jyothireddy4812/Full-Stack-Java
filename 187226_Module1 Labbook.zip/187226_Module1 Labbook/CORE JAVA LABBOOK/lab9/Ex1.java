package lab9;

import java.util.*;
class Details{
	int empId;
	String empName;
	public Details(int aid,String aname) {
		// TODO Auto-generated constructor stub
		empId=aid;
		empName=aname;
	}
	public String toString()
	{
		return "[empId :" +empId+ " empName :"+empName+"]";
	}
}
public class Ex1 {
	ArrayList<Details> getvalues(HashMap<Integer, Details> mp)
	{
		Collection<Details> values=mp.values();
		ArrayList<Details> al=new ArrayList<Details>(values);
		return al;
	}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Ex1 e=new Ex1();
		Details d1=new Details(1234, "JYOTHIREDDY");
		Details d2=new Details(1345, "SHILPA");
		Details d3=new Details(1156, "MAHITHA");
		Details d4=new Details(1897, "AKSHITHA");
		HashMap<Integer,Details> h=new HashMap<Integer,Details>();
		h.put(1, d1);
		h.put(2, d2);
		h.put(3, d3);
		h.put(4, d4);
		System.out.println(e.getvalues(h));
		s.close();
	}
}