package lab9;

import java.util.*;

public class Ex2 {
public static void main(String[] args) {
	String s="jyothireddy";
	char a[]=s.toCharArray();
	HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
	hm=countCharacter(a);
	System.out.println(hm);
}
private static HashMap<Character,Integer> countCharacter(char[] a)
{ 
	HashMap<Character,Integer> hm1=new HashMap<Character,Integer>();
	for(char b:a)
	{
		if(hm1.containsKey(b))
			hm1.put(b, hm1.get(b)+1);
		else
			hm1.put(b, 1);
	}
	return hm1;
}
}