import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


/*
 * decorator/annotation which passes the information that the class (MusicStoreService) should be used for injection
 */
@Injectable({
  providedIn: 'root'
})
export class MusicStoreService {
  http:HttpClient;
  list:MusicStore[]=[];
  /* inject musicStore service whith HttpClient object so when instance of musicstore service
     *  will be created by angular, HttpClient object will be passed as an argument
     * @param http */
     
  constructor(http:HttpClient) {
    this.http=http;
    this.fetchAlbum();
  }
  fetched:boolean=false;

  fetchAlbum()
  {
    this.http.get('./assets/albumList.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getAlbum():MusicStore[]
  {
    return this.list;
  }
  convert(data:any)
  {
    for(let o of data)
    {
      let e=new MusicStore(o.albumId,o.title,o.artist,o.price);
      this.list.push(e);
    }
  }
  /*
 * find the index of the object with same album id and then use array's 
 * splice method to remove object 
 * @param albumId 
 */
  delete(albumId:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.list.length;i++)
    {
      let e=this.list[i];
      if(albumId==e.albumId)
      {
        foundIndex=i;
        break;
      }
    }
    // first argument is the index,second argument is the number of items we want to delete after this index
    this.list.splice(foundIndex,1);
  }
  add(e:MusicStore){
     //adding list at end in array
    this.list.push(e);
  }
}
  export class MusicStore{
    albumId:number;
    title:string;
    artist:string;
    price:number;
      constructor(albumId:number,title:string,artist:string,price:number)
      {
        this.albumId=albumId;
        this.title=title;
        this.artist=artist;
        this.price=price;
    
      }
  }
