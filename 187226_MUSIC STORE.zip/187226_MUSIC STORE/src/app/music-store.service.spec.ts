import { TestBed } from '@angular/core/testing';

import { MusicStoreService } from './music-store.service';

describe('MusicStoreService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MusicStoreService = TestBed.get(MusicStoreService);
    expect(service).toBeTruthy();
  });
});
