import { Component, OnInit } from '@angular/core';
import { MusicStore, MusicStoreService } from '../music-store.service';

@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  createdAlbum:MusicStore;

  createdFlag:boolean=false;

  service:MusicStoreService;

  constructor(service:MusicStoreService) 
  {
    this.service=service;
  }

  ngOnInit() {
  }

  add(data:any){
    this.createdAlbum=new MusicStore(data.albumId,data.title,data.artist,data.price);
    this.service.add(this.createdAlbum);
    alert("Added Succesfully!!!");
    this.createdFlag=true;
   }
}
