import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mobile'
})
export class MobilePipe implements PipeTransform {

  transform(arr:any[],column:string,order:boolean)
  {
    if(column==undefined)
    {
      return arr;
    }
    let r:any;
    if(order)
    {
      r=this.ascending(arr,column);
    }
    return arr;
  }

  ascending(arr:any[],column:string)//function for ascending order to display the columns in ascending which is clicking by user
  {
    arr.sort(
      (a:any,b:any)=>
      {
        if(a[column]>b[column])
        {
          return 1;
        }
        return -1;
      }
    );
    return arr;
  }

}
