import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MobileService {

  http:HttpClient;//object creation for http client
  mob:Mobile[]=[];//object creation for mobile class

  constructor(http:HttpClient) {
    this.http=http;
    this.fetch();
   }

   fetched:boolean=false;
   fetch()//fetch function used for fetching the details into json file
   {
     this.http.get('./assets/mobile.json')//path for json file
     .subscribe(
       data=>
       {
         if(!this.fetched)
         {
           this.convert(data);
           this.fetched=true;
         }
       }
     );
   }

   getMobiles():Mobile[]//getMobiles function used for return the mobile class data
   {
     return this.mob;
   }

   convert(data:any)//convert function for pushing the json file into table
   {
     for(let m of data)
     {
       let mbl=new Mobile(m.mobId,m.mobName,m.mobPrice);
       this.mob.push(mbl);
     }
   }
  
   delete(mobId:number)//function for deleting the rows
  {
    let index:number=-1;
    for(let i=0;i<this.mob.length;i++)
    {
      let m=this.mob[i];
      if(mobId==m.mobId)
      {
        index=i;
        break;
      }
    }
    this.mob.splice(index,1);
  }

  search(mobId:number):Mobile[]
  {
    let result:Mobile[]=[];
    let o:Mobile
    var flag=0;
    for(let i=0;i<this.mob.length;i++)
    {
      o=this.mob[i];
      if(mobId==o.mobId)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(mobId +" doesn't exists");
    }
    return result;
  }
}

export class Mobile{//class creation for mobile details
  mobId:any;
  mobName:any;
  mobPrice:any;
  constructor(mobId:any,mobName:any,mobPrice:any)
  {
    this.mobId=mobId;
    this.mobName=mobName;
    this.mobPrice=mobPrice;
  }
}