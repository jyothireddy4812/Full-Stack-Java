import { Component ,OnInit} from '@angular/core';
import { MusicStoreService,MusicStore } from './music-store.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  title = 'MusicStore';
  service:MusicStoreService;
  router:Router;

  constructor(service:MusicStoreService,router:Router){
    this.service=service;
    this.router=router;
  }

  ngOnInit(){

    //redirect to listing component at start

 
  }

   
   
}
