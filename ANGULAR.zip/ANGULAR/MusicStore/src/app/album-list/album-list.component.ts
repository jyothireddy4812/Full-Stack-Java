import { Component, OnInit } from '@angular/core';
import { MusicStoreService,MusicStore } from '../music-store.service';

@Component({
  selector: 'app-album-list',
  templateUrl: './album-list.component.html',
  styleUrls: ['./album-list.component.css']
})
export class AlbumListComponent implements OnInit {
  service:MusicStoreService;
  /**
 * when instance of AlbumListComponent will be created , 
 * instance of MusicService will be passed as an argument
 * 
 * @param service 
 */
  constructor(service:MusicStoreService) { 
  this.service=service;
  }
  list:MusicStore[]=[];
  /**
   * after deleting reassign the value to list field in this component
   * to keep in sync with service
   * @param albumId 
   */
 delete(albumId:number)
  {
    this.service.delete(albumId);
    this.list=this.service.getAlbum();
    alert("Are you Sure You Want to delete?");  
  }
  
  // albumId kept as default column

  ngOnInit() {
    this.service.fetchAlbum();
    this.list=this.service.getAlbum();
  }

   }

