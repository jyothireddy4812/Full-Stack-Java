import { Component, OnInit } from '@angular/core';
import { MusicStore, MusicStoreService } from '../music-store.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  createdAlbum:MusicStore;

  createdFlag:boolean=false;

  service:MusicStoreService;
  router:Router;

  constructor(service:MusicStoreService) 
  {
    this.service=service;
  }

  ngOnInit() {
   
   
  }

  add(data:any){
    this.createdAlbum=new MusicStore(data.albumId,data.title,data.artist,data.price);
    this.service.add(this.createdAlbum);
    this.router.navigate(['app-album-list']);
    this.createdFlag=true;
   
   }
}
