import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  employees:Employee[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchEmployees();
  }

  fetched:boolean=false;

  fetchEmployees()
  {
    this.http.get('./assets/Employee.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getEmployees():Employee[]
  {
    return this.employees;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Employee(o.eid,o.ename,o.gender,o.edesignation,o.Salary,o.eaddress,o.econtact);
      this.employees.push(e);
    }
  }
  
  delete(eid:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employees.length;i++)
    {
      let e=this.employees[i];
      if(eid==e.eid)
      {
        foundIndex=i;
        break;
      }
    }
    this.employees.splice(foundIndex,1);
  }

  add(e:Employee){
    this.employees.push(e);
  }

  update(data:Employee)
  {
    let eid=data.eid;
    for(let i=0;i<this.employees.length;i++)
    {
      if(eid === this.employees[i].eid)
      {
        this.employees[i].Salary=data.Salary;
        this.employees[i].ename=data.ename;
        this.employees[i].econtact=data.econtact;
        break;
      }
    }
  }
}

export class Employee{
  eid:number;
  ename:string;
  gender:string;
  edesignation:string;
  Salary:number;
  eaddress:string;
  econtact:number;
    constructor(eid:number,ename:string,gender:string,edesignation:string,Salary:number,eaddress:string,econtact:number)
    {
      this.eid=eid;
      this.ename=ename;
      this.gender=gender;
      this.edesignation=edesignation;
      this.Salary=Salary;
      this.eaddress=eaddress;
      this.econtact=econtact;
    }
}