import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeAddComponent } from './Register/employee-add/employee-add.component';
import { EmployeeListComponent } from './Login/employee-list/employee-list.component';
import { ShowBalanceComponent } from './Operations/show-balance/show-balance.component';
import { DepositeAmountComponent } from './Operations/deposite-amount/deposite-amount.component';
import { WithdrawAmountComponent } from './Operations/withdraw-amount/withdraw-amount.component';
import { FundTransferComponent } from './Operations/fund-transfer/fund-transfer.component';
import { MiniStatementComponent } from './Operations/mini-statement/mini-statement.component';
import { HomepageComponent } from './HomePage/homepage.component';



const routes: Routes = [
  {
    path:'app-employee-add',
    component : EmployeeAddComponent
  },
  {
    path:'app-employee-list',
    component : EmployeeListComponent
  },
  {
    path:'app-show-balance',
    component : ShowBalanceComponent
  },
  {
    path:'app-homepage/app-show-balance',
    component : ShowBalanceComponent
  },
  {
    path:'app-deposite-amount',
    component : DepositeAmountComponent
  },
  {
    path:'app-homepage/app-deposite-amount',
    component : DepositeAmountComponent
  },
  {
    path:'app-withdraw-amount',
    component : WithdrawAmountComponent
  },
  {
    path:'app-homepage/app-withdraw-amount',
    component : WithdrawAmountComponent
  },
  {
    path:'app-homepage/app-fund-transfer',
    component : FundTransferComponent
  },
  {
    path:'app-fund-transfer',
    component : FundTransferComponent
  },
  {
    path:'app-homepage/app-mini-statement',
    component : MiniStatementComponent
  },
  {
    path:'app-mini-statement',
    component : MiniStatementComponent
  },
  {
    path:'app-homepage',
    component : HomepageComponent
  }

  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
