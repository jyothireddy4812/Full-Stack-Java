export class Transactions{
    tid:number;
    taccount_sender:number;
    taccount_reciver:number;
    tamount:number;
    ttype:string;
  
  
      constructor(tid:number,taccount_sender:number,taccount_reciver:number,tamount:number,ttype:string)
      {
        this.tid=tid;
        this.taccount_sender=taccount_sender;
        this.taccount_reciver=taccount_reciver;
        this.tamount=tamount;
        this.ttype=ttype;
      }
  }