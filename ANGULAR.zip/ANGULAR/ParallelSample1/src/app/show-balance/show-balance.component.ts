import { Component, OnInit } from '@angular/core';
import { Bank, BankService } from '../bank.service';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {


    accountNo: number;
    
    amount:number;

    result:string;

  constructor(private bankSer: BankService) { }

  ngOnInit() {
  }

   showBalance() {
    this.bankSer.showBalance(this.accountNo)
    .subscribe(response =>{
      this.result = response;
    });

   
  }
}
