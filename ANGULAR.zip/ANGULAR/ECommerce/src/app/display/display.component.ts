import { Component, OnInit } from '@angular/core';
import { MyServiceService, Product } from '../my-service.service';
@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  products:Product[]=[];

  delete(id:number)
  {
    this.service.delete(id);
    this.products=this.service.getProducts();
  }
  isUpdate:boolean=true;
  updateData()
  {
    this.isUpdate=!this.isUpdate;
  }
  update(data:any)
  {
    this.service.update(data);
    this.products=this.service.getProducts();
  }
  ngOnInit() {
    this.service.fetchproducts();
    this.products=this.service.getProducts();
  }

}
