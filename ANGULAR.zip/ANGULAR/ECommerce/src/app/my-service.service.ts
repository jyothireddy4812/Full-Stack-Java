import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  products:Product[]=[];
  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchproducts();
  }
  fetched:boolean=false;
  fetchproducts()
  {
    this.http.get('./assets/product.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getProducts():Product[]
  {
    return this.products;
  }
  
  convert(data:any)
  {
    for(let o of data["products"])
    {
      let e=new Product(o.id,o.name,o.price,o.category);
      this.products.push(e);
    }
  }
  delete(id:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.products.length;i++)
    {
      let e=this.products[i];
      if(id==e.id)
      {
        foundIndex=i;
        break;
      }
    }
    this.products.splice(foundIndex,1);
  }
  update(data:Product)
  {
    let id=data.id;
    for(let i=0;i<this.products.length;i++)
    {
      if(id === this.products[i].id)
      {
        this.products[i].name=data.name;
        this.products[i].price=data.price;
        this.products[i].category=data.category;
        break;
      }
    }
  }
}
export class Product{
  id:number;
  name:string;
  price:number;
  category:string;

    constructor(id:number,name:string,price:number,category:string)
    {
      this.id=id;
      this.name=name;
      this.price=price;
      this.category=category;

    }
}

