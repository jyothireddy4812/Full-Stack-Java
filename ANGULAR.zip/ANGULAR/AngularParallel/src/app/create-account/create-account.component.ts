import { Component, OnInit } from '@angular/core';
import { WalletApp, Transactions, WalletServiceService } from '../wallet-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent implements OnInit {

  createdWalletApp:WalletApp;
  createdTransaction:Transactions;

  router:Router;
  createdFlag:boolean=false;

  service:WalletServiceService;

  constructor(service:WalletServiceService,router:Router) 
  {
    this.service=service;
    this.router=router;
  }

  ngOnInit() {
  }

  add(data:any){
    data.caccount=data.cphone-100;
    data.cbalance=1000;
    
    this.createdWalletApp=new WalletApp(data.caccount,data.cname,data.cphone,data.cpassword,data.ccity,data.cbalance);
    this.service.add(this.createdWalletApp);
    
    this.createdTransaction=new Transactions(125,data.caccount,0,data.cbalance);
    this.service.addTransaction(this.createdTransaction)
    console.log(this.createdTransaction);

    alert("Added Succesfully!!!");
    this.createdFlag=true;
    this.router.navigate(['app-details-list']);
   }
}