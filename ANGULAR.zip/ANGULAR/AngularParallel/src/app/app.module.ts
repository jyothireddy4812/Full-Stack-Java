import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { OrderByPipePipe } from './order-by-pipe.pipe';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { WalletServiceService } from './wallet-service.service';
import { MyServiceService } from './my-service.service';
import { DetailsListComponent } from './details-list/details-list.component';
import { AccountDetailsComponent } from './account-details/account-details.component';
import { PrintTransactionsComponent } from './print-transactions/print-transactions.component';
@NgModule({
  declarations: [
    AppComponent,
    CreateAccountComponent,
    ShowBalanceComponent,
    DepositAmountComponent,
    WithdrawAmountComponent,
    FundTransferComponent,
    OrderByPipePipe,
    DetailsListComponent,
    AccountDetailsComponent,
    PrintTransactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [HttpClient,WalletServiceService,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
