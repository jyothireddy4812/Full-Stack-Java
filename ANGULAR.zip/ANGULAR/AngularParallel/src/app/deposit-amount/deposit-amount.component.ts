import { Component, OnInit } from '@angular/core';
import { WalletApp, Transactions, WalletServiceService } from '../wallet-service.service';

@Component({
  selector: 'app-deposit-amount',
  templateUrl: './deposit-amount.component.html',
  styleUrls: ['./deposit-amount.component.css']
})
export class DepositAmountComponent implements OnInit {

  isLogin:boolean=true;
  details:WalletApp[]=[];
  createdTransaction:Transactions;
  
  service:WalletServiceService;
  constructor(service:WalletServiceService) { 
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  depositAmount(data:any){
    let tid:number;
    let caccount_first=data.caccount;
    let cbalance=data.cbalance;
    console.log(data)
    this.service.depositBalance(caccount_first,cbalance);

    this.createdTransaction=new Transactions(cbalance*4,data.caccount,0,data.cbalance);
    this.service.addTransaction(this.createdTransaction)
  }


  ngOnInit() {
    this.service.fetchDetails();
    this.details=this.service.getDetails();
  }

}
