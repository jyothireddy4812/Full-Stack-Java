import { OrderByPipePipe } from './order-by-pipe.pipe';

describe('OrderByPipePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderByPipePipe();
    expect(pipe).toBeTruthy();
  });
});
