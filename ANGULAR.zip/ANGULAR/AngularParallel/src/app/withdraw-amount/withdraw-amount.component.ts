import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdraw-amount',
  templateUrl: './withdraw-amount.component.html',
  styleUrls: ['./withdraw-amount.component.css']
})
export class WithdrawAmountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
