import { Component, OnInit } from '@angular/core';
import { WalletServiceService, WalletApp } from '../wallet-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-details-list',
  templateUrl: './details-list.component.html',
  styleUrls: ['./details-list.component.css']
})
export class DetailsListComponent implements OnInit {

  service:WalletServiceService;
  router:Router;

  constructor(service:WalletServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }

  details:WalletApp[]=[];
  

  delete(caccount:number)
  {
    this.service.delete(caccount);
    this.details=this.service.getDetails();
  }

  isDeposit:boolean=true;
  isWithdraw:boolean=true;
  isTransfer:boolean=true;
  isLogin:boolean=true;
  
  depositeAmount()
  {
    this.isDeposit=!this.isDeposit;
    this.isWithdraw=this.isWithdraw;
  }

  withdrawAmount()
  {
    this.isWithdraw=!this.isWithdraw;
    this.isDeposit=this.isDeposit;
  }

  fundTransfer(){
    this.isTransfer=!this.isTransfer;
  }

  login(data:any){
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['app-homepage']);
    }else{
      alert("Please Enter Valid Details")
    }
    
    //this.details=this.service.getDetails();
  }
  update(data:any)
  {
    this.service.update(data);
    this.details=this.service.getDetails();
  }

  column:string="caccount"; 
  order:boolean=true;

  sort(column:string)
  {    
    if(this.column==column )
    {
      this.order=!this.order;
    }
    else
    {
      this.order=true;
      this.column=column;
    }
  }
  
  ngOnInit() {
    this.service.fetchDetails();
    this.details=this.service.getDetails();
  }

  
}
