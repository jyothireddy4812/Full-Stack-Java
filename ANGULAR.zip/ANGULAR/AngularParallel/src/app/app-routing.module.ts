import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositAmountComponent } from './deposit-amount/deposit-amount.component';
import { WithdrawAmountComponent } from './withdraw-amount/withdraw-amount.component';
import { FundTransferComponent } from './fund-transfer/fund-transfer.component';
import { DetailsListComponent } from './details-list/details-list.component';


const routes: Routes = [
  {
    path:'app-create-account',
    component : CreateAccountComponent
  },
  {
    path:'app-details-list',
    component : DetailsListComponent
  },
  {
    path:'app-show-balance',
    component : ShowBalanceComponent
  },
  {
    path:'app-deposit-amount',
    component : DepositAmountComponent
  },
  {
    path:'app-withdraw-amount',
    component : WithdrawAmountComponent
  },
  {
    path:'app-fund-transfer',
    component : FundTransferComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
