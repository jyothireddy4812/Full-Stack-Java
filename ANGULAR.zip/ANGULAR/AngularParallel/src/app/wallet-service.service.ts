import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class WalletServiceService {

  http:HttpClient;
  isLogin:boolean=true;
  details:WalletApp[]=[];
  transactions:Transactions[]=[];
  tempTransaction:Transactions[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchDetails();
    this.fetchTransactions();
  }

  fetched:boolean=false;
  fetchedT:boolean=false;

  fetchDetails()
  {
    this.http.get('./assets/Wallet.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  fetchTransactions()
  {
    this.http.get('./assets/Transactions.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetchedT)
        {
          this.convertTransaction(data);
          this.fetchedT=true;
        }
      }
    );
  }

  getDetails():WalletApp[]
  {
    return this.details;
  }

  getTransactions():Transactions[]
  {
    return this.transactions;
  }

  convert(data:any)
  {
    for(let c of data)
    {
      let e=new WalletApp(c.caccount,c.cname,c.cphone,c.cpassword,c.ccity,c.cbalance);
      this.details.push(e);
    }
  }

  convertTransaction(data1:any)
  {
    for(let c of data1)
    {
      let e=new Transactions(c.tid,c.taccount_sender,c.taccount_reciver,c.tamount);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }

  miniStatement(caccount:number):Transactions[]{
    this.tempTransaction=[];
    for(let i=0;i<this.transactions.length;i++)
    {
      let e=this.transactions[i];
      if(caccount==e.taccount_sender)
      {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }
  
  
  delete(caccount:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.details.length;i++)
    {
      let e=this.details[i];
      if(caccount==e.caccount)
      {
        foundIndex=i;
        break;
      }
    }
    this.details.splice(foundIndex,1);
  }

  add(e:WalletApp){
    this.details.push(e);
    var myJSON = JSON.stringify(this.details);
    console.log(myJSON);
  }

  addTransaction(e:Transactions){
    this.transactions.push(e);
  }

  showBalance(data:WalletApp):number{
    let caccount = data.caccount; 
    for(let i=0;i<this.details.length;i++)
      {
        if(caccount == this.details[i].caccount)
        {
          //alert(this.employees[i].cbalance)
          let cbalance=this.details[i].cbalance;
          return cbalance;
        }else{
          alert("Account number is not found!")
        }
      }
  }

  depositBalance(caccount_first:number,cbalance:number){
      console.log(caccount_first,cbalance)

      for(let i=0;i<this.details.length;i++)
      {
        if(caccount_first == this.details[i].caccount)
        {
          let depositeB:number=this.details[i].cbalance;
          this.details[i].cbalance=depositeB + cbalance;
          alert(10 + 30)
          // alert(this.employees[i].cbalance);
          alert("Amount Deposited to "+caccount_first+" Available Balance : "+this.details[i].cbalance);
          break;
        }
      }
  }
  
  withdrawBalance(caccount_first:number,cbalance:number){
    console.log(caccount_first,cbalance)

    for(let i=0;i<this.details.length;i++)
    {
      if(caccount_first == this.details[i].caccount)
      {
        let depositeB:number=this.details[i].cbalance;
        this.details[i].cbalance=depositeB - cbalance;
        alert(10 + 30)
        // alert(this.employees[i].cbalance);
        alert("Amount Withdrawn from "+caccount_first+" Available Balance : "+this.details[i].cbalance);
        break;
      }
    }
  }

  update(data:WalletApp)
  {
    let caccount=data.caccount;
    for(let i=0;i<this.details.length;i++)
    {
      if(caccount === this.details[i].caccount)
      {
        this.details[i].cname=data.cname;
        this.details[i].cbalance=data.cbalance;
        break;
      }
    }
  }

  login(data:WalletApp):boolean
  {
    let caccount=data.caccount;
    let cpassword=data.cpassword;
    //this.loginCheckAcc=data.caccount;
    //alert(this.loginCheckAcc);
    for(let i=0;i<this.details.length;i++)
    {
      if(caccount == this.details[i].caccount && cpassword == this.details[i].cpassword)
      {
        alert("details Matched!")
        this.isLogin=!this.isLogin;
        // this.employees[i].cname=data.cname;
        // this.employees[i].cbalance=data.cbalance;
        return true;
        
      }else {
        return false;
      }

    }
  }

  search(caccount:number):WalletApp[]
  {
    let resultEmp:WalletApp[]=[];
    let o:WalletApp;
    var flag = 0;
    for(let i=0;i<this.details.length;i++)
    {
      if(caccount==o.caccount)
      {
        resultEmp.push(o);
        alert("ID : "+o.caccount+"Name :"+o.cname);
        flag=1;
        break;
      }
    }
    if(flag==0){
      alert("No data Exist!");
    }
    return resultEmp;
  }
}

export class WalletApp{
  caccount:number;
  cname:string;
  cphone:number;
  cpassword:string;
  ccity:string;
  cbalance:number;

    constructor(caccount:number,cname:string,cphone:number,cpassword:string,ccity:string,cbalance:number)
    {
      this.cbalance=cbalance;
      this.caccount=caccount;
      this.cname=cname;
      this.cphone=cphone;
      this.cpassword=cpassword;
      this.ccity=ccity;
    }
}

export class Transactions{
  tid:number;
  taccount_sender:number;
  taccount_reciver:number;
  tamount:number;


    constructor(tid:number,taccount_sender:number,taccount_reciver:number,tamount:number)
    {
      this.tid=tid;
      this.taccount_sender=taccount_sender;
      this.taccount_reciver=taccount_reciver;
      this.tamount=tamount;
    }
}
