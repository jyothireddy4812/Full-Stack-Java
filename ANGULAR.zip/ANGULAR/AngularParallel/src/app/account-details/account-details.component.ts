import { Component, OnInit } from '@angular/core';
import { WalletServiceService, WalletApp } from '../wallet-service.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {

  service:WalletServiceService;
  details:WalletApp[]=[];
  
  constructor(service:WalletServiceService) { 
    this.service=service;
  }

  ngOnInit() {

    this.service.fetchDetails();
    this.details=this.service.getDetails();
    console.log(this.details);

  }

}
