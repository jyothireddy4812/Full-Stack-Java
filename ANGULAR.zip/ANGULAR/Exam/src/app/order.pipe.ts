import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'order'
})
export class OrderPipe implements PipeTransform {

  transform(arr:any[],column:string,order:boolean) //array and column which needs to be sorted
  {
    //column name is not defines so no sorting order
    if(column==undefined)
    {
      return arr;
    }

   let result:any[]; 
   if(order)
   {
    result =this.ascending(arr,column);
   }
  
    return arr;
  }
  ascending(arr:any[],column:string)//array and column which needs to be sorted
  {
    arr.sort
    (
      (a:any,b:any)=>
      {
        if(a[column]>b[column])
        {
          return 1;
        }
          return -1;
      }
    );
    return arr;
  }
}