import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { DisplayMobileComponent } from './display-mobile/display-mobile.component';
import { OrderPipe } from './order.pipe';
import { MobileserviceService } from './mobileservice.service';
import { SearchComponent } from './search/search.component';

@NgModule({
  declarations: [
    AppComponent,
    DisplayMobileComponent,
    OrderPipe,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    
    FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,MobileserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
