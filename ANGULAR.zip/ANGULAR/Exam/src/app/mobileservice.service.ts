import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MobileserviceService {
  http:HttpClient;
  mobiles:Mobile[]=[];
  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchMobiles();
  }
fetched:boolean=false;
//fetching json by making get request
 fetchMobiles()
  {
    this.http.get('./assets/mobile.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }
  getMobiles():Mobile[]
  {
    return this.mobiles;
  }
  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Mobile(o.mobId,o.mobName,o.mobPrice);
      this.mobiles.push(e);
    }
  }
  //find the index of the object with same mobile id and then use array's  splice method to remove object 
  delete(mobId:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.mobiles.length;i++)
    {
      let e=this.mobiles[i];
      if(mobId==e.mobId)
      {
        foundIndex=i;
        break;
      }
    }//first argument is the index,second argument is the number of items we want to delete after this index
    this.mobiles.splice(foundIndex,1);
  }
  search(mobId:number):Mobile[]
  {
    let result:Mobile[]=[];
    let o:Mobile
    var flag=0;
    for(let i=0;i<this.mobiles.length;i++)
    {
      o=this.mobiles[i];
      if(mobId==o.mobId)
      {
        result.push(o);
        flag=1;
      }
    }
    if(flag==0)
    {
      alert(mobId +" doesn't exists");
    }
    return result;
  }
}


export class Mobile{
  mobId:number;
  mobName:string;
  mobPrice:number;
  constructor(mobId:number,mobName:string,mobPrice:number)
    {
      this.mobId=mobId;
      this.mobName=mobName;
      this.mobPrice=mobPrice;
   
 
}
}