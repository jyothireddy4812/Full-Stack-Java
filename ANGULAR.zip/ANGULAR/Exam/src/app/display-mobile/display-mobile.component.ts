import { Component, OnInit } from '@angular/core';
import { MobileserviceService,Mobile } from '../mobileservice.service';

@Component({
  selector: 'app-display-mobile',
  templateUrl: './display-mobile.component.html',
  styleUrls: ['./display-mobile.component.css']
})
export class DisplayMobileComponent implements OnInit {
  service:MobileserviceService; //instance of mobileservice will pass an argument
  constructor(service:MobileserviceService) {
    this.service=service;
   }
   mobiles:Mobile[]=[];
   delete(mobId:number) //id kept as default column
   {
     this.service.delete(mobId);
     this.mobiles=this.service.getMobiles();
   }

   column:string="mobId"; 
   order:boolean=true;
 
   sort(column:string) //sort for same column change the order to ascending
   {    
     if(this.column==column )
     {
       this.order=!this.order;
     }
     else
     {
       this.order=true;
       this.column=column;
     }
   }
   

  ngOnInit() {
    this.service.fetchMobiles();
    this.mobiles=this.service.getMobiles();
  }

}
