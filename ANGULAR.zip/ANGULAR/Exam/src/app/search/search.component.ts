import { Component, OnInit } from '@angular/core';
import { MobileserviceService, Mobile } from '../mobileservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  service:MobileserviceService;

  constructor(service:MobileserviceService) {
    this.service=service;
   }

   mobiles:Mobile[]=[];

  ngOnInit() {
    this.service.fetchMobiles();
  }

  isSearch:boolean=true;
  SearchData()
  {
    this.isSearch=!this.isSearch;
  }
  search(data:any)
  {
    let id:number=data.mobId;
    this.mobiles=this.service.search(id);
  }

}
