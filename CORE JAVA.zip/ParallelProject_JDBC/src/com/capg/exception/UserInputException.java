package com.capg.exception;

@SuppressWarnings("serial")

public class UserInputException extends Exception {
	String s1;

	public UserInputException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}
}
