package com.capg.dao;

import java.util.HashMap;

import com.capg.beans.Wallet;
import com.capg.beans.Transaction;

public interface IWalletDAO {
	
	public void addUserAccount(Wallet bank,Transaction tran) ;
	
	public String getBalance(int accountNo) ;
	
	public String depositMoney(int accountNumber,long amount,Transaction tran) ;
	
	public String withdrawMoney(int accountNumber,long amount,Transaction tran);
	
	public HashMap<Integer,Transaction> printTransactions(int  accountId)  ;	

	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction tran1,Transaction tran2) ;


	
}
