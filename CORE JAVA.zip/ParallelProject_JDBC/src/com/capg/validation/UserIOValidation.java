package com.capg.validation;

import java.util.regex.Pattern;

import com.capg.dao.WalletDAOImpl;
import com.capg.exception.UserInputException;

public class UserIOValidation {

	static WalletDAOImpl dao=new WalletDAOImpl();
	
	public static boolean checkName(String name) throws UserInputException {
		  if (Pattern.matches("([A-Z])([a-z])*",name))
	           return true;
	       else
	           return false;
	}

	public static boolean checkPIN(int pin) throws UserInputException {
		try {
			String g=Integer.toString(pin);
			if (g.matches("[0-9]+") && g.length() == 4) {
				return true;
			} else {
				throw new UserInputException("Invalid PIN");

			}
		} catch (UserInputException e) {
			return false;
		}
	}

	public static boolean checkPhoneNumber(String number) throws UserInputException {
		try {
			if (number.matches("[0-9]+") && number.length() == 10) {
				return true;
			} else {
				throw new UserInputException("Invalid mobile number");
			}
		} catch (UserInputException e) {
			return false;
		}
	}
	
	public static boolean checkAccNo(int accountNumber) throws UserInputException {
		try {
			if (dao.checkAccountNumber(accountNumber))
				return true;
			else
				throw new UserInputException("Invalid Account Number");
		} catch (UserInputException e) {
			return false;

		}

	}
}