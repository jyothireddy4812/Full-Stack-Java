package com.capg.ui;

import java.util.Scanner;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.LocalTime;

import com.capg.beans.Wallet;
import com.capg.beans.Transaction;
import com.capg.exception.UserInputException;
import com.capg.service.WalletServiceImpl;
import com.capg.service.IWalletService;
import com.capg.validation.UserIOValidation;

public class Client {

	public static void main(String args[]) {
		Wallet wallet;
		Transaction transaction = new Transaction();
		UserIOValidation validation = new UserIOValidation();
		IWalletService service = new WalletServiceImpl();
		Scanner scanner = new Scanner(System.in);
		int choice;
		LocalDate date = LocalDate.now();
		LocalTime time = LocalTime.now();
		while (true) {
			System.out.println("------------XYZ BANK-----------");
			System.out.println("******BANK WALLET APPLICATION*******");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT MONEY");
			System.out.println("4.WITHDRAW MONEY");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.println("ENTER YOUR CHOICE");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("ENTER YOUR NAME:");
				String name = scanner.next();
				try {
					while (!UserIOValidation.checkName(name)) {
						System.out.print("Invalid Name....Please Enter valid name starts with uppercase: ");
						name = scanner.next();
					}
				} catch (UserInputException e) {
				
					e.printStackTrace();
				}
				System.out.println("ENTER YOUR DATE OF BIRTH IN DD/MM/YYYY");
				String dob = scanner.next();
				System.out.println("ENTER YOUR PHONE NUMBER ( SHOULD CONTAIN ONLY TEN DIGITS )");
				String phno = scanner.next();
				try {
					while (!UserIOValidation.checkPhoneNumber(phno)) {
						System.out.print("Enter your phone number : ");
						phno = scanner.next();
					}
				} catch (UserInputException e) {
					
					e.printStackTrace();
				}
				System.out.println("ENTER YOUR PIN(SHOULD CONTAIN ONLY FOUR DIGITS)");
				int pin = scanner.nextInt();
				try {
					while (!UserIOValidation.checkPIN(pin)) {
						System.out.print("Enter your PIN : ");
						pin = scanner.nextInt();
					}
				} catch (UserInputException e) {
				
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU WANT TO DEPOSIT");
				long amt = scanner.nextLong();
				int acno = (int) ((Math.random()) * 1000000000);
				int tranid = (int) ((Math.random()) * 100000);
				wallet = new Wallet(acno, name, dob, phno, pin, amt);
				transaction = new Transaction(tranid, acno, "Account Created. Date : " + date + " Time : " + time
						+ " Rs." + amt + " was deposited successfully.");
				service.addAccount(wallet, transaction);
				System.out.println("Your account created.\n Your Account number is " + acno);
				break;
			case 2:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber = scanner.nextInt();
				try {
					while (!UserIOValidation.checkAccNo(accountNumber)) {
						System.out.print("Enter valid Account Number: ");
						accountNumber = scanner.nextInt();
					}
				} catch (UserInputException e2) {
					
					e2.printStackTrace();
				}
				String message = service.checkBalance(accountNumber);
				System.out.println(message);
				break;
			case 3:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber1 = scanner.nextInt();
				try {
					while (!UserIOValidation.checkAccNo(accountNumber1)) {
						System.out.print("Enter valid Account Number: ");
						accountNumber1 = scanner.nextInt();
					}
				} catch (UserInputException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU NEED TO DEPOSIT : ");
				long amount = scanner.nextLong();
				int tranidd = (int) ((Math.random()) * 100000);
				transaction = new Transaction(tranidd, accountNumber1, "Amount Deposited. Date : " + date + " Time : "
						+ time + " Rs." + amount + " was deposited successfully.");
				String message1 = service.depositMoney(accountNumber1, amount, transaction);
				System.out.println(message1);
				break;
			case 4:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumberr = scanner.nextInt();
				try {
					while (!UserIOValidation.checkAccNo(accountNumberr)) {
						System.out.print("Enter valid Account Number: ");
						accountNumberr = scanner.nextInt();
					}
				} catch (UserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU NEED TO WITHDRAW : ");
				long amountt = scanner.nextLong();
				int tranId = (int) ((Math.random()) * 100000);
				transaction = new Transaction(tranId, accountNumberr, "Ammount Withdrawn. Date : " + date + " Time : "
						+ time + " Rs." + amountt + " was withdrawn successfully.");
				String messagee = service.withdrawMoney(accountNumberr, amountt, transaction);
				System.out.println(messagee);
				break;
			case 5:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumber01 = scanner.nextInt();
				try {
					while (!UserIOValidation.checkAccNo(accountNumber01)) {
						System.out.print("Enter valid Account Number: ");
						accountNumber01 = scanner.nextInt();
					}
				} catch (UserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("ENTER THE AMOUNT YOU NEED TO Send : ");
				long amount01 = scanner.nextLong();
				System.out.println("ENTER ANOTHER ACCOUNT NUMBER : ");
				int accountNumber02 = scanner.nextInt();
				try {
					while (!UserIOValidation.checkAccNo(accountNumber02)) {
						System.out.print("Enter valid Account Number: ");
						accountNumber02 = scanner.nextInt();
					}
				} catch (UserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				int tranid1 = (int) ((Math.random()) * 100000);
				int tranid2 = (int) ((Math.random()) * 100000);
				Transaction trans1 = new Transaction(tranid1, accountNumber01, "Amount Sent. Date : " + date
						+ " Time : " + time + " Rs." + amount01 + " was sent to " + accountNumber02 + " successfully.");
				Transaction trans2 = new Transaction(tranid2, accountNumber02,
						"Amount Received. Date : " + date + " Time : " + time + " Rs." + amount01 + " was received from "
								+ accountNumber02 + " successfully.");
				String messages = service.transferMoney(accountNumber01, amount01, accountNumber02, trans1,
						trans2);
				System.out.println(messages);
				break;
			case 6:
				System.out.println("ENTER YOUR ACCOUNT NUMBER : ");
				int accountNumbers = scanner.nextInt();
				try {
					while (!UserIOValidation.checkAccNo(accountNumbers)) {
						System.out.print("Enter valid Account Number: ");
						accountNumbers = scanner.nextInt();
					}
				} catch (UserInputException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(service.getTransactionDetails(accountNumbers));
				break;
			case 7:
				System.out.println("Thank You for using our services");
				scanner.close();
				break;
			default:
				System.out.println(" Invalid choice." + "\n" + " Enter Valid choice");

			}
		}

	}

}
