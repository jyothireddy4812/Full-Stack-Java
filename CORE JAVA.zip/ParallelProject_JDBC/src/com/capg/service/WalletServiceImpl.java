package com.capg.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capg.beans.Wallet;
import com.capg.beans.Transaction;
import com.capg.dao.WalletDAOImpl;
import com.capg.dao.IWalletDAO;

public class WalletServiceImpl implements IWalletService{

	IWalletDAO dao=new WalletDAOImpl();
	
	@Override
	public void addAccount(Wallet bean,Transaction tran) {
		dao.addUserAccount(bean,tran);
		
	}

	@Override
	public String checkBalance(int accountNo) {
		return  dao.getBalance(accountNo);
	}

	@Override
	public String depositMoney(int accountNumber, long amount, Transaction tran) {
		return  dao.depositMoney(accountNumber, amount, tran);
	}

	@Override
	public String withdrawMoney(int accountNumber, long amount, Transaction tran) {
		return  dao.withdrawMoney(accountNumber, amount, tran);
	}


	@Override
	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction tran1,Transaction tran2) {
		return dao.transferMoney(accountNumber01,amount01,accountNumber02,tran1,tran2);
	}

	@Override
	public String getTransactionDetails(int accountNumber) {

		HashMap<Integer,Transaction> hm=dao.printTransactions(accountNumber);
		
		Set set=hm.entrySet();
		Iterator iterator=set.iterator();
		String trans = "" ;
		while(iterator.hasNext())
		{
			Map.Entry pair = (Map.Entry)iterator.next();
			int tid=(int) pair.getKey();
			Transaction transaction=(Transaction) pair.getValue();
			trans=trans+"\n"+"Transaction ID :"+tid+"|| Account number :"+transaction.getAcno()+"|| Transaction Type :"+transaction.getOpertaion();
		}
		return trans;
	}
}
