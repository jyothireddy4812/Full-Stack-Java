package com.capg.service;



import com.capg.beans.Wallet;
import com.capg.beans.Transaction;

public interface IWalletService {

	public void addAccount(Wallet bank,Transaction tran) ;
	
	public String checkBalance(int accountNo) ;
	
	public String depositMoney(int accountNumber,long amount,Transaction tran) ;
	
	public String withdrawMoney(int accountNumber, long amount,Transaction tran) ;
	
	public String getTransactionDetails(int accountNumber) ;

	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction tran1,Transaction tran2) ; 
}
