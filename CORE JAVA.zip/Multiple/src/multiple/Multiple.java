package multiple;
interface A
{
	void m1();	
	
}
abstract class B
{
	abstract void m2();
	void m3()
	{
		System.out.println("JYOTHI REDDY");
	}
}
public class Multiple extends B implements A {
	public static void main(String[] args) {
		Multiple m=new Multiple();
		m.m1();
		m.m2();
		m.m3();
		
	}

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		System.out.println("123");
	}

	@Override
	void m2() {
		// TODO Auto-generated method stub
		System.out.println("456");
	}
	

}
