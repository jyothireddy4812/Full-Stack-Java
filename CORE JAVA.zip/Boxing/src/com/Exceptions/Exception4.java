package com.Exceptions;

class A {
public void div(String a,String b) throws Exception
{
	int c=Integer.parseInt(a)/Integer.parseInt(b);
	System.out.println(c);
}
}
public class Exception4{
	public static void main(String[] args) {
		A ob=new A();
		try {
			ob.div("10", "0");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}