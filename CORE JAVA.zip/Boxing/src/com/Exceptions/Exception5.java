package com.Exceptions;

class MyException1 extends Exception{
	private int age;
	public MyException1(int age)
	{
		this.age=age;
	}
	public String toString() {
		return "u r not eligible for vote"+age;
	}
}
public class Exception5 {
static void validation(int age) throws MyException1
{
	if(age<18)
		throw new MyException1(age);//MyException1 obj
	else
		System.out.println("u r not eligible to vote");
}
public static void main(String[] args) throws MyException1  {
	Exception5.validation(16);
	System.out.println("rest of the code...............................");
}
}

