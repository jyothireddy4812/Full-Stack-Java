package com.Exceptions;

public class Exception1 {
public static void main(String[] args) {
	try {
		int a=10;
		int b=0;
		int c=a/b;
	}catch(ArithmeticException ae) {
		System.out.println("dont enter zero as denominator");
		//System.out.println(ae);
		ae.printStackTrace();
		//System.out.println(ae.getMessage());
	}
	try {
		int a[]=new int[5];//0....4
		a[0]=1;
		a[5]=7;
	}
	catch(ArrayIndexOutOfBoundsException ae) {
		System.out.println("array index maximum size is 4");
	}
	System.out.println("remaining code lines");
}
}
