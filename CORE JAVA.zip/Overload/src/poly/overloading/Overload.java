package poly.overloading;

class Test {
	static void add()
	{
		System.out.println("default method");
	}
	static void add(int a,int b)
	{
		System.out.println("sum is "+(a+b));
	}
	static void add(float a,float b)
	{
		System.out.println("sum is "+(a+b));
	}
	static void add(int a,float b)
	{
		System.out.println("sum is "+(a+b));
	}

	static void add(float a,int b)
	{
		System.out.println("sum is "+(a+b));
	}

}
class Overload
{
	public static void main(String[] args) {
		Test.add();
		Test.add(112,6);
		Test.add(2.45f,4.45f);
		Test.add(12,4.56f);
		Test.add(2.456f,12);
	}
}
