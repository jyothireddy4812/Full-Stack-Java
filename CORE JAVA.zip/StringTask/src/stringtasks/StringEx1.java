
package stringtasks;

import java.util.Scanner;

public class StringEx1 {
public static void main(String[] args) {
	int n;
	String s1;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Index");
	n=sc.nextInt();
	System.out.println("Enter String");
	s1=sc.next();
	System.out.println(s1.charAt(n));
}
}
