package stringtasks;

import java.util.Scanner;

public class StringEx8 {
public static void main(String[] args) {
	int n=0;
	String s1;
	Scanner sc=new Scanner(System.in);
	/*System.out.println("Enter Index");
	n=sc.nextInt();*/
	System.out.println("Enter String");
	s1=sc.next();
	System.out.println(s1);
	for(int i=0;i<s1.length();i++) {
		if(s1.equals(" ")) {
			System.out.println(Character.toUpperCase(s1.charAt(i)));
		}
	}

}
}
