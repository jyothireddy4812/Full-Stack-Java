package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductCodeException;
import com.capgemini.takehome.service.ProductService;



public class Client {
static ProductService ps=new ProductService();
//@SuppressWarnings("unused")
@SuppressWarnings("unused")
public static void main(String[] args) {
	int productCode;
	String productName;
	double productPrice ;
	int productQuantity;
	String productCategory ;	
	
	while(true) {
		System.out.println("BILLING SOFTWARE APPLICATION");
		System.out.println("1)Generate Bill by entering Product code and quantity");
		System.out.println("2)Exit");
		Scanner sc=new Scanner(System.in);
		System.out.println("ENTER YOUR CHOICE");
		int choice=sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter Product code");
			productCode=ps.validationCode(sc.nextInt());
			try {
			System.out.println("Enter Product Quantity");
			productQuantity=ps.validationQuantity(sc.nextInt());
			Product p=new Product(productCode,productQuantity);
			Product p1=ps.getProductDetails(productCode);
			System.out.println("PRODUCT NAME: "+p1.getProductName()+"\nPRODUCT CATEGORY:  "+p1.getProductCategory()+
					"\nPRODUCT PRICE: " +p1.getProductPrice()+ "\nPRODUCT QUANTITY: "+productQuantity+ "\nLINE TOTAL: " +productQuantity*p1.getProductPrice());
			}
			catch (ProductCodeException e) {
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("THANK YOU :)");
			System.exit(0);
			break;
			
		}	
	
		}
}

}
