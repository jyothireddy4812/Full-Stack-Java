package com.capgemini.takehome.exception;

public class ProductCodeException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProductCodeException(String msg) {
	
		super(msg);
	
	}
	
}


