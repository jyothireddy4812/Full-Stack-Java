package com.capgemini.takehome.service;

import java.util.Scanner;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements IProductService {
	Scanner sc=new Scanner(System.in);
	ProductDAO pd=new ProductDAO();



public int validationQuantity(int productQuantity) {
	while (true) {
		if(productQuantity<=0) {
			System.out.println("Quantity should be greater than zero \nEnter atleast one Quantity ");
			productQuantity=sc.nextInt();
		}else {
			return productQuantity;
		}
	}
}
public int validationCode(int productCode) {
	while (true) {
		if(productCode==4) {
			System.out.println("enter valid 4 digit code ");
			productCode=sc.nextInt();
		}else {
			return productCode;
		}
	}
}

@Override
public Product getProductDetails(int productCode){
	Product p1=pd.getProductDetails(productCode);
	
	
	return p1;
}

}



