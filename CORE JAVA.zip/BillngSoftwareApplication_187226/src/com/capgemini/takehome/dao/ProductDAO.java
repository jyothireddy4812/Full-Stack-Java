package com.capgemini.takehome.dao;

import java.util.Map;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductCodeException;
import com.capgemini.takehome.util.CollectionUtil;



public class ProductDAO implements IProductDAO{
	CollectionUtil c=new CollectionUtil();
	

	@Override
	public Product getProductDetails(int productCode) {
		Map<?, ?> m1=(Map<?, ?>) c.getObject();
		Product p=(Product) m1.get(productCode);
		if(p==null) {
			throw new ProductCodeException("Invalid Code...... Please Try valid 4 digit code:)"); 
		}else
		{
			return p;
		}
	}

	}
	
