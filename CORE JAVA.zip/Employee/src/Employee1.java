
public class Employee1 {
private int Eid=123;
private String Ename="JYOTHIREDDY";
private int Esal=120000;
private int Atmpin=7678;
public int getEid() {
	return Eid;
}
public void setEid(int eid) {
	Eid = eid;
}
public String getEname() {
	return Ename;
}
public void setEname(String ename) {
	Ename = ename;
}
public int getEsal() {
	return Esal;
}
public void setEsal(int esal) {
	Esal = esal;
}
public int getAtmpin() {
	return Atmpin;
}
public void setAtmpin(int atmpin) {
	Atmpin = atmpin;
}

}
