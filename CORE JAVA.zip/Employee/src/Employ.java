
public class Employ {

	public static void main(String[] args) {
		Employee1 e=new Employee1(); 
		System.out.println(e.getEid());
		System.out.println(e.getEname());
		System.out.println(e.getEsal());
		System.out.println(e.getAtmpin());
		e.setEid(12345);
		e.setEname("Jyothi");
		e.setEsal(123459000);
		System.out.println("*************************************************");
		e.setAtmpin(1345);System.out.println(e.getEid());
		System.out.println(e.getEname());
		System.out.println(e.getEsal());
		System.out.println(e.getAtmpin());
		
		
	}
	
	
 
}
  