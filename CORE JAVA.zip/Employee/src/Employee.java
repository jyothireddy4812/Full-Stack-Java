
import java.util.*;
class Student
{

static String name="SIST";
Scanner sc=new Scanner(System.in);
int studReg=sc.nextInt();
String studName=sc.nextLine();
void display()
{
System.out.println(studReg+" "+studName);
}
public static void main(String args[])
{
System.out.println(Student.name);
Student st=new Student();
st.display();
}
}

