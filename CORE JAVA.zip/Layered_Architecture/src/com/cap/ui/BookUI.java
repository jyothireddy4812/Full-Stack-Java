package com.cap.ui;

import java.util.Scanner;

import com.cap.services.BookService;

public class BookUI {
public static void main(String[] args) {
	int bookId=0;
	String title="";
	float price=0;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter book id");
	bookId=sc.nextInt();
	System.out.println("Enter book title");
	title=sc.next();
	System.out.println("Enter book price");
	price=sc.nextFloat();
	BookService b=new BookService();
	int finalresult=b.addBook(bookId, title, price);
	System.out.println("record "+ finalresult + " inserted");
	sc.close();
	
}
}
