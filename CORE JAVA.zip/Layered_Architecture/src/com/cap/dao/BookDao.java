package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cap.beans.BookBean;

public class BookDao implements BookDaoI {

	@Override
	public int addBook(BookBean bookBean) {
		Connection con=null;
		PreparedStatement pstmt=null;
		try {
			con=BookDB.getConnection1();
			String ins_str="insert into book values(?,?,?,?)";
			pstmt=con.prepareStatement(ins_str)	;
			pstmt.setInt(1, bookBean.getBookId());
			pstmt.setString(2, bookBean.getTitle());
			pstmt.setFloat(3, bookBean.getPrice());
			pstmt.setString(4, bookBean.getGrade());
		int finalResult =pstmt.executeUpdate();
		con.close();
		
		return finalResult;
	}
		catch(Exception e) {
			System.out.println(e);
			return 0;
		}

}
}
