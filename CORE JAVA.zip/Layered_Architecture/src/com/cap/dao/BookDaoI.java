package com.cap.dao;

import com.cap.beans.BookBean;

public interface BookDaoI {
int addBook(BookBean bookBean);
}
