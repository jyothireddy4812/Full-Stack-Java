package com.cap.services;

import com.cap.beans.BookBean;
import com.cap.dao.BookDao;

public class BookService implements BookServiceI{

	@Override
	public int addBook(int bookId,String title,float price) {
		String grade="";
		if(price<=300)
		{
			grade ="C";
		}
		else if(price<=600) {
		
			grade ="B";
			}
		
		else {	
			grade ="A";
		}
		BookDao bookDao=new BookDao();
		BookBean bookBean=new BookBean();
		bookBean.setBookId(bookId);
		bookBean.setTitle(title);
		bookBean.setPrice(price);
		bookBean.setGrade(grade);
		
	int result=	0;
		try {
		result=bookDao.addBook(bookBean);
		return result;
	}catch(Exception e) {
		System.out.println(e.toString());
		return 0;
	}


	}}


	


