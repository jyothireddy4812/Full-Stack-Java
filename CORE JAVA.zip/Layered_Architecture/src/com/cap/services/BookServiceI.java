package com.cap.services;

public interface BookServiceI {
int addBook(int bookId,String title,float price);
}
