package com.cg.mra.service;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	Scanner sc = new Scanner(System.in);
	AccountDaoImpl ad = new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNumber) {
		Account a1 = ad.getAccountDetails(mobileNumber); // passing mobile number to AccountDao class
		return a1;
	}

	@Override
	public Account rechargeAccount(String mobileNumber, long bal) {
		Account a1 = ad.rechargeAccount(mobileNumber, bal);// passing arguments to AccountDao class
		return a1;
	}

	public long validationBal(long balance) { // validation for balance
		while (true) {
			if (balance <= 0) {
				System.out.println("Amount should be greater than zero \nEnter valid amount ");
				balance = sc.nextLong();
			} else {
				return balance;
			}
		}
	}

	public String validationMobileNo(String mobileNo) { // validation for mobile number
		while (true) {
			if (String.valueOf(mobileNo).length() == 10 && mobileNo.matches("[6-9][0-9]{9}")) {
				System.out.println(mobileNo);
				return mobileNo;
			} else {
				System.out.println("Enter valid 10 digit number");
				mobileNo = sc.next();
			}
		}
	}

}
