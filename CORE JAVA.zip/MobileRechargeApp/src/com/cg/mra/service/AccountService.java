package com.cg.mra.service;

import com.cg.mra.beans.Account;

public interface AccountService {
	Account getAccountDetails(String mobileNumber);

	Account rechargeAccount(String mobileNumber, long bal);
}
