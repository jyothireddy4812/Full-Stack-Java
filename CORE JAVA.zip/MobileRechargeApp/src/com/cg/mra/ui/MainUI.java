package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;

import com.cg.mra.exceptions.MobileNumberNotFoundException;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	static AccountServiceImpl as = new AccountServiceImpl();

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		String AccountType;
		String customerName;
		double accountBalance;
		String mobileNumber;
		while (true) {
			System.out.println("******MOBILE RECHARGE APPLICATION*******");
			System.out.println("1.ACCOUNT BALANCE ENQUIRY");
			System.out.println("2.RECHARGE ACCOUNT");
			System.out.println("3.EXIT");
			Scanner sc = new Scanner(System.in);
			System.out.println("ENTER YOUR CHOICE");
			int choice = getOption(sc);
			switch (choice) {
			case 1:
				System.out.println("ENTER MOBILE NUMBER");
				mobileNumber = as.validationMobileNo(sc.next()); // validating mobile number
				try {
					Account a = as.getAccountDetails(mobileNumber); // passing mobile number to Accountservice
					System.out.println("ACCOUNT BALANCE IS: " + a.getAccountBalance());
				} catch (MobileNumberNotFoundException e) {
					System.out.println(e.getMessage());
				}
				break;
			case 2:
				System.out.println("ENTER MOBILE NUMBER");// validating mobile number
				mobileNumber = sc.next();
				try {
					System.out.println("ENTER THE RECHARGE AMOUNT");// validating balance
					long bal = as.validationBal(sc.nextLong());
					Account a1 = as.rechargeAccount(mobileNumber, bal); // passing arguments to Accountservice
					System.out.println("RECHARGE AMOUNT: " + bal);
					System.out.println("YOUR ACCOUNT RECHARGED SUCCESSFULLY \n HELLO  " + a1.getCustomerName()
							+ " AVAILABLE BALANCE: " + a1.getAccountBalance());
				} catch (MobileNumberNotFoundException e) { // Exception
					System.out.println(e.getMessage());
				}
				break;
			case 3:
				System.out.println("THANK U:)");
				break;

			default:
				System.exit(0);

			}
		}
	}

	private static int getOption(Scanner sc) {
		try {
			int option = sc.nextInt();
			return option;
		} catch (Throwable e) {
			System.out.println("Enter Valid choice");
		}
		return -1;
	}
}
