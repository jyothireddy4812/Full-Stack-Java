package com.cg.mra.exceptions;

public class MobileNumberNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MobileNumberNotFoundException(String msg) {

		super(msg);

	}

}
