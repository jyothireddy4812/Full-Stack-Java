package com.cg.mra.dao;

import org.junit.Test;

import com.cg.mra.beans.Account;

import junit.framework.Assert;

public class AccountDaoImplTest {
	AccountDaoImpl ad = new AccountDaoImpl();

	@Test
	public void testRechargeAccount_1() {
		String mobileNumber = "9010210131";
		@SuppressWarnings("unused")
		Account accountEntry = ad.getAccountDetails(mobileNumber);

		Account result = ad.rechargeAccount(mobileNumber, 500);
		long result1 = (long) result.getAccountBalance();
		long expectedResult = 1132;
		System.out.println("account=" + result1);
		Assert.assertEquals(expectedResult, result1);
		ad.rechargeAccount(mobileNumber, 900);
	}

}
