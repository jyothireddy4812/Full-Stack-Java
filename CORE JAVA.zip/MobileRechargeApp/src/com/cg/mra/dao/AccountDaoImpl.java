package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;
import com.cg.mra.beans.Account;
import com.cg.mra.exceptions.MobileNumberNotFoundException;

public class AccountDaoImpl {
	Map<String, Account> accountEntry;

	public AccountDaoImpl() {
		accountEntry = new HashMap<>();
		accountEntry.put("9010210131", new Account("Prepaid", "Vaishali", 200));
		accountEntry.put("9823920123", new Account("Prepaid", "Megha", 453));
		accountEntry.put("9932012345", new Account("Prepaid", "Vikas", 631));
		accountEntry.put("9010210131", new Account("Prepaid", "Anju", 521));
		accountEntry.put("9010210131", new Account("Prepaid", "Tushar", 632));
	}

	public Account getAccountDetails(String mobileNumber) {
		Account a1 = accountEntry.get(mobileNumber);// getting mobile number from map
		if (a1 == null) {
			throw new MobileNumberNotFoundException("ERROR : Given account id doesn't exist:)");
		} else {

			return a1;
		}
	}

	public Account rechargeAccount(String mobileNumber, long bal) {
		Account a1 = accountEntry.get(mobileNumber); // getting mobile number from map
		if (a1 == null) {
			throw new MobileNumberNotFoundException("ERROR : Given account id doesn't exist:)");
		} else {
			long a = (long) a1.getAccountBalance();
			long recharge = a + bal;
			a1.setAccountBalance(recharge);
			accountEntry.put(mobileNumber, a1);
			return a1;
		}
	}

}
