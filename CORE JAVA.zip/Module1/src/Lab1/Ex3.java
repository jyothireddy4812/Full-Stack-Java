package Lab1;

import java.util.Scanner;

public class Ex3 {
public static void main(String[] args) {
	int number ;
	Scanner sc=new Scanner(System.in);
	 number=sc.nextInt();
	 Ex3 e=new Ex3();
	 boolean c=e.checkNumber(number);
	System.out.println(c);
}
public static boolean checkNumber(int number) {
	int i=0;

	int p=number;
	int l=number;
	while(p>0) {
		p=p/10;
		i++;
		
	}
for(int j=0;j<i;j++)
{
while(number>0)
{
	int m=number%10;
	number=number/10;
	int q=number;
	int k=q%10;
	if(k>m) {
		j=i+1;
		return false;
	}
	
}
}
return true;
}
}


