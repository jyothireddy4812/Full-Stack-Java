package Lab1;

import java.util.Scanner;

public class Ex2 {
public static void main(String[] args) {
	int n ;
	Scanner sc=new Scanner(System.in);
	 n=sc.nextInt();
	 Ex2 e=new Ex2();
	 int c=Ex2.calculateDifference(n);
	System.out.println(c);
}

public static int calculateDifference(int n) {
	int d=0;
	int d1=0,d2=0;
	int i;
	for(i=0;i<=n;i++) {
		d1=d1+(i*i);
		
	}
	for(i=0;i<=n;i++) {
		d=d+i;
		d2=d*d;
	}
	int sum=d1-d2;
	
return sum;
}

}

