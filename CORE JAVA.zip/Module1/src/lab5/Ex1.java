package lab5;

import java.util.Scanner;

public class Ex1 {
public static void main(String[] args) {
	Scanner c=new Scanner(System.in);
	System.out.println("1.RED");
	System.out.println("2.YELLOW");
	System.out.println("3.GREEN");
	int d=c.nextInt();
	System.out.println(" ");
	switch(d) {
case 1:System.out.println("STOP");
break;
case 2:System.out.println("READY");
break;
case 3:System.out.println("GO");
break;
default:System.out.println("INVALID INPUT");
c.close();
	}
	
}

}
