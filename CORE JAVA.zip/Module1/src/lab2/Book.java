package lab2;


public class Book extends WrittenItem
{
public Book()
{
System.out.println("Core Java Book");
setAuthor("Kishore Kumaar");
setIdNum(543);
setTitle("Basics of Java");
setNoOfCopies(16);
display();
}

public void display()
{
System.out.println("The Name of the Book is "+getTitle());
System.out.println("The Name of the Author is "+getAuthor());
System.out.println("The ID of the Book is "+getIdNum());
System.out.println("No.of Copies available are "+getNoOfCopies());
System.out.println("------------------------------------");
}

}
