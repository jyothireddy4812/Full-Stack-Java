package lab4;

import java.util.Scanner;

public class Ex1 {
	public int sumCubes(int n) {
		int sum=0;
		while(n!=0) {
			int k=n%10;
			sum=sum+(k*k*k);
			n=n/10;
		}
		return sum;
		}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int d=sc.nextInt();
		Ex1 s=new Ex1();
		System.out.println(s.sumCubes(d));
	}
}
