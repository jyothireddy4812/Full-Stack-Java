
package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends RuntimeException {
			
	int salary ;
	public String toString() {

		return "ur salary is less than 3000"+salary;
	}

}
public class Ex6{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the salary");
		int salary=sc.nextInt();
	
		sc.close();
try {
	if(salary<3000) {
		throw new EmployeeException();
		
	}
	else {
		System.out.println("salary:" +salary);
	}}
	catch(ArithmeticException ae) {
		System.out.println(ae);
	}
	System.out.println("remaining code is executed");
	}}

