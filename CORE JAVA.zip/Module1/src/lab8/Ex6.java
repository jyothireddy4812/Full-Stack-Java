package lab8;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Ex6 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Date");
	int day=sc.nextInt();
	System.out.println("Enter Month");
	int month=sc.nextInt();
	System.out.println("Enter Year");
	int year=sc.nextInt();
	LocalDate l1=LocalDate.of(year, month, day);
	LocalDate l2=LocalDate.now();
	Period pr=Period.between(l1, l2);
	System.out.println("Date given by the user: "+day+"."+month+"."+year);
	System.out.println("Current Date: "+LocalDate.now());
	System.out.println("days: "+pr.getDays()+"\nMonths: "+pr.getMonths()+"\nYears: "+pr.getYears());
	sc.close();
}
}