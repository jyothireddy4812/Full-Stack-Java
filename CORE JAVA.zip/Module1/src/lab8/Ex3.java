package lab8;
import java.io.*;

public class Ex3 {
public static void main(String[] args) throws IOException {
	FileWriter f=new FileWriter("CAPGEMINI1.txt");
	PrintWriter pw=new PrintWriter(f);
	pw.println(1000);
	pw.println("EMPLOYEES");
	pw.println("JYOTHIREDDY");
	pw.println("CAPGEMINI");
	pw.println("12345");
	pw.println("WELCOME CAPGEMINI");
	pw.println("HELLO JYOTHIREDDY");
	pw.close();
	FileReader fr=new FileReader("CAPGEMINI1.txt");
	BufferedReader b=new BufferedReader(fr); 
	int linesCount=0;
	int wordsCount=0;
	int charactersCount=0;
	String currentLine=b.readLine();
	while(currentLine!=null)
	{
		linesCount++;
		String[] words= currentLine.split(" ");
		wordsCount=wordsCount+words.length;
		for(String word:words)
		{
			charactersCount=charactersCount+word.length();
		}
		currentLine=b.readLine();
	}
	System.out.println("Total No of characters :"+charactersCount);
	System.out.println("Total No of words :"+wordsCount);
	System.out.println("Total No of lines :"+linesCount);
	b.close();
}
}