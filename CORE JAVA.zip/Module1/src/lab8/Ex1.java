package lab8;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Ex1
{
	


public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter line of numbers");
	String i=sc.next();
	StringTokenizer s= new StringTokenizer(i,"$");
	int sum=0;
	while(s.hasMoreTokens()) {
		int n=0;
		n=Integer.parseInt(s.nextToken());
		System.out.println("number is: "+n);
		sum=sum+n;
	}
	System.out.println("sum of the numbers is: "+sum);
	sc.close();
}


}




