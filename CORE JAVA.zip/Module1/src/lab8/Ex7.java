package lab8;

import java.util.*;

public class Ex7 {
public static void main(String[] args) {
	boolean b=false;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter the name:");
	String name=sc.nextLine();
	name+="_job";
	int i=name.indexOf("_");
	String s=name.substring(0,i);
	System.out.println(s);
	b=validate(s);
	if(b==true)
	{
		System.out.println("Valid Name..."+name);
	}
	else
		System.out.println("Invalid Name..");
	sc.close();
}
static boolean validate(String name)
{
	boolean r=false;
	if(name.length()>8)
	{
		r=true;
	}
	else
	{
		r=false;
	}
	return r;
}
}
