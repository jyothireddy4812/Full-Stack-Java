import java.util.ArrayList;

import org.omg.Messaging.SyncScopeHelper;

/*interface A{
	int add(int a,int b);
}
public class MethodReferenceEx {
public static int sum(int a,int b) {
	return a+b;
}
public static void main(String[] args) {
	A a1=(a,b)->{
		return a+b;};
		System.out.println(a1.add(12, 478));
		A a2=MethodReferenceEx::sum;
		System.out.println(a1.add(72, 47));
}
}*/
//--------------------------------------------
public class MethodReferenceEx {
public static void main(String[] args) {             //StreamApi
	ArrayList<Integer> al=new ArrayList<Integer>();
	al.add(23);
	al.add(67);
	al.add(68);
	al.add(45);
	al.add(02);
	al.add(17);
	al.add(12);
	al.add(44);
	al.add(87);
	al.add(90);
	al.add(13);
	System.out.println(al);
	al.stream().forEach(System.out::println);
}}