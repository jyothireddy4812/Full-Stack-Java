import java.util.ArrayList;
import java.util.function.BiFunction;
import java.util.function.Function;

/*public class FunctionEx {
public static void main(String[] args) {      // input-anything , return- anything
	String s="jyothireddy";
	Function<String,String> f=i->i.toUpperCase();
	Function<String,Integer> f1=(i)->s.length();
	System.out.println(f.apply(s));
	System.out.println(f1.apply(s));
}
}*/

//-------------------------------------------------------
/*public class FunctionEx {
public static void main(String[] args) {  
	Function<Integer,Integer> f=i->2*i; 
	Function<Integer,String> f2=i->""+2*i; //For string
	Function<Integer,Integer> f1=i->i*i*i; 
	System.out.println(f.andThen(f1).apply(3));
	System.out.println(f.compose(f1).apply(3)); //function chaining
	System.out.println(f.andThen(f2).apply(3));

}
}*/

//---------------------------------------------------------
public class FunctionEx {
public static void main(String[] args) {
	ArrayList<Employee1> al=new ArrayList<Employee1>();
	al.add(new Employee1(123,"jyothireddy",50000));
	al.add(new Employee1(124,"Akshitha",45000));
	al.add(new Employee1(125,"shilpa",30000));
	al.add(new Employee1(126,"mahitha",40000));
	BiFunction<Employee1,Double,Double> bic=(emp,sal1)->emp.sal=emp.sal+sal1;
	for(Employee1 e:al) {
		bic.apply(e,10000.00);
	}
	System.out.println(al);
}
}
class Employee1{
	int eid;
	String ename;
	double sal;
	
public Employee1(int eid, String ename, double sal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.sal = sal;
	}

@Override
public String toString() {
	// TODO Auto-generated method stub
	return ename+" "+sal;
}
}