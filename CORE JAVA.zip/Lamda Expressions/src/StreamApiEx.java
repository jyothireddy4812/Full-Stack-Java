import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/*public class StreamApiEx {
public static void main(String[] args) {
	ArrayList<Employee> al=new ArrayList<Employee>();
	al.add(new Employee(123,"jyothireddy",50000));
	al.add(new Employee(124,"Akshitha",45000));
	al.add(new Employee(125,"shilpa",30000));
	al.add(new Employee(126,"mahitha",40000));
	Iterator<Employee> itr=al.iterator();
	while(itr.hasNext()) {
		System.out.println(al);
	}
}
}
class Employee{
	int eid;
	String ename;
	double sal;
	
public Employee(int eid, String ename, double sal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.sal = sal;
	}

@Override
public String toString() {
	// TODO Auto-generated method stub
	return " "+ename+" "+sal+ " "+eid;
}
}*/
//--------------------------------------------------------------------
public class StreamApiEx {
	public static void main(String[] args) { // StreamApi
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(23);
		al.add(67);
		al.add(68);
		al.add(45);
		al.add(02);
		al.add(17);
		al.add(12);
		al.add(44);
		al.add(87);
		al.add(90);
		al.add(13);
		System.out.println(al);
		List<Integer> l = (List<Integer>) al.stream().filter(i -> i % 2 == 0).collect(Collectors.toList());
		System.out.println(l);
		List<Integer> l1 = (List<Integer>) al.stream().map(i -> i * 2).collect(Collectors.toList());
		System.out.println(l1);
		List<Integer> l2 = (List<Integer>) al.stream().filter(i -> i < 50).collect(Collectors.toList());
		System.out.println(l2);
		long numCount = al.stream().filter(i -> i < 50).count();
		System.out.println(numCount);
		List<Integer> l3 = (List<Integer>) al.stream().sorted().collect(Collectors.toList());
		System.out.println(l3);
		List<Integer> l4 = (List<Integer>) al.stream().sorted((i1, i2) -> (i1 < i2) ? 1 : (i1 > i2) ? -1 : 0)
				.collect(Collectors.toList());// descending order
		System.out.println(l4);
		List<Integer> l5 = (List<Integer>) al.stream().sorted((i1, i2) -> -i1.compareTo(i2))
				.collect(Collectors.toList()); // another method for descending
		System.out.println(l5);
		List<Integer> l6 = (List<Integer>) al.stream().sorted((i1, i2) -> i2.compareTo(i1))
				.collect(Collectors.toList()); // another method for descending
		System.out.println(l6);
		Integer minVal = al.stream().min((i1, i2) -> -i1.compareTo(i2)).get();
		System.out.println(minVal);
		Integer maxVal = al.stream().max((i1, i2) -> i2.compareTo(i1)).get();
		System.out.println(maxVal);
		al.stream().forEach(i -> {
			System.out.println("the elements are : " + i);
		});

	}
}