import java.util.ArrayList;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

/*public class ConsumerEx {
public static void main(String[] args) {   // input-anything , return- void
	Consumer<String> con=i-> System.out.println(i);
	con.accept("welcome to capgemini");
	con.accept("JYOTHIREDDY");
}
}*/

//-------------------------------------------------------
public class ConsumerEx {
public static void main(String[] args) {   // input-anything , return- void
	IntConsumer con=i-> System.out.println(i);
	con.accept(123);
	con.accept(456);
}
}

//------------------------------------------------------

/*public class ConsumerEx {
public static void main(String[] args) {
	ArrayList<Employee> al=new ArrayList<Employee>();
	al.add(new Employee(123,"jyothireddy",50000));
	al.add(new Employee(124,"Akshitha",45000));
	al.add(new Employee(125,"shilpa",30000));
	al.add(new Employee(126,"mahitha",40000));
	BiConsumer<Employee,Double> bic=(emp,sal1)->emp.sal=emp.sal+sal1;
	for(Employee e:al) {
		bic.accept(e,10000.00);
	}
	System.out.println(al);
}
}
class Employee{
	int eid;
	String ename;
	double sal;
	
public Employee(int eid, String ename, double sal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.sal = sal;
	}

@Override
public String toString() {
	// TODO Auto-generated method stub
	return ename+" "+sal;
}
}*/