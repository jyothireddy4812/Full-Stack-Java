//import java.util.ArrayList;
import java.util.function.BiPredicate;
import java.util.function.IntPredicate;
//import java.util.function.Predicate;

/*public class PredicateFunctionalInterface {  // input-anything , return- boolean
	public static void main(String[] args) {
		Predicate<Integer> p1=i-> (i%2)==0;
		System.out.println(p1.test(10));
		System.out.println(p1.test(67));
		System.out.println(p1.test(93));
		
	}

}*/

//--------------------------------------------------------

/*public class PredicateFunctionalInterface {
	public static void main(String[] args) {
		String str[]= {"JYOTHIREDDY","MAHITHA","SHILPA","AKSHITHA"};
		Predicate<String> p1=s->s.length()%2 ==0;
		for(String s1:str) {
			if(p1.test(s1)) {
				System.out.println(s1);
			}
		}
}
}*/

//---------------------------------------------------------
/*public class PredicateFunctionalInterface {
	public static void main(String[] args) {
		int x[]= {0,10,8,9,56,38,33,65,92,44,82};
		Predicate<Integer> p1=i-> (i%2)==0;
		Predicate<Integer> p2=i-> i>10;
		System.out.println("numbers greater than 10 and even: ");
	    for(int i1: x) {
			if(p1.and(p2).test(i1)) { //or  //any method we can use
				System.out.println(i1);
			}
			
			if(p1.negate().test(i1)) { //or
				System.out.println(i1);
			}
			
	        if(p1.or(p2).test(i1)) {
				System.out.println(i1);
			}

	}}}*/

//---------------------------------------------------------
/*public class PredicateFunctionalInterface {
	public static void main(String[] args) {
		ArrayList<Employee> al=new ArrayList<Employee>();
		al.add(new Employee(123,"jyothireddy",50000));
		al.add(new Employee(124,"Akshitha",45000));
		al.add(new Employee(125,"shilpa",30000));
		al.add(new Employee(126,"mahitha",40000));
		Predicate<Employee> p=e-> e.sal>10000;
		for(Employee e1:al) {
			if(p.test(e1)) {
				System.out.println(e1.ename+ " "+ e1.eid + " " +e1.sal);
			}
		}
	}
}
class Employee{
	int eid;
	String ename;
	int sal;
	public Employee(int eid, String ename, int sal) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.sal = sal;
	}
	
}*/
//---------------------------------------------------------------------------
/*public class PredicateFunctionalInterface {   //bipredicate
	public static void main(String[] args) {
		BiPredicate<Integer,Integer> p1=(a,b)-> (a+b)%2==0;
		System.out.println(p1.test(10,8));
		System.out.println(p1.test(10,17));
	}
}*/

//------------------------------------------------
public class PredicateFunctionalInterface {   //bipredicate
	public static void main(String[] args) {
		IntPredicate p1=i-> (i%2)==0;
		System.out.println(p1.test(10));
		System.out.println(p1.test(113));
	}
}