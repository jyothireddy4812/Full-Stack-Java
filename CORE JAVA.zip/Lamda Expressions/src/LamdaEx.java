/*interface Add{
	
	public int sum(int a,int b);  //functional interface should have only one abstract method
}
	public class LamdaEx {
	public static void main(String[] args) {
	 Add a1=(a,b)->a+b;
	 System.out.println(a1.sum(2,4));
	}
	}
*/

//------------------------------------------------------

/*interface A{
	
	public int m1(String s);

}
public class LamdaEx {
	public static void main(String[] args) {
		String name;
		System.out.println("enter name");
		Scanner sc=new Scanner(System.in);
	   name=sc.next();
	     A a1=s-> s.length();
	    System.out.println(a1.m1(name));
	    sc.close();
	}
}*/

//---------------------------------------------------------

/*class Thread1 implements Runnable{              //without lamda expression

	@Override
	public void run() {
		for(int i=0;i<=5;i++)
		System.out.println("Jyothireddy");	
	}
	}
public class LamdaEx{
	public static void main(String[] args) {
		Thread1 t1=new Thread1();
		Thread t=new Thread(t1);
		t.start();
		for(int i=0;i<=5;i++)
			System.out.println("Jyothi");
	}
}*/

//----------------------------------------------------------------

/*public class LamdaEx{                                   //with lamda expression
	public static void main(String[] args) {
		Runnable r=()->{
			for(int i=0;i<=5;i++) {
				System.out.println("JYOTHIREDDY");
			}};
		Thread t=new Thread(r);
		t.start();
		for(int i=0;i<=5;i++) {
			System.out.println("jyothireddy");
		}
	}
}*/

//--------------------------------------------------------------------

/*interface Lamda{
	void m1();           //only one abstract method and we can create many static or default methods...
	 default void m2(){
		 for(int i=0;i<=3;i++) {
				System.out.println("interface default method");
		 }
	}
}
public class LamdaEx implements Lamda{

	@Override
	public void m1() {
		System.out.println("LamdaEx class method implementation");
		
	}
  /*----@Override                         
	public void m2() {
		System.out.println("different implementation for interface default method");
		
	}---*/
/*public static void main(String[] args) {
	LamdaEx e=new LamdaEx();
	e.m1();
	e.m2();
}
}*/

//----------------------------------------------------------------------
	
interface Lamda{
	static void m1() {         
		 for(int i=0;i<=3;i++) {
				System.out.println("interface default method");
		 }
	}
	static void m2() {         
		
				System.out.println("Jyothireddy");
		 }
	}

public class LamdaEx implements Lamda{

	public void m1() {
		System.out.println("LamdaEx class method implementation");
		
	}
    public void m2() {
		System.out.println("different implementation for interface default method");
		
	}
public static void main(String[] args) {
	LamdaEx e=new LamdaEx();
	Lamda.m1();
	Lamda.m2();
	e.m1();
	e.m2();
}
}
