package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.LoanDao;

public class LoanService implements ILoanService {
	LoanDao ldao = new LoanDao();

	@Override
	public long insertCust(Customer customer) {
		// TODO Auto-generated method stub
		long details = ldao.insertCust(customer);
		return details;
	}

	@Override
	public long applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		long ldetails = ldao.applyLoan(loan);
		return ldetails;
	}

	public long calculateEMI(double amount, int duration) {
		// TODO Auto-generated method stub
		float r = 0.095f;
		int n = duration * 12;

		double EMI = amount * r * (1 + r) * n / ((1 + r) * (n - 1));

		return (long) EMI;
	}

}
