package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanService {
	long insertCust(Customer customer);

	public long applyLoan(Loan loan);

	long calculateEMI(double amount, int duration);
}
