package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public interface ILoanDao {
	long insertCust(Customer customer);

	public long applyLoan(Loan loan);

}
