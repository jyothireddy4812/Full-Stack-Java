package com.capgemini.xyz.dao;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.xyz.bean.Customer;

public class LoanDaoTest 
{
	
	
	
	
	
	
	
	
	Customer customer=new Customer(12345,"qwerty","hyd",979979,"dasdsd");
	LoanDao dao=new  LoanDao();
	
	
	@Test
	public void getCustomerId()
	{
		long custId=dao.insertCust(customer);
		
	assertEquals(12345, custId);
	
	}
	
	@Test
	public void getCustomerId1()
	{
		long custId=dao.insertCust(customer);
		
	assertEquals(1234, custId);
	
	}
	
	
	
	
	
}
