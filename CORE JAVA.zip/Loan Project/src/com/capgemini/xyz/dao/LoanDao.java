package com.capgemini.xyz.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;

public class LoanDao implements ILoanDao {
	private Map<Integer, Loan> loanEntry;
	private Map<Integer, Customer> customerEntry;

	public LoanDao() { // default constructor
		customerEntry = new HashMap<Integer, Customer>();
		loanEntry = new HashMap<Integer, Loan>();

	}

	@Override
	public long insertCust(Customer customer) {
		// TODO Auto-generated method stub
		customerEntry.put((int) customer.getCustId(), customer);
		return customer.getCustId();
	}

	@Override
	public long applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		loanEntry.put((int) loan.getLoanId(), loan);
		return loan.getLoanId();
	}

}
