package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.service.LoanService;

public class ExecuterMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LoanService service = new LoanService();
		System.out.println("XYZ Finance Company Welcomes You");
		while (true) {
			System.out.println("1.Register Customer\n2.Exit");
			System.out.println("please enter your choice");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter customer name");
				String custName = sc.next();
				System.out.println("enter address");
				String address = sc.next();
				System.out.println("enter mobile number");
				long mobile = sc.nextLong();
				System.out.println("enter email");
				String email = sc.next();
				long custId = (long) (Math.random() * 10000);
				Customer customer = new Customer(custId, custName, address, mobile, email);
				service.insertCust(customer);
				System.out.println(
						"customer information saved successfully,your customer Id is<" + customer.getCustId() + ">");
				System.out.println("Do you wish to apply for loan?1.yes\n2.no");
				int opt = sc.nextInt();
				switch (opt) {
				case 1:
					System.out.println("enter the loan amount");
					double amount = sc.nextInt();
					System.out.println("enter the loan duration");
					int duration = sc.nextInt();

					long EMI = service.calculateEMI(amount, duration);

					System.out.println("for loan amount" + amount + "  " + "and no of years" + "  " + duration + "  "
							+ "Your EMI per month will be" + "  " + EMI + " "
							+ "do you want to apply for loan now?1.yes\n2.no");
					int a = sc.nextInt();
					switch (a) {
					case 1:
						long loanId = (long) (Math.random() * 10000);
						Loan loan = new Loan(loanId, amount, custId, duration);
						service.applyLoan(loan);
						System.out.println("your loan request is now generated.your loan id is" + loanId);
						System.out.println("customer id is:" + " " + customer.getCustId());
						System.out.println("customer address is:" + " " + customer.getAddress());
						System.out.println("customer mobile number is:" + " " + customer.getMobile());
						System.out.println("customer email is:" + " " + customer.getEmail());
						System.out.println("loan id is" + " " + loan.getLoanId());
						System.out.println("loan amount is:" + " " + loan.getLoanAmount());
						System.out.println("loan duration is" + " " + loan.getDuration());
						break;

					case 2:
						System.out.println("Thankyou");
						// break;
					}
					break;
				case 2:
					System.out.println(customer);

				}

				break;
			case 2:
				System.exit(0);
				break;
			}
			
		}

	}

}
