import java.util.Iterator;
//import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;


	public class CopyOnWriteArrayListandSetEx1 extends Thread {
		//static CopyOnWriteArrayList<String> co=new CopyOnWriteArrayList<String>();
		static CopyOnWriteArraySet<String> co=new CopyOnWriteArraySet<String>();
		
		public void run() {
			try {
				Thread.sleep(2000);
			}catch(InterruptedException ie) {
				ie.printStackTrace();
				}
				System.out.println("child thread updating Co");
				co.add("CAPGEMINI");
				}
			public static void main(String[] args)  throws InterruptedException {
				co.add("JYOTHIREDDY");
				co.add("AKSHITHA");
				co.add("SHILPA");
				co.add("MAHITHA");
				CopyOnWriteArrayListandSetEx1 c1=new CopyOnWriteArrayListandSetEx1();
	            c1.start();
	       
	            Iterator<String> itr=co.iterator();
	            while(itr.hasNext()) {
	            	String values=(String) itr.next();
	            	System.out.println("main thread iterating co values......"+values);
	            	
	            	Thread.sleep(1000);
	            	System.out.println(co);
	            }
			}
		}


