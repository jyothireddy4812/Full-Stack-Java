import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListEx {
public static void main(String[] args) {
	ArrayList<String> a1=new ArrayList<String>();
	a1.add("JYOTHIREDDY");
	a1.add("AKSHITHA");
	a1.add("SHILPA");
	a1.add("MAHITHA");
	System.out.println(a1);
	CopyOnWriteArrayList<String> c=new CopyOnWriteArrayList<String>();
	c.addIfAbsent("JYOTHI");
	c.add("AKSHITHA");
	c.addIfAbsent("SHILPA");
	c.add("MAHITHA");
	System.out.println(c);
	c.addAllAbsent(a1);
	System.out.println(c);
	ArrayList<String> a=new ArrayList<String>();
	a.add("JYOTHIREDDY");
	a.add("AKSHITHA");
	a1.add("SHILPA");
	System.out.println(a);
	c.addAllAbsent(a);
	System.out.println(c);
	
}
}
