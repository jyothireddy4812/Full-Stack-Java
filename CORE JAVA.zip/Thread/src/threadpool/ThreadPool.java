package threadpool;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPool {
public static void main(String[] args) {
	//ExecutorService s=Executors.newFixedThreadPool(20);
	//ExecutorService s=Executors.newCachedThreadPool();
	ExecutorService s=Executors.newSingleThreadExecutor();
	for(int i=0;i<100;i++) {
		s.execute(new Task());
	}
		System.out.println("JYOTHI REDDY");
	}
}
class Task implements Runnable{

	@Override
	public void run() {
	System.out.println("Thread name: "+Thread.currentThread().getName());
	System.exit(0);	
	}
	
}

