package concurrenthashmap;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapEx2 extends Thread {
	static ConcurrentHashMap<Integer, String> c=new ConcurrentHashMap<Integer, String>();
	//static ConcurrentHashMap<Integer, String> c=new ConcurrentHashMap<Integer, String>();
	public void run() {
		try {
			Thread.sleep(2000);
		}catch(InterruptedException ie) {
			ie.printStackTrace();
			}
			System.out.println("child thread got chance");
			c.put(123, "welcome to capgemini");
			}
		public static void main(String[] args)  throws InterruptedException {
			c.put(123, "jyothireddy");
			c.put(234, "shilpa");
			c.put(345, "mahitha");
			ConcurrentHashMapEx2 c1=new ConcurrentHashMapEx2();
            c1.start();
            Set<Integer> s=c.keySet();
            Iterator<Integer> itr=s.iterator();
            while(itr.hasNext()) {
            	Integer i=(Integer) itr.next();
            	System.out.println("main thread iterating......");
            	System.out.println("current key is..." +i+ "and value: " +c.get(i));
            	Thread.sleep(1000);
            	System.out.println(c);
            }
		}
	}


