package concurrenthashmap;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapEx {
public static void main(String[] args) {
	ConcurrentHashMap<Integer, String> c=new ConcurrentHashMap<Integer, String>();
	c.put(123, "jyothireddy");
	c.put(234, "shilpa");
	c.put(345, "mahitha");
	
	System.out.println(c);
	c.putIfAbsent(123, "akshitha");
	System.out.println(c);
	boolean b=c.remove(123, "jyothireddy");
	System.out.println(b);

}
}
