package threads;

 class Thread1 implements Runnable{

	@Override
	public void run() {
		for(int i=1;i<10;i++) {
System.out.println("JYOTHIREDDY");
		
	}
 }}
 class ThreadEx1 extends Thread{

	public void run() {
		for(int i=1;i<10;i++) {
System.out.println("User thread"+Thread.currentThread());
		
	}
	}}
class ThreadEx{
	public static void main(String[] args) throws InterruptedException {
		Thread1 t=new Thread1();
		Thread t1=new Thread(t);
		ThreadEx1 t2=new ThreadEx1();
		t1.start();
		t2.start();
		t1.join();
		t2.join();
		for(int i=1;i<10;i++) {
		System.out.println("main thread");
		}
	/*	for(int i=1;i<10;i++) {
			Thread.currentThread().setName("JAVA");
			Thread.currentThread().setPriority(2);
			System.out.println("Main thread"+Thread.currentThread());
			
		}*/
		
		
	}
}