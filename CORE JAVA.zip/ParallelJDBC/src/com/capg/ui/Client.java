package com.capg.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import com.capg.bean.TransactionDetails;
import com.capg.bean.UserDetails;
import com.capg.exception.AccountNotFoundException;
import com.capg.service.WalletServiceImpl;
import com.capg.service.WalletServiceInterface;

public class Client {
	public int getOption(Scanner sc) {
		try {
			int option = sc.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int option;
		Random r = new Random();// random method used for creating a random account number
		Scanner sc = new Scanner(System.in);
		WalletServiceInterface c = new WalletServiceImpl();
		LocalDate date = LocalDate.now();
		LocalTime time = LocalTime.now();
		UserDetails userDetails;
		TransactionDetails transfer;
		do {
			System.out.println("------------XYZ BANK-----------");
			System.out.println("******BANK WALLET APPLICATION*******");
			System.out.println("1.CREATE ACCOUNT");
			System.out.println("2.SHOW BALANCE");
			System.out.println("3.DEPOSIT MONEY");
			System.out.println("4.WITHDRAW MONEY");
			System.out.println("5.FUND TRANSFER");
			System.out.println("6.PRINT TRANSACTIONS");
			System.out.println("7.EXIT");
			System.out.println("ENTER YOUR CHOICE");
			option = sc.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter your name:");
				String name = c.validationName(sc.next());
				System.out.println("Enter your mobile number:");
				long mblNo = c.validationMblNo(sc.nextLong());

				int accNo = r.nextInt(100000000);// limit
				System.out.println("Enter your initial amount: ");
				double balance = c.validationBal((sc.nextDouble()));// validating the balance which is greater than zero
																	// or not
				int transId = r.nextInt(10000);
				userDetails = new UserDetails(name, mblNo, accNo, balance);
				transfer = new TransactionDetails(transId, accNo, "Account created successfully!!! Date: " + date
						+ " Time: " + time + " Rs." + balance + " was initially deposited...");

				c.createAccount(userDetails, transfer);// passing the details to service
														// class
				System.out.println("\n");
				System.out.println("------------------------------------------------------------");
				System.out.println("Thank you " + name + " Your Account is created Successully");
				System.out.println("Your Account Id " + accNo);
				System.out.println("------------------------------------------------------------");
				break;
			case 2:
				try {
					System.out.println("Enter your account number: ");
					accNo = sc.nextInt();
					double balance_1 = c.showBalance(accNo);// passing the argument to service class
					System.out.println("\n");
					System.out.println("------------------------------------------------------------");
					System.out.println("Your Current Account Balance is " + balance_1);
					System.out.println("------------------------------------------------------------");
				} catch (AccountNotFoundException ex) {
					System.out.println(ex.getMessage());
				}
				break;
			case 3:
				try {
					System.out.println("Enter your account number: ");
					accNo = sc.nextInt();
					System.out.println("Enter your deposit amount: ");
					balance = c.validationBal(sc.nextDouble());// validating the balance which is greater than zero or
																// not
					int transId_1 = r.nextInt(10000);
					transfer = new TransactionDetails(transId_1, accNo,
							"Amount deposited Rs." + balance + " Date:" + date + " Time:" + time);
					double balance_2 = c.depositBalance(accNo, balance, transfer);// passing the arguments to service
																					// class
					System.out.println("\n");
					System.out.println("------------------------------------------------------------");
					System.out.println("Your Amount is Deposited Succesfully");
					System.out.println("Your Current Account Balance is " + balance_2);
					System.out.println("------------------------------------------------------------");
				} catch (AccountNotFoundException ex) {
					System.out.println(ex);
				}
				break;
			case 4:
				try {
					System.out.println("Enter the account number: ");
					accNo = sc.nextInt();
					System.out.println("Enter your withdraw amount: ");
					balance = c.validationBal(sc.nextDouble());// validating the balance which is greater than zero or
																// not
					int transId_2 = r.nextInt(10000);
					transfer = new TransactionDetails(transId_2, accNo,
							"Amount withdrawn Rs." + balance + " Date:" + date + " Time:" + time);
					double balance_3 = c.withdrawBalance(accNo, balance, transfer);// passing the arguments to service
																					// class
					System.out.println("\n");
					System.out.println("------------------------------------------------------------");
					System.out.println("Your Amount is Withdrawn Succesfully");
					System.out.println("Your Current Account Balance is " + balance_3);
					System.out.println("------------------------------------------------------------");
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid account number...");
				} catch (Throwable ex) {
					ex.printStackTrace();
				}
				break;
			case 5:
				try {
					System.out.println("Enter your account number: ");
					accNo = sc.nextInt();
					System.out.println("Enter the account number to transfer: ");
					int accNo1 = sc.nextInt();
					System.out.println("Enter the transfer amount: ");
					balance = sc.nextDouble();

					int transId_3 = r.nextInt(10000);
					int transId_4 = r.nextInt(10000);
					TransactionDetails transfer_1 = new TransactionDetails(transId_3, accNo, "Amount sent Rs." + balance
							+ " Date:" + date + " Time:" + time + " was set to " + accNo1 + " succesfully.");
					TransactionDetails transfer_2 = new TransactionDetails(transId_4, accNo, "Amount sent Rs." + balance
							+ " Date:" + date + " Time:" + time + " was set to " + accNo1 + " succesfully.");

					double balance_4 = c.fundTransfer(accNo, accNo1, balance, transfer_1, transfer_2);
					System.out.println("\n");
					System.out.println("------------------------------------------------------------");
					System.out.println("Your Amount is Transferred Succesfully");
					System.out.println("Your Current Account Balance is " + balance_4);
					System.out.println("------------------------------------------------------------");
				} catch (AccountNotFoundException e) {
					System.out.println("Invalid account number...");
				}
				break;
			case 6:
				System.out.println("Enter your account number: ");
				accNo = sc.nextInt();
				@SuppressWarnings("rawtypes")
				ArrayList list = c.printTransaction(accNo);
				System.out.println("\n");
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				System.out.println("TransactionID		AccountNumber		Message");
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				for (Object i : list)
					System.out.println(i + "\n");
				System.out.println(
						"--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
				break;
			case 7:
				System.out.println("Thank for using our service!!!");
				System.out.println("Regards\nXYZ BANK WALLET...");
				break;
			default:
				System.out.println("Please give feedback to application");
				break;
			}
		} while (option != 7);
		sc.close();
	}
}
