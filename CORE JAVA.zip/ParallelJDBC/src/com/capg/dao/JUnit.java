package com.capg.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

public class JUnit {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	WalletDao dao = new WalletDao();

	@Test
	public void getBalanceById() throws ClassNotFoundException, SQLException {
		double balance = dao.showBalance(83880226);
		// fail("Not yet implemented");
		// assertNotNull(bean);
		assertTrue(10200 == balance);//Junit pass
	}
}
