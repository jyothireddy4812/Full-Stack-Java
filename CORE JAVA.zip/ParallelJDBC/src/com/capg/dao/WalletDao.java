package com.capg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capg.bean.TransactionDetails;
import com.capg.bean.UserDetails;

public class WalletDao implements WalletDaoInterface {

	UserDetails userDetails;
	WalletDB db = new WalletDB();
	Connection conn;

	@Override
	public void createAccount(UserDetails userDetails, TransactionDetails transfer)
			throws SQLException, ClassNotFoundException {
		conn = db.getConnection();
		PreparedStatement prepareStatement = conn.prepareStatement("insert into userDetails values(?,?,?,?)");
		prepareStatement.setString(1, userDetails.getName());
		prepareStatement.setLong(2, userDetails.getMblNo());
		prepareStatement.setInt(3, userDetails.getAccNo());
		prepareStatement.setDouble(4, userDetails.getBalance());
		prepareStatement.execute();

		prepareStatement = conn.prepareStatement("insert into transferDetails values(?,?,?)");
		prepareStatement.setInt(1, transfer.getTransId());
		prepareStatement.setInt(2, transfer.getAccNo());
		prepareStatement.setString(3, transfer.toString());
		prepareStatement.execute();
	}

	@Override
	public double showBalance(int accNo) throws ClassNotFoundException, SQLException {
		conn = db.getConnection();
		PreparedStatement prepareStatement = conn.prepareStatement("select balance from userDetails where accNo=?");
		prepareStatement.setInt(1, accNo);
		ResultSet rs = prepareStatement.executeQuery();
		rs.next();
		return rs.getDouble("balance");
	}

	@Override
	public double depositBalance(int accNo, double balance, TransactionDetails transfer)
			throws ClassNotFoundException, SQLException {
		conn = db.getConnection();

		PreparedStatement prepareStatement = conn
				.prepareStatement("update userDetails set balance=balance+? where accNo=?");
		prepareStatement.setDouble(1, balance);
		prepareStatement.setInt(2, accNo);
		prepareStatement.executeUpdate();

		prepareStatement = conn.prepareStatement("insert into transferDetails values(?,?,?)");
		prepareStatement.setInt(1, transfer.getTransId());
		prepareStatement.setInt(2, transfer.getAccNo());
		prepareStatement.setString(3, transfer.toString());
		prepareStatement.execute();

		return showBalance(accNo);
	}

	@Override
	public double withdrawBalance(int accNo, double balance, TransactionDetails transfer)
			throws ClassNotFoundException, SQLException {
		conn = db.getConnection();

		PreparedStatement prepareStatement = conn
				.prepareStatement("update userDetails set balance=balance-? where accNo=?");
		prepareStatement.setDouble(1, balance);
		prepareStatement.setInt(2, accNo);
		prepareStatement.executeUpdate();

		prepareStatement = conn.prepareStatement("insert into transferDetails values(?,?,?)");
		prepareStatement.setInt(1, transfer.getTransId());
		prepareStatement.setInt(2, transfer.getAccNo());
		prepareStatement.setString(3, transfer.toString());
		prepareStatement.execute();

		return showBalance(accNo);
	}

	@Override
	public double fundTransfer(int accNo, int accNo1, double balance, TransactionDetails transfer_1,
			TransactionDetails transfer_2) throws ClassNotFoundException, SQLException {

		conn = db.getConnection();

		PreparedStatement prepareStatement = conn
				.prepareStatement("update userDetails set balance=balance-? where accNo=?");
		prepareStatement.setDouble(1, balance);
		prepareStatement.setInt(2, accNo);
		prepareStatement.executeUpdate();

		prepareStatement = conn.prepareStatement("insert into transferDetails values(?,?,?)");
		prepareStatement.setInt(1, transfer_1.getTransId());
		prepareStatement.setInt(2, transfer_1.getAccNo());
		prepareStatement.setString(3, transfer_1.toString());
		prepareStatement.execute();

		prepareStatement = conn.prepareStatement("update userDetails set balance=balance+? where accNo=?");
		prepareStatement.setDouble(1, balance);
		prepareStatement.setInt(2, accNo1);
		prepareStatement.executeUpdate();

		prepareStatement = conn.prepareStatement("insert into transferDetails values(?,?,?)");
		prepareStatement.setInt(1, transfer_2.getTransId());
		prepareStatement.setInt(2, transfer_2.getAccNo());
		prepareStatement.setString(3, transfer_2.toString());
		prepareStatement.execute();

		return showBalance(accNo);

	}

	@SuppressWarnings("rawtypes")
	@Override
	public ArrayList printTransaction(int accNo) throws ClassNotFoundException, SQLException {
		conn = db.getConnection();
		ArrayList<String> list = new ArrayList<String>();
		String str = "";
		PreparedStatement preparedStatement = conn.prepareStatement("select * from transferDetails where accNO=?");
		preparedStatement.setInt(1, accNo);
		ResultSet res = preparedStatement.executeQuery();
		while (res.next()) {
			str = String.valueOf(res.getInt(1) + "\t\t\t");
			str += res.getInt(2)+"\t\t\t";
			str += res.getString(3);
			list.add(str);
		}
		return list;
	}

}
