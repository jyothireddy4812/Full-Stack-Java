package com.capg.bean;

public class UserDetails {
	private String name;
	private long mblNo;
	private double balance;
	private int accNo;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMblNo() {
		return mblNo;
	}

	public void setMblNo(long mblNo) {
		this.mblNo = mblNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public UserDetails(String name, long mblNo, int accNo, double balance) {
		this.accNo = accNo;
		this.name = name;
		this.mblNo = mblNo;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "UserDetails [name=" + name + ", mblNo=" + mblNo + ", balance=" + balance + ", accNo=" + accNo + "]";
	}

	public UserDetails() {
		// TODO Auto-generated constructor stub

	}
}