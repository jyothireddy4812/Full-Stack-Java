package Final;

 class A {
	 
int a=456;
public void m1() {
	this.a=++a;
	System.out.println(a);
}
}
 public class Final extends A
 {
	 public void m1() {
			this.a =--a;
			System.out.println(a); 
 }
	 public static void main(String[] args) {
		Final t=new Final();
		t.m1();
		A a=new A();
		a.m1();
	}
 }
