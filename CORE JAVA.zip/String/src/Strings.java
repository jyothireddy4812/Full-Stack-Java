
public class Strings {
	public static void main(String[] args) {
		StringBuffer s=new StringBuffer("CAPGEMINI");
		StringBuffer s1=new StringBuffer("ibm");
		System.out.println(s.equals(s1));//false
		System.out.println(s==s1);//false
		System.out.println(s);
		//s.append("BANGALORE");
		System.out.println(s);
		
		String r=new String("JYOTHIREDDY");
		String r1=new String("JYOTHIREDDY");
		System.out.println(r.equals(r1));//true
		String sr=s.toString();	
		String sr1=s1.toString();
		System.out.println(sr.equals(sr1));
		System.out.println(sr==sr1);
		
		
		
	}
	

}
