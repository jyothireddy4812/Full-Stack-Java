

		public class Strings1 {
			public static void main(String[] args) {
				/*StringBuffer s=new StringBuffer("CAPGEMINI");
				StringBuffer s1=new StringBuffer("ibm");
				System.out.println(s.equals(s1));//false
				System.out.println(s==s1);//false
				System.out.println(s);
				//s.append("BANGALORE");
				System.out.println(s);*/
				
				String r=new String("JYOTHIREDDY");
				String r1=new String("lion");
		
				int sr=r.compareTo(r1);	
				System.out.println(sr);
				int sr1=r1.length();
				System.out.println(sr1);
				String sr2=r.toLowerCase();
				System.out.println(sr2);
				String sr3=r1.toUpperCase();
				System.out.println(sr3);
				System.out.println(r.codePointBefore(4));
				System.out.println(r.codePointCount(2,6));
				System.out.println(r.isEmpty());
				System.out.println(r.offsetByCodePoints(3,8));
				System.out.println(r.hashCode());
				System.out.println(r.equals(r1));
				System.out.println(r.indexOf('Y'));
				System.out.println(r.lastIndexOf('Y'));
				System.out.println(r.contentEquals(r1));
				System.out.println(r.equalsIgnoreCase("jyothireddy"));
				System.out.println(r.compareTo(r1));
				System.out.println(r.compareToIgnoreCase(r1));
				System.out.println(r.regionMatches(0, "JYOTHIREDDY", 2 ,4));
				System.out.println(r.startsWith("JYOTHIREDDY",2));
				System.out.println(r.startsWith("JYOTHI"));
				System.out.println(r.trim());
				
				
			}
			

	}


