import static org.junit.Assert.*;
import org.junit.Test;
public class JUnitEx {
Add t=new Add();
int i=t.sum(383,666);
int j=1049;
@Test
public void testSum() {
	System.out.println("sum is :"+i +"="+j);
	assertEquals(i,j);
}
}
