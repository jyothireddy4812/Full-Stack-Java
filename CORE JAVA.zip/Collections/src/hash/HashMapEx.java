package hash;

//import java.util.HashMap;
//import java.util.LinkedHashMap;
import java.util.TreeMap;

public class HashMapEx {
	public static void main(String[] args) {
		// HashMap hm=new HashMap();
		// LinkedHashMap hm=new LinkedHashMap();
		TreeMap<String, Integer> hm = new TreeMap<String, Integer>();
		hm.put("JYOTHIREDDY", 50000);
		hm.put("SHILPA", 30000);
		hm.put("AKSHITHA", 10);
		hm.put("MAHITHA", 40000);
		hm.put("JYOTHIREDDY", 500001);
		System.out.println(hm);
		// HashMap h1=new HashMap();
		// LinkedHashMap h1=new LinkedHashMap();
		TreeMap<String, Integer> h1 = new TreeMap<String, Integer>();
		h1.put("JYOTHI", 9293);
		h1.put("PADMAVATHI", 456);
		h1.put("AKSHI", 1890);
		h1.put("MAHI", 409);
		h1.put("JYOTHIREDDY", 5098);
		System.out.println(h1);
		// h1.putAll(hm);
		// System.out.println(h1);
		// System.out.println(h1.get("MAHI"));
		// h1.remove("JYOTHIREDDY");
		// System.out.println(h1.remove("JYOTHIREDDY"));
		System.out.println(h1.containsKey("JYOTHIREDDY"));
		System.out.println(h1.containsValue(5098));
		System.out.println(h1.isEmpty());
		System.out.println(h1.size());
		System.out.println(hm.keySet());
		System.out.println(h1.entrySet());
		System.out.println(h1.values());
	}
}
