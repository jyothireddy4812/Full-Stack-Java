package hash;

import java.util.Comparator;
import java.util.Iterator;
//import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapCustomizedEx {
public static void main(String[] args) {
	TreeMap<String, Integer> hm=new TreeMap<String, Integer>(new A());
	hm.put("JYOTHIREDDY", 50000);
	hm.put("SHILPA", 30000);
	hm.put("AKSHITHA", 10);
	hm.put("MAHITHA", 40000);
	hm.put("JYOTHIREDDY", 500001);
	System.out.println(hm);
	/*Set s= hm.entrySet(); // for entryset
	Iterator itr=s.iterator();
	while(itr.hasNext()) {
		Entry e=(Entry) itr.next();
		System.out.println(e1.getKey()+" "+e1.getValue());
		}*/

	Set<String> s1= hm.keySet();//for keyset
	Iterator<String> itr1=s1.iterator();
	while(itr1.hasNext()) {
	
		System.out.println(itr1.next());
	}
}
}
class A implements Comparator{
	public int compare(Object o1,Object o2) {
		String s1=(String)o1;
		String s2=(String)o2;
		return s2.compareTo(s1);
}}