package treeset;

import java.util.Comparator;
import java.util.TreeSet;

public class ComparatorEx {
public static void main(String[] args) {
	TreeSet<String> a1=new TreeSet<String>(new A());
	a1.add("JYOTHIREDDY");
	a1.add("AKSHITHA");
	a1.add("SHILPA");
	a1.add("MAHITHA");	
System.out.println(a1);
}
}
class A implements Comparator{
	public int compare(Object o1,Object o2) {
		String s1=(String)o1;
		String s2=(String)o2;
	/*	if(i1<i2)               //for integer values
			return +666;
		else if(i1>i2)
			return -666;
		else 
			return 0;*/
		//return -s1.compareTo(s2);
		return s2.compareTo(s1);
	
}
}
