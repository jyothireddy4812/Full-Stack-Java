package treeset;

import java.util.TreeSet;

public class ComparableEx {
public static void main(String[] args) {
	TreeSet<String> a1=new TreeSet<String>();
	a1.add("JYOTHIREDDY");
	a1.add("AKSHITHA");
	a1.add("SHILPA");
	a1.add("MAHITHA");
	/*returns -ve=> obj1 has to come before obj2
	returns +ve=> obj1 has to come after obj2
	returns 0=> both are same*/
	System.out.println("JYOTHIREDDY".compareTo("SHILPA"));
	System.out.println("SHILPA".compareTo("AKSHITHA"));
	System.out.println("JYOTHIREDDY".compareTo("MAHITHA"));
	System.out.println("JYOTHIREDDY".compareTo("JYOTHIREDDY"));
	
	
	
	
}
}
