package collections;

import java.util.ArrayList;

public class ListMethods {
public static void main(String[] args) {
	ArrayList<String> a1=new ArrayList<String>();
	a1.add("JYOTHIREDDY");
	a1.add("AKSHITHA");
	a1.add("SHILPA");
	a1.add("MAHITHA");
	a1.add("JYOTHIREDDY");
	ArrayList a=new ArrayList();
	a.add(1223);
	a.add('s');
	a.add(false);
	a.add("abc");
	a.add(383666);
	//System.out.println(a1.get(4));
	//a1.remove(0);
	//System.out.println(a1);
	//a1.add(5,"jyo");
	//System.out.println(a1);
	//a.addAll(2,a1);
	//System.out.println(a);
	//a.set(2,"jyo");
	//System.out.println(a);

	System.out.println(a1.lastIndexOf("JYOTHIREDDY"));
	
}
}
