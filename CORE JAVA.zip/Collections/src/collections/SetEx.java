package collections;

//import java.util.HashSet;
import java.util.LinkedHashSet;
//import java.util.TreeSet;

public class SetEx {
public static void main(String[] args) {
	//HashSet a1=new HashSet();
	//TreeSet a1=new TreeSet();
	LinkedHashSet<String> a1=new LinkedHashSet<String>();
	a1.add("JYOTHIREDDY");
	a1.add("AKSHITHA");
	a1.add("SHILPA");
	a1.add("MAHITHA");
	a1.add("JYOTHIREDDY");
	System.out.println(a1);
}
}
