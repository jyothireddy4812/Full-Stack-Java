package collections;

public class TaskEx{
	private int empid;
	private String ename;
	private int sal;
	public TaskEx(int empid, String ename, int sal) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.sal = sal;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub

	
	return ""+empid+ ""+ename+ ""+sal;
}
}