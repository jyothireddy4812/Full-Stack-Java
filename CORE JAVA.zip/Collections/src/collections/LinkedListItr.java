package collections;

import java.util.ArrayList;
import java.util.ListIterator;

public class LinkedListItr {
	public static void main(String[] args) {
		ArrayList<String> a1=new ArrayList<String>();
		a1.add("JYOTHIREDDY");
		a1.add("AKSHITHA");
		a1.add("SHILPA");
		a1.add("MAHITHA");
		a1.add("JYOTHIREDDY");
		System.out.println(a1);
		ListIterator<String> litr=a1.listIterator();

		while(litr.hasNext())//in forward direction
		{
			System.out.println(litr.next()+" ");
			}	
	System.out.println("***********************************");
		while(litr.hasPrevious()) {  	//in backward direction
			String val=(String) litr.previous();
			if(val.equals("JYOTHIREDDY")) {
				litr.set("CAPGEMINI");
				System.out.println(litr.next());
				litr.previous();
				
			}else
			{
			System.out.println(val);
		}}

}}
