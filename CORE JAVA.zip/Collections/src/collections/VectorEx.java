package collections;

//import java.util.Enumeration;
//import java.util.Iterator;
//import java.util.ListIterator;
import java.util.Vector;

public class VectorEx {
	public static void main(String[] args) {
		Vector<String> a1=new Vector<String>();
		a1.add("SHILPA");
		a1.add("JYOTHIREDDY");
		a1.add("AKSHITHA");
		a1.add("JYOTHIREDDY");
		a1.add("MAHITHA");
		//a1.addElement("jyo");
		//System.out.println(a1);
		//a1.removeAllElements();
		//System.out.println(a1);
		//a1.removeElement("AKSHITHA");
		//System.out.println(a1);
		//a1.removeElementAt(4);
		//System.out.println(a1);
		//System.out.println(a1.elementAt(4));
		//System.out.println(a1.firstElement());
		//System.out.println(a1.lastElement());
		//System.out.println(a1.size());
		//System.out.println(a1.capacity());
		System.out.println(a1);
	/*	Enumeration days=a1.elements();
		while(days.hasMoreElements()) {
			System.out.println(days.nextElement());
		}     */
/*	Iterator itr=a1.iterator();
	while(itr.hasNext())
	{
		String name=(String) itr.next();
	if(name.equals("JYOTHIREDDY")){	
			itr.remove();
	}else {
		System.out.println(name);*/
	}



}
