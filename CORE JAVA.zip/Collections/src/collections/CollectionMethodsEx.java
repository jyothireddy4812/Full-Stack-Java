package collections;

import java.util.ArrayList;

public class CollectionMethodsEx {
	public static void main(String[] args) {
		ArrayList<String> a1=new ArrayList<String>();
		a1.add("JYOTHIREDDY");
		a1.add("AKSHITHA");
		a1.add("SHILPA");
		a1.add("MAHITHA");
		a1.add("JYOTHIREDDY");
		ArrayList a=new ArrayList();
		a.add(1223);
		a.add('s');
		a.add(false);
		a.add("abc");
		a.add(383666);
		a.addAll(a1);
	System.out.println(a);
	//a.removeAll(a1);
	//System.out.println(	a);
	//a1.clear();
	//System.out.println(a1);
	//System.out.println(	a.isEmpty());
	//System.out.println(	a.size());
	//a.retainAll(a1);
	//System.out.println(a);
	//a.remove("abc");
	//System.out.println(a);
	System.out.println(a.containsAll(a1));
	
	
	}
}
