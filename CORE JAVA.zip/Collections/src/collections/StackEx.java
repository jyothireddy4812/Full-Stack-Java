package collections;

import java.util.Stack;

public class StackEx {
	public static void main(String[] args) {
		Stack<String> a1=new Stack<String>();
		a1.add("JYOTHIREDDY");
		a1.add("AKSHITHA");
		a1.add("SHILPA");
		a1.add("JYOTHIREDDY");
		a1.add("MAHITHA");
		
		//a1.push("JYOTHI");
		//System.out.println(a1);

		//System.out.println(a1.pop());
		System.out.println(a1.peek());
		System.out.println(a1.empty());
		//System.out.println(a1.search("MAHITHA"));
}
}
