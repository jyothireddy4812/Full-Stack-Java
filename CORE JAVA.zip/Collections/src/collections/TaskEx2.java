package collections;

import java.util.ArrayList;

public class TaskEx2 {
	public static void main(String[] args) {
		TaskEx t=new TaskEx(123,"JYOTHIREDDY",10000);
		TaskEx u=new TaskEx(124,"MAHITHA",10000);
		TaskEx v=new TaskEx(125,"SHILPA",10000);
		TaskEx w=new TaskEx(126,"AKSHITHA",10000);
		ArrayList<TaskEx> a1=new ArrayList<TaskEx>();
		a1.add(t);
		a1.add(u);
		a1.add(v);
		a1.add(w);
		System.out.println(a1);
		
	}

}
