package collections;

import java.util.LinkedList;

public class LinkedListEx {
	public static void main(String[] args) {
		LinkedList<String> a1=new LinkedList<String>();
		a1.add("JYOTHIREDDY");
		a1.add("AKSHITHA");
		a1.add("SHILPA");
		a1.add("JYOTHIREDDY");
		a1.add("MAHITHA");
		
		//a1.addFirst("AKSHITHA");
		//System.out.println(a1);
		//a1.addLast("AKSHITHA");
		//System.out.println(a1);
		//System.out.println(a1.getFirst());
		//System.out.println(a1.getLast());
		System.out.println(a1.removeFirst());
		System.out.println(a1.removeLast());
	}

}
