package queue;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueEx {
	public static void main(String[] args) {
		PriorityQueue<String> a1=new PriorityQueue<String>();
		a1.add("JYOTHIREDDY");
		a1.add("AKSHITHA");
		a1.add("SHILPA");
		a1.add("MAHITHA");	
		System.out.println(a1);
		System.out.println(a1.element());
		System.out.println(a1.peek());
		System.out.println("head:"+a1.poll());//null
		System.out.println("head:"+a1.remove());//exception
		System.out.println(a1);
		System.out.println("iterating the queue elements:");
		Iterator<String> itr=a1.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
