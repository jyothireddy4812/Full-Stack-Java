package employeedetails;

public interface EmployeeDetailsInterface {

}
