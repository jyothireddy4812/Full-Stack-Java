package employeedetails;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import employeebean.EmployeeBean;

public class EmployeeDetails {
	
public static void main(String[] args) {
	EmployeeBean eb=new EmployeeBean();
	EmployeeBean eb1=new EmployeeBean(123,"JYOTHI",30000);
	EmployeeBean eb2=new EmployeeBean(1567,"Shilpa",12000);
	EmployeeBean eb3=new EmployeeBean(9123,"Akshitha",20000);
	EmployeeBean eb4=new EmployeeBean(9129,"Mahitha",10000);
    HashMap<Integer,EmployeeBean> h=new HashMap<Integer,EmployeeBean>();
 h.put(1, eb1);
 h.put(2, eb2);
 h.put(3, eb3);
 h.put(4, eb4);

        Set s=h.entrySet();
    	ArrayList<EmployeeBean> al=new ArrayList<EmployeeBean>(s);
	Iterator<EmployeeBean> i=al.iterator();
	while(i.hasNext()) {
		System.out.println(i.next());
	}
}}