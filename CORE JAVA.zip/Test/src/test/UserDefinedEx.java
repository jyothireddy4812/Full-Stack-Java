package test;


class AgeEx extends Exception{
	private int age;
	public AgeEx(int age)
	{
		this.age=age;
	}
	public String toString() {
		return "u r not eligible for marry"+age;
	}
}
public class UserDefinedEx {
static void validation(int age) throws AgeEx
{
	if(age<25)
		throw new AgeEx(age);//AgeEx obj
	else
		System.out.println("u r not eligible to marry");
}
public static void main(String[] args) throws AgeEx  {
	UserDefinedEx.validation(16);
	System.out.println("rest of the code..........");
}
}