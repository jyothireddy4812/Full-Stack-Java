package test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Details implements Serializable
{
	private int id;
	private String name;
	private String mobileNo;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}}
	public class SerializableExam{
		public static void main(String[] args) throws IOException {
			Details d=new Details();
			d.setId(1234);
			d.setName("jyothireddy");
			d.setMobileNo("9840291500");
			File f=new File("jyothi.txt");
			f.mkdir();
			System.out.println(f.exists());
			FileOutputStream fs=new FileOutputStream("jyothi.txt");
			ObjectOutputStream oos =new ObjectOutputStream(fs);
			oos.writeObject(d);
			System.out.println("******");
		} 
	}

