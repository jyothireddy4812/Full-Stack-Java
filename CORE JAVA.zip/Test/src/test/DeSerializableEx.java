package test;

import java.io.FileInputStream;
import java.io.ObjectInputStream;



public class DeSerializableEx {
	public static void main(String[] args) throws Exception  {
		FileInputStream fis=new FileInputStream("jyothi.txt");
	ObjectInputStream ois=new ObjectInputStream(fis);
    Details d=(Details)ois.readObject();
	System.out.println(d.getId());
	System.out.println(d.getName());
	System.out.println(d.getMobileNo());
	}
	}

