package test;
public class Test {
	public void m1()
	{
		System.out.println("This is test class instance method");
		
	}
	public static void m2()
	{
		System.out.println("This is test class static method");
		
	}
	public int add()
	{
		int a=20;
		int b=30;
		return a+b;
		
	}
	public int sub(int a,int b)
	{
	
		return a-b;
	}
	
	public static void main(String[] args) {
		
		Test t=new Test();
		int sum=t.add();
		int minus=t.sub(30,8);
		System.out.println(sum+" "+minus);
		Test.m2();
		t.m1();
	}	
	}
