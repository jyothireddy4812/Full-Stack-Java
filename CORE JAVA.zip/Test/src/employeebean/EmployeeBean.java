package employeebean;

public class EmployeeBean {
private int empId;
private String empName;
private int empSal;
public EmployeeBean(int empId, String empName, int empSal) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empSal = empSal;
}


public EmployeeBean() {
	// TODO Auto-generated constructor stub
}


public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getEmpSal() {
	return empSal;
}
public void setEmpSal(int empSal) {
	this.empSal = empSal;
}
@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "emp id: "+empId+ "emp Name: " +empName+ "emp sal: "+empSal;
	}
}
