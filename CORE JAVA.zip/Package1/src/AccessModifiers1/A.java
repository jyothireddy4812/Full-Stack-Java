package AccessModifiers1;
import AccessModifiers.AccessModifiers;
class B 
{
	protected void m1() {
		System.out.println("JR");
	}
	
}
public class A extends B {
	public static void main(String[] args) {
		B b=new B();
		b.m1();
		AccessModifiers A=new AccessModifiers();
		A.method1();
		
	}

}
