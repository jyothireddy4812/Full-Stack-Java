package AccessModifiers;

class D{
	public void method1() {
		System.out.println("hjk");
	}
}

public class AccessModifiers extends D {
	public static void main(String[] args) {
		D m=new D();
		m.method1();
	System.out.println("absd");
	
}
}


