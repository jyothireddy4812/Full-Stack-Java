package fileexample;

import java.io.File;
import java.io.IOException;

public class Fileconcept {
public static void main(String[] args) throws IOException {
	File f=new File("Jyothireddy.txt");
	f.createNewFile();
	System.out.println("File Created");
}
}
