package fileexample;

import java.io.*;

public class PrintWriterEx {
	public static void main(String[] args) throws IOException {
		//FileWriter fw=new FileWriter("CAPG.txt");//create
		PrintWriter pw=new PrintWriter("CAPG.txt");
		pw.println(1000);
		pw.println("EMPLOYEES");
		pw.println("JYOTHIREDDY");
		pw.println("CAPGEMINI");
		pw.println("12345");
		char [] ch1={'s','s','t'};
		pw.write(ch1);
		pw.close();
		/*fw.write(ch1);
		fw.write("\n");
		fw.flush();
		fw.close();*/
	}

}
