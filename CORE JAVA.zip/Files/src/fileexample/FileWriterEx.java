package fileexample;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriterEx {
	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("cap.txt");//create
		fw.write(98);//character;
		fw.write("\n");
		fw.write("JYOTHIREDDY \n CAPGEMINI");
		fw.write("\n");
		char [] ch1={'r','s','t'};
		fw.write(ch1);
		fw.write("\n");
		fw.flush();
		fw.close();
	}

}
