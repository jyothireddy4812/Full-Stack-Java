package fileexample;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class OutputStreamEx {
public static void main(String[] args) throws IOException {
	FileOutputStream outputStream=new FileOutputStream("CAPG.txt");
	for(int i=0;i<10;i++)
	outputStream.write(i);


FileInputStream inputStream=new FileInputStream("CAPG.txt");

int i;
while(( i=inputStream.read())!=-1) {
	System.out.println("I: "+i);
}
inputStream.close();
outputStream.close();
}
}
