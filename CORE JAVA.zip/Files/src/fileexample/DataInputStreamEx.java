package fileexample;

import java.io.*;
import java.io.IOException;

public class DataInputStreamEx {
	public static void main(String[] args) throws IOException{
		FileOutputStream fs=new FileOutputStream("CAPG.txt");
	DataOutputStream dos=new DataOutputStream(fs);
	dos.writeInt(666);
	dos.writeUTF("JYOTHIREDDY");
	dos.close();
	DataInputStream dis=new DataInputStream(new FileInputStream("CAPG.txt"));
	System.out.println("Int: "+ dis.readInt());
	System.out.println("String: "+ dis.readUTF());
	dis.close();
	}
	
}
