package fileexample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriteEx {
	public static void main(String[] args) throws IOException {
		FileWriter fw=new FileWriter("cap1.txt");
		BufferedWriter bw=new BufferedWriter(fw);//create
		bw.write(100);//character;
		bw.newLine();
		char [] ch={'r','s','t','u'};
		bw.write(ch);
		bw.newLine();
		bw.write("JYOTHIREDDY \n CAPGEMINI");
		bw.newLine();
		bw.write("HELLO");
		
		bw.write("\n");
		bw.flush();
		bw.close();
		fw.close();
	}

}
