package fileexample;

import java.util.Scanner;
import java.io.*;

public class FileTask {


	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		String uname=sc.nextLine();
		String pwd=sc.nextLine();
		PrintWriter pw=new PrintWriter("CAPG.txt");
		pw.println(uname);
		pw.println(pwd);
		pw.flush();
		pw.close();
		
		FileReader fr=new FileReader("CAPG.txt");
		BufferedReader br=new BufferedReader(fr);
		String line=br.readLine();
		//System.out.println(line);
		while(line!=null)
		{
		
			if(uname.equals("JYOTHIREDDY") && pwd.equals("12345")) {
			
			System.out.println("LOGIN SUCCESSFULL");
			break;
			
			}//line=br.readLine();
			else {
				System.out.println("INVALID CREDITIALS");
				break;
			}
		

		}
		br.close();
		sc.close();
	}
		
				
		
	} 


