package fileexample;

import java.io.*;
;

class Student implements Serializable
{
	private int sno;
	private String name;
	private String saddr;


public int getSno() {
		return sno;
	}


	public void setSno(int sno) {
		this.sno = sno;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSaddr() {
		return saddr;
	}


	public void setSaddr(String saddr) {
		this.saddr = saddr;
	}

}
public class Serialization {
	public static void main(String[] args) throws IOException {
		Student st=new Student();
		st.setSno(1011);
		st.setName("JYOTHIREDDY");
		st.setSaddr("BANGALORE");
		FileOutputStream fs=new FileOutputStream("Capg1.txt");
		ObjectOutputStream oos =new ObjectOutputStream(fs);
		oos.writeObject(st);
		System.out.println("SUCCESS");
		oos.close();
	}

}
