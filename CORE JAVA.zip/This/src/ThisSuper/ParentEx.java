package ThisSuper;

 class ParentEx1 {
	int a=12;
	public ParentEx1()
	{
		System.out.println("default constructor of parent");
	}
ParentEx1(int a)
{
	this();
	System.out.println("parent class parameterized"+a);
}
public void m1()
{
	System.out.println("parent class method");
}
}
public class ParentEx extends ParentEx1
{
	int a=20;
	ParentEx()
	{
		super();
		super.m1();
		this.m1();
		System.out.println(this.a);
		System.out.println(super.a);
		System.out.println(this);
		System.out.println("child class constructor");}
		public void m1()
		{
			System.out.println("parent class method");
		}
		public static void main(String[] args) {
			ParentEx e=new ParentEx();
			System.out.println(e);
			ParentEx1 p=new ParentEx1(12);
		}
	}
	
	