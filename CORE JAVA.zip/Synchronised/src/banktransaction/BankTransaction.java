package banktransaction;
class Account{
	public int balance;
	public Account() {
		balance=10000;
	}
	public synchronized void withdraw(int bal) {
	
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
			}
		balance=balance-bal;
		System.out.println("Amount withdrawn="+bal);
		System.out.println("Remaining balance="+balance);
		}
	public synchronized void deposit(int bal) {
		
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
			}
		balance=balance+bal;
		System.out.println("Amount deposited="+bal);
		System.out.println("New balance="+balance);
		}
	public synchronized void enquiry() {
		
		try {
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
			}
		System.out.println("Available Balance="+balance);
		}
	}
class Transaction implements Runnable{
	Account obj;
Transaction(Account a){
	obj=a;
}
public void run() {
	obj.withdraw(700);
	obj.deposit(1000);
	obj.enquiry();
}
}

public class BankTransaction {
	public static void main(String[] args) throws InterruptedException {
		Account a=new Account();
		Transaction t=new Transaction(a);
		Thread t1=new Thread(t);
		Thread t2=new Thread(t);
		t1.start();
		t1.join();
		t2.start();
		//t2.join();
		
		}

}
