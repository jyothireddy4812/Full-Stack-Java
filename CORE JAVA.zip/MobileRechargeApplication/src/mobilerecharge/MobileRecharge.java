package mobilerecharge;

import java.util.HashMap;
import java.util.Scanner;

class A {
	String name;
	String actType;
	int balance;

	A(String name, String actType, int balance) {
		super();
		this.name = name;
		this.actType = actType;
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getActType() {
		return actType;
	}

	public void setActType(String actType) {
		this.actType = actType;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "" + name + "" + actType + "" + balance;
	}
}

public class MobileRecharge {
	public static void main(String[] args) {
		HashMap<String, A> h = new HashMap<String, A>();
		A a1 = new A("JYOTHIREDDY ", "POSTPAID ", 1000);
		A a2 = new A("SHILPA ", "PREPAID ", 900);
		A a3 = new A("AKSHITHA ", "PREPAID ", 10);
		A a4 = new A("MAHITHA ", "POSTPAID ", 1200);
		h.put("9840291500", a1);
		h.put("8317580045", a2);
		h.put("8125199885", a3);
		h.put("9789850682", a4);
		System.out.println(h);
		System.out.println("1.Display");
		System.out.println("2.Add");
		Scanner sc = new Scanner(System.in);
		int d = sc.nextInt();

		
		switch (d) {
		case 1:
			String num1 = sc.next();
			A x1 = (A) h.get(num1);
			System.out.println(x1);
			break;
			case 2:
			int	bal = sc.nextInt();
			String num2 = sc.next();
			A t0=(A) h.get(num2);
			int c = t0.getBalance();
			int d1 = bal + c;
			System.out.println(d1);
			System.out.println("recharge done successfully");
			break;

		}sc.close();
	}

}
