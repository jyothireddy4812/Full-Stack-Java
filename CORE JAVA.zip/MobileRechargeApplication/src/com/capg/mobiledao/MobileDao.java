package com.capg.mobiledao;

import java.util.HashMap;

import com.capg.mobilebeans.MobileBean;

public class MobileDao implements MobileDaoI {
HashMap<String, MobileBean> h=null;
public MobileDao(){
	 h = new HashMap<String, MobileBean>();
		MobileBean a1 = new MobileBean("JYOTHIREDDY ", "POSTPAID ", 1000);
		MobileBean a2 = new MobileBean("SHILPA ", "PREPAID ", 900);
		MobileBean a3 = new MobileBean("AKSHITHA ", "PREPAID ", 10);
		MobileBean a4 = new MobileBean("MAHITHA ", "POSTPAID ", 1200);
		h.put("9840291500", a1);
		h.put("8317580045", a2);
		h.put("8125199885", a3);
		h.put("9789850682", a4);

	
}
@Override
public MobileBean userAcct(String mb) {
	MobileBean mb1=(MobileBean) h.get(mb);
	return mb1;
	
	
}
}
