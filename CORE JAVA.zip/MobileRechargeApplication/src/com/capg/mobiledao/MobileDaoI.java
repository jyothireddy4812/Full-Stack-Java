package com.capg.mobiledao;

import com.capg.mobilebeans.MobileBean;

public interface MobileDaoI {
	MobileBean userAcct(String mb);
}
