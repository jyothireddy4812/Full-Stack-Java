package com.capg.mobileui;

import java.util.Scanner;

import com.capg.mobilebeans.MobileBean;
import com.capg.mobileservice.MobileService;

public class MobileUi {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter your mobile number");
	String mobileNo=sc.next();
	MobileService ms=new MobileService();
	MobileBean mb=ms.userAcct( mobileNo);
	System.out.println(mb);
	sc.close();
}}
