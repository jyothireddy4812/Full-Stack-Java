package com.capg.mobilebeans;



public class MobileBean {
	private String actType;
	private String name;
	private float balance;
	public MobileBean(String actType, String name, float balance) {
		super();
		this.actType = actType;
		this.name = name;
		this.balance = balance;	
	}
	public String getActType() {
		return actType;
	}
	public void setActType(String actType) {
		this.actType = actType;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
		
		public String toString() {
			return " "+actType+ " "+name+ " "+balance;
		}
			
	
	}
	
	








   