package com.capg.mobileservice;

import com.capg.mobilebeans.MobileBean;

public interface MobileServiceI {
	MobileBean userAcct(String mobileNo);
}
