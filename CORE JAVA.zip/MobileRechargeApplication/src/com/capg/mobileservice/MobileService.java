package com.capg.mobileservice;

import com.capg.mobilebeans.MobileBean;
import com.capg.mobiledao.MobileDao;

public class MobileService implements MobileServiceI{
	MobileDao md=new MobileDao();
public MobileBean userAcct(String mobileNo)
{ 

	MobileBean mb=md.userAcct(mobileNo);


	return mb;
	
}


}

