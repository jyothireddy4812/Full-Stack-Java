package jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
//loading the driver class
	Class.forName("oracle.jdbc.driver.OracleDriver");
	//create the connection
	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","jyothireddy","jyothi4812");
	//crete statement
	Statement stmt= conn.createStatement();
	//execute query
	//boolean b=stmt.execute("create table jyothireddy(id number(10),name varchar2(10))");
	int b1= stmt.executeUpdate("insert into jyothireddy values(1234,'jyothi')");
	int b2= stmt.executeUpdate("insert into jyothireddy values(1235,'akshitha')");
	int b3= stmt.executeUpdate("insert into jyothireddy values(1256,'shilpa')");
	int b4= stmt.executeUpdate("insert into jyothireddy values(1267,'mahitha')");
    ResultSet r=stmt.executeQuery("select * from jyothireddy");


    while(r.next()) {
    	System.out.println(r.getInt(1)+ " "+r.getString(2));
    }
  //close the connection
  	conn.close();
		// System.out.println("table created " +r);
	}
}
