package jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JdbcTask {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
Scanner sc=new Scanner(System.in);
System.out.println("enter your username");
String uname=sc.next();
System.out.println("enter your password");
String pwd=sc.next();
System.out.println("enter your phone number");
String phone=sc.next();
	Class.forName("oracle.jdbc.driver.OracleDriver");

	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","jyothireddy","jyothi4812");
PreparedStatement ps=conn.prepareStatement("insert into gmail values(?,?,?)");
ps.setString(1,uname);
ps.setString(2,pwd);
ps.setString(3,phone);
int rs=ps.executeUpdate();
if(rs>0) {
	System.out.println("registered successfully");
}
sc.close();
conn.close(); 
}}




	

