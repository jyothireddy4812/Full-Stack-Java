package poly.overriding;


class Test1 {
	static void add()
	{
		System.out.println("default method");
	}
	static void add(int a,int b)
	{
		System.out.println("sum is "+(a+b));
	}
	static void add(float a,float b)
	{
		System.out.println("sum is "+(a+b));
	}
	static void add(int a,float b)
	{
		System.out.println("sum is "+(a+b));
	}

	static void add(float a,int b)
	{
		System.out.println("sum is "+(a+b));
	}

}
class Override extends Test1
{
	static void add()
	{
		System.out.println("JYOTHI REDDY");
	}
	public static void main(String[] args) {
		Override.add();
		Test1.add();
		
		Test1.add(6,7);
		Test1.add(2.45f,4.45f);
		Test1.add(12,4.56f);
		Test1.add(2.456f,19);
	}
}
