
package com.capg.walletui;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capg.walletbeans.TransactionBeans;
import com.capg.walletbeans.WalletBeans;
import com.capg.walletservice.WalletServiceImpl;
import exceptions.AccountNotFoundException;
import exceptions.InsufficientBalanceException;

public class Client {
	static WalletServiceImpl ws=new WalletServiceImpl();
public static void main(String[] args) {
	long accNo;
	String mobileNo;
	String userName;
	String password;
	long balance=10000;

	while(true)
	{

	System.out.println("------------XYZ BANK-----------");
	System.out.println("******BANK WALLET APPLICATION*******");
	System.out.println("1.CREATE ACCOUNT");
	System.out.println("2.SHOW BALANCE");
	System.out.println("3.DEPOSIT MONEY");
	System.out.println("4.WITHDRAW MONEY");
	System.out.println("5.FUND TRANSFER");
	System.out.println("6.PRINT TRANSACTIONS");
	System.out.println("7.EXIT");
	Scanner sc=new Scanner(System.in);
	System.out.println("ENTER YOUR CHOICE");
	int choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("Enter your username");
		userName=ws.validationName(sc.next());
		System.out.println("Enter your password");
		password=sc.next();
		System.out.println("Enter your mobile number");
		mobileNo=ws.validationMobileNo(sc.next());
		Random r=new Random();
		accNo=(long) r.nextInt(999999);
		System.out.println("Your Account No is "+accNo);
		WalletBeans wb=new WalletBeans(userName,password,balance,mobileNo,accNo);
	    WalletBeans wb1=ws.userAccount(wb);
	    System.out.println(wb);
	    System.out.println("ACCOUNT CREATED SUCCESSFULLY :)");
      	break;
	case 2:
		System.out.println("Enter your Account Number");
		accNo=sc.nextLong();
		try {
		WalletBeans wb2=ws.showBalance(accNo);
			System.out.println("Your Account Balance: "+wb2.getBalance());
		}catch (AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
		break;
	case 3:
		System.out.println("Enter your Account Number");
		accNo=sc.nextLong();
		try {
		System.out.println("Enter the amount to be deposited");
		long bal=ws.validationBal(sc.nextLong());
		WalletBeans wb3=ws.deposit(accNo,bal);
		System.out.println("Deposited Amount: "+bal);
		System.out.println("Available Account  balance: "+wb3.getBalance());
		}catch (AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		break;
	case 4:
		System.out.println("Enter your Account Number");
		accNo=sc.nextLong();
		try {
		System.out.println("Enter the amount to withdraw");
		long bal1=ws.validationBal(sc.nextLong());
		WalletBeans wb4=ws.withdraw(accNo,bal1);
		System.out.println("Withdrawn Amount: "+bal1);
		System.out.println("Available Account  balance:: "+wb4.getBalance());
		}catch (AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		break;
	case 5:
		System.out.println("Enter your Account Number");
		accNo=sc.nextLong();
		System.out.println("Enter the account number to transfer amount");
		long accNo1=sc.nextLong();
		try {
		System.out.println("Enter the amount to transfer");
		long bal2=ws.validationBal(sc.nextLong());
		WalletBeans wb5=ws.fundTransfer(accNo,accNo1,bal2);
		System.out.println("Amount transferred is:  "+bal2);
		System.out.println("Successfully Transferred Fund.....\nAvailable balance is: "+wb5.getBalance());
		}catch (AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}catch (InsufficientBalanceException e) {
			System.out.println(e.getMessage());
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
		}
		break;
	case 6:
		System.out.println("Enter your Account Number");
		accNo=sc.nextLong();
		try {
	    List<TransactionBeans> l=ws.getTransactions(accNo);
	    System.out.println(l+"\n");
		}catch (AccountNotFoundException e) {
			System.out.println(e.getMessage());
		}
	    break;
	case 7:
	System.out.println("THANK U \nVISIT AGAIN:)");
	break;

		default:
			System.out.println("Invalid choice \n Please enter valid Choice:)");
	 sc.close();
		
}
}}}
