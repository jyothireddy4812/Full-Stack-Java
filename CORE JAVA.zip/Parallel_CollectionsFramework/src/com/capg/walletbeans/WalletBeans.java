package com.capg.walletbeans;

public class WalletBeans {
	private String userName;
	private String password;
	private long balance;
	private String mobileNo;
	private long accNo;
	

public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public double getBalance() {
		return balance;
	}


	public void setBalance(long balance) {
		this.balance = balance;
	}


	public String getMobileNo() {
		return mobileNo;
	}


	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}


	public long getAccNo() {
		return accNo;
	}


	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}


public WalletBeans(String userName, String password, long balance, String mobileNo, long accNo) {
		super();
		this.userName = userName;
		this.password = password;
		this.balance = balance;
		this.mobileNo = mobileNo;
		this.accNo = accNo;
	}



@Override
public String toString() {

	return "UserName: "+userName+ "\nInitial Account Balance: "+balance+ "\nAccount Number: "+accNo; 
}


public String getTrans() {
	// TODO Auto-generated method stub
	return null;
}






}



