package com.capg.walletbeans;

public class TransactionBeans {
private int transId;
private String transDate;
private String transType;
private long balance;
private long accFrom;
private long accTo;
private long bal;
public long getBal() {
	return bal;
}
public void setBal(long bal) {
	this.bal = bal;
}

public TransactionBeans(int transId, String transDate, String transType, long balance, long accFrom, long accTo,
		long bal) {
	super();
	this.transId = transId;
	this.transDate = transDate;
	this.transType = transType;
	this.balance = balance;
	this.accFrom = accFrom;
	this.accTo = accTo;
	this.bal = bal;
}
public TransactionBeans() {
	// TODO Auto-generated constructor stub
}
public int getTransId() {
	return transId;
}
public void setTransId(int transId) {
	this.transId = transId;
}
public String getTransDate() {
	return transDate;
}
public void setTransDate(String transDate) {
	this.transDate = transDate;
}
public String getTransType() {
	return transType;
}
public void setTransType(String transType) {
	this.transType = transType;
}
public long getBalance() {
	return balance;
}
public void setBalance(long balance) {
	this.balance = balance;
}
public long getAccFrom() {
	return accFrom;
}
public void setAccFrom(long accNo) {
	this.accFrom = accNo;
}
public long getAccTo() {
	return accTo;
}
public void setAccTo(long accTo) {
	this.accTo = accTo;
}

@Override
public String toString() {
	return "\nTransaction Id: " +transId+ "\nTransaction date: " +transDate+ "\nFrom Account: " +accFrom+ "\nTo Account : " +accTo+ "\nTransfer Amount  :"+bal+ "\nAvailable balance: " +balance+ "\nTransaction type: " +transType ;
	
}}
