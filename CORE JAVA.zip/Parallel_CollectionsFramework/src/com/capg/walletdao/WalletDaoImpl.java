package com.capg.walletdao;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Random;

import com.capg.walletbeans.TransactionBeans;
import com.capg.walletbeans.WalletBeans;

import exceptions.AccountNotFoundException;
import exceptions.InsufficientBalanceException;

public class WalletDaoImpl implements WalletDaoInterface {

   LinkedHashMap<Long, WalletBeans> h=null;
   LinkedHashMap<TransactionBeans, Long>h1 =null;
   public WalletDaoImpl() {
	 h = new LinkedHashMap<Long, WalletBeans>();
	 h1=new LinkedHashMap<TransactionBeans, Long>();
    }
   
	@Override
	public WalletBeans userAccount1(WalletBeans wb) {
	    h.put(wb.getAccNo(),wb);
		WalletBeans wb1=(WalletBeans)h.get(wb.getAccNo());
		return wb1;
	}

	@Override
	public WalletBeans showBalance(Long accNo) {
		WalletBeans wb1=(WalletBeans)h.get(accNo);
		if(wb1==null) {
			throw new AccountNotFoundException("Invalid Account Number or Create New Account:)"); 
		}else
		{
		return wb1;
        }
	    }
	@Override
	public WalletBeans deposit(long accNo, long bal) {
		WalletBeans wb1=(WalletBeans)h.get(accNo);
		if(wb1==null) {
			throw new AccountNotFoundException("Invalid Account Number or Create New Account:)"); 
		}else
		{
		long a=(long) wb1.getBalance();
		long money=a+bal;
		wb1.setBalance(money);
		Date date=(Date) Calendar.getInstance().getTime();
		DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-DD HH:MM:SS");
		String strDate=dateFormat.format(date);
		Random r=new Random();
		int transId=r.nextInt(99999);
		TransactionBeans t=new TransactionBeans();
		t.setTransId(transId);
		t.setTransDate(strDate);
		t.setBalance(money);
		t.setAccFrom(accNo);
		t.setBal(bal);
		t.setTransType("Deposit...");
		h1.put(t, accNo);
		return wb1;
		}
	}
	@Override
	public WalletBeans withdraw(long accNo, long bal1) {
		WalletBeans wb1=(WalletBeans)h.get(accNo);
		if(wb1==null ) {
			throw new AccountNotFoundException("Invalid Account Number or Create New Account:)"); 
		}
		else {
			if(wb1.getBalance()<bal1){
				throw new InsufficientBalanceException("Insufficient Balance");
		}
		long a=(long) wb1.getBalance();
		long money1=a-bal1;
		wb1.setBalance(money1);
		Date date=(Date) Calendar.getInstance().getTime();
		DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-DD HH:MM:SS");
		String strDate=dateFormat.format(date);
		Random r=new Random();
		int transId=r.nextInt(999999);
		TransactionBeans t=new TransactionBeans();
		t.setTransId(transId);
		t.setTransDate(strDate);
		t.setBalance(money1);
		t.setAccFrom(accNo);
		t.setBal(bal1);
		t.setTransType("Withdraw....");
		h1.put(t, accNo);
		return wb1;
	}}
	@Override
	public WalletBeans fundTransfer(long accNo, long accNo1, long bal2) {
		WalletBeans wb1=(WalletBeans)h.get(accNo);
		WalletBeans wb2=(WalletBeans)h.get(accNo1);
		if(wb1==null) {
			throw new AccountNotFoundException("Invalid Account Number or Create New Account:)"); 
		}
		else 
		{
			if(wb1.getBalance()<bal2){
				throw new InsufficientBalanceException("Insufficient Balance");
		}
		long w=(long) wb1.getBalance();
		long w1=w-bal2;
		long d=(long) wb2.getBalance();
		long d1=d+bal2;
		wb1.setBalance(w1);
		wb2.setBalance(d1);
		Date date=(Date) Calendar.getInstance().getTime();
		DateFormat dateFormat=new SimpleDateFormat("YYYY-MM-DD HH:MM:SS");
		String strDate=dateFormat.format(date);
		Random r=new Random();
		int transId=r.nextInt(99999);
		TransactionBeans t=new TransactionBeans();
		t.setTransId(transId);
		t.setTransDate(strDate);
		t.setBalance(w1);
		t.setAccFrom(accNo);
		t.setAccTo(accNo1);
		t.setBal(bal2);
		t.setTransType("Fund Transfer.....");
		h1.put(t, accNo);
		return wb1;
	}}
	@Override
	public List<TransactionBeans> getTransactions(Long accNo){
		WalletBeans wb1=(WalletBeans)h.get(accNo);
		if(wb1==null) {
			throw new AccountNotFoundException("Invalid Account Number or Create New Account:)"); 
		}else {
		ArrayList<TransactionBeans> a=new ArrayList<TransactionBeans>(h1.keySet());
		return a;
	}
	}}





			
		
	
	
	
	
	
	
	






