package com.capg.walletdao;
import org.junit.jupiter.api.Test;
import java.util.HashMap;

import org.junit.jupiter.api.Assertions;
import com.capg.walletbeans.WalletBeans;

@SuppressWarnings("unchecked")
public class JUnit {
	WalletDaoImpl dao=new WalletDaoImpl();
@SuppressWarnings("rawtypes")
static HashMap hm = new HashMap();
	
	static{
	
		
		try {
			WalletBeans bean=new WalletBeans("Jyothi","tweety4812",10000,"7894561230",761858);
			WalletBeans bean1=new WalletBeans("Jyothireddy","qwerty48",10000,"7412589963",110917);		
			hm.put(761858, bean);
			hm.put(110917, bean1);
		} catch (Exception e) {
		
			e.printStackTrace();
		}
	
	}
	//Hashmap which is storing all account holders information
	WalletBeans bean1;					//object of Bankbean class

	@Test// getting Balance of account holder by reference to their accno
	public void getBalance() { 
		double observed;
		if (hm.containsKey(761858)) {
			WalletBeans bean1 = (WalletBeans) hm.get(761858);
			observed= bean1.getBalance();
		} else
			observed =10000;
		long expected=1000;
		Assertions.assertEquals(expected, observed);
		
	}

	@Test// Getting information of account holder using accNo
	public  void getInfo() {
		// TODO Auto-generated method stub
		WalletBeans wb=(WalletBeans)hm.get(761858);
		String expected="Jyothireddy";
	}
}
