package com.capg.walletdao;

import java.util.List;

import com.capg.walletbeans.TransactionBeans;
import com.capg.walletbeans.WalletBeans;

public interface WalletDaoInterface {
	
	WalletBeans showBalance(Long accNo);

	WalletBeans userAccount1(WalletBeans wb);

	WalletBeans deposit(long accNo, long bal);

	WalletBeans withdraw(long accNo, long bal1);
	
	WalletBeans fundTransfer(long accNo, long accNo1, long bal2) ;

	List<TransactionBeans> getTransactions(Long accNo);
}
