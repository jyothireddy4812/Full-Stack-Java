package com.capgemini.hotel.service;

import java.util.Scanner;


import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;

public class HotelService implements IHotelService{
	Scanner sc=new Scanner(System.in);

	CustomerBookingDAO dao=new CustomerBookingDAO();
	
	@Override
	public RoomBooking getBookingDetails(int customerId) {
		RoomBooking room=dao.getBookingDetails(customerId);
		return room;
	}
		@Override
		public int addCustomerDetails(CustomerBean bean) {
			int cust=dao.addCustomerDetails(bean);
	        return bean.getCustomerId();
		}
		public String validationName(String userName) {
			if(userName.matches("[A-Z][a-zA-Z]*")){
				return userName;
			}else {
				System.out.println("Enter Valid Name Starts with Uppercase");
				return userName=sc.next();
			}
			}
		public String validationMobileNo(String mobileNo) {
			while(true) {
				if(String.valueOf(mobileNo).length()==10 && mobileNo.matches("[6-9][0-9]{9}")) {
					System.out.println(mobileNo);
					return mobileNo;
				}else {
					System.out.println("Enter valid 10 digit number");
					mobileNo=sc.next();			}
			}}
			public int validationCode(int customerId) {
				while (true) {
					if(customerId==4) {
						System.out.println("enter valid 4 digit code ");
						customerId=sc.nextInt();
					}else {
						return customerId;
					}
				}
			}


}
