package com.capgemini.hotel.dao;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;

public interface ICustomerBookingDAO {
	//CustomerBean addCustomerDetails(CustomerBean bean) ;
	int addCustomerDetails(CustomerBean bean);
	RoomBooking getBookingDetails(int customerId);
	}
	
